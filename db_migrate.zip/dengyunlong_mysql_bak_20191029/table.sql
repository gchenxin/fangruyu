-- MySQL dump 10.13  Distrib 5.5.57, for Linux (x86_64)
--
-- Host: localhost    Database: dengyunlong_26dj
-- ------------------------------------------------------
-- Server version	5.5.57-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `huoniao_admingroup`
--

DROP TABLE IF EXISTS `huoniao_admingroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_admingroup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `groupname` char(30) NOT NULL DEFAULT '' COMMENT '管理组',
  `purviews` text COMMENT '权限范围',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `groupname` (`groupname`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_adminlogin`
--

DROP TABLE IF EXISTS `huoniao_adminlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_adminlogin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `logintime` int(10) NOT NULL DEFAULT '0' COMMENT '登录时间',
  `loginip` char(15) NOT NULL DEFAULT '' COMMENT '登录IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9811 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='管理员登录记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_advlist`
--

DROP TABLE IF EXISTS `huoniao_advlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_advlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `model` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `template` char(30) NOT NULL DEFAULT '' COMMENT '所属模板',
  `class` int(10) NOT NULL COMMENT '广告类型',
  `typeid` int(10) NOT NULL COMMENT '所属分类',
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '投放城市',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '广告名称',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `starttime` int(10) NOT NULL DEFAULT '0' COMMENT '起始时间',
  `endtime` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `body` text NOT NULL COMMENT '广告内容',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=280 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_advlist_city`
--

DROP TABLE IF EXISTS `huoniao_advlist_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_advlist_city` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '广告ID',
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `body` text NOT NULL COMMENT '广告内容',
  `admin` int(10) NOT NULL DEFAULT '0' COMMENT '操作人',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `cityid` (`cityid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='城市分站广告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_advtype`
--

DROP TABLE IF EXISTS `huoniao_advtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_advtype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `model` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=391 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='广告分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_agentpushrecord`
--

DROP TABLE IF EXISTS `huoniao_agentpushrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_agentpushrecord` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `zjid` int(10) NOT NULL,
  `expire` datetime NOT NULL,
  `realphone` char(11) NOT NULL DEFAULT '',
  `visualphone` char(11) NOT NULL DEFAULT '',
  `remarks` varchar(100) DEFAULT NULL,
  `collected` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_agentresource`
--

DROP TABLE IF EXISTS `huoniao_agentresource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_agentresource` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `phone` char(11) NOT NULL DEFAULT '11111111111',
  `company` varchar(50) DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '2',
  `distinct` varchar(50) NOT NULL DEFAULT '',
  `remarks` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=88081 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_app_audio_video_config`
--

DROP TABLE IF EXISTS `huoniao_app_audio_video_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_app_audio_video_config` (
  `access_key` varchar(100) NOT NULL DEFAULT '',
  `secret_key` varchar(100) NOT NULL DEFAULT '',
  `bucket` varchar(100) NOT NULL DEFAULT '' COMMENT '存储空间',
  `pipeline` varchar(100) NOT NULL DEFAULT '' COMMENT '数据处理队列名称',
  `domain` varchar(100) NOT NULL DEFAULT '' COMMENT '外链域名',
  `audio_quality` varchar(100) NOT NULL DEFAULT '' COMMENT '音频质量'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='音视频处理配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_app_config`
--

DROP TABLE IF EXISTS `huoniao_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_app_config` (
  `appname` varchar(100) NOT NULL DEFAULT '' COMMENT 'APP名称',
  `logo` varchar(100) NOT NULL DEFAULT '' COMMENT 'logo',
  `android_version` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓最新版本',
  `android_update` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓更新时间',
  `android_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '安卓是否强制升级',
  `android_size` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓包大小',
  `android_note` text NOT NULL COMMENT '安卓更新内容',
  `ios_version` varchar(50) NOT NULL DEFAULT '' COMMENT '苹果最新版本',
  `ios_update` varchar(50) NOT NULL DEFAULT '' COMMENT 'ios更新时间',
  `ios_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '苹果是否强制升级',
  `ios_note` text NOT NULL COMMENT 'ios更新内容',
  `android_download` varchar(255) NOT NULL COMMENT '安卓下载地址',
  `yyb_download` varchar(255) NOT NULL DEFAULT '' COMMENT '应用宝链接地址',
  `ios_download` varchar(255) NOT NULL DEFAULT '' COMMENT '苹果下载地址',
  `android_guide` text NOT NULL COMMENT '安卓引导页',
  `ios_guide` text NOT NULL COMMENT '苹果引导页',
  `ad_pic` varchar(100) NOT NULL DEFAULT '' COMMENT '广告页图片',
  `ad_link` varchar(255) NOT NULL DEFAULT '' COMMENT '广告页链接',
  `ad_time` smallint(5) NOT NULL DEFAULT '0' COMMENT '广告页时间',
  `android_index` varchar(255) NOT NULL DEFAULT '' COMMENT '安卓首页',
  `ios_index` varchar(255) NOT NULL DEFAULT '' COMMENT '苹果首页',
  `map_baidu_android` varchar(255) NOT NULL DEFAULT '' COMMENT '百度地图-安卓',
  `map_baidu_ios` varchar(255) NOT NULL DEFAULT '' COMMENT '百度地图-苹果',
  `map_google_android` varchar(255) NOT NULL DEFAULT '' COMMENT '谷歌地图',
  `map_google_ios` varchar(255) NOT NULL DEFAULT '',
  `map_amap_android` varchar(255) NOT NULL,
  `map_amap_ios` varchar(255) NOT NULL,
  `map_set` tinyint(1) NOT NULL DEFAULT '1' COMMENT '默认地图',
  `business_appname` varchar(100) NOT NULL DEFAULT '' COMMENT '商家APP名称',
  `business_android_version` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓最新版本',
  `business_android_update` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓更新时间',
  `business_android_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '安卓是否强制升级',
  `business_android_size` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓包大小',
  `business_android_note` text NOT NULL COMMENT '安卓更新内容',
  `business_ios_version` varchar(50) NOT NULL DEFAULT '' COMMENT '苹果最新版本',
  `business_ios_update` varchar(50) NOT NULL DEFAULT '' COMMENT 'ios更新时间',
  `business_ios_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '苹果是否强制升级',
  `business_ios_note` text NOT NULL COMMENT 'ios更新内容',
  `business_android_download` varchar(255) NOT NULL COMMENT '安卓下载地址',
  `business_yyb_download` varchar(255) NOT NULL DEFAULT '' COMMENT '应用宝链接地址',
  `business_ios_download` varchar(255) NOT NULL DEFAULT '' COMMENT '苹果下载地址',
  `peisong_appname` varchar(100) NOT NULL DEFAULT '' COMMENT '骑手APP名称',
  `peisong_android_version` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓最新版本',
  `peisong_android_update` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓更新时间',
  `peisong_android_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '安卓是否强制升级',
  `peisong_android_size` varchar(50) NOT NULL DEFAULT '' COMMENT '安卓包大小',
  `peisong_android_note` text NOT NULL COMMENT '安卓更新内容',
  `peisong_ios_version` varchar(50) NOT NULL DEFAULT '' COMMENT '苹果最新版本',
  `peisong_ios_update` varchar(50) NOT NULL DEFAULT '' COMMENT 'ios更新时间',
  `peisong_ios_force` smallint(1) NOT NULL DEFAULT '0' COMMENT '苹果是否强制升级',
  `peisong_ios_note` text NOT NULL COMMENT 'ios更新内容',
  `peisong_android_download` varchar(255) NOT NULL COMMENT '安卓下载地址',
  `peisong_yyb_download` varchar(255) NOT NULL DEFAULT '' COMMENT '应用宝链接地址',
  `peisong_ios_download` varchar(255) NOT NULL DEFAULT '' COMMENT '苹果下载地址',
  `business_logo` varchar(100) DEFAULT '' COMMENT 'logo',
  `peisong_logo` varchar(100) DEFAULT '' COMMENT 'logo',
  `rongKeyID` varchar(255) DEFAULT '' COMMENT '融云ID',
  `rongKeySecret` varchar(255) DEFAULT '' COMMENT '融云Secret',
  `peisong_map_baidu_android` varchar(255) NOT NULL DEFAULT '' COMMENT '百度地图-安卓',
  `peisong_map_baidu_ios` varchar(255) NOT NULL DEFAULT '' COMMENT '百度地图-苹果',
  `peisong_map_google_android` varchar(255) NOT NULL DEFAULT '' COMMENT '谷歌地图',
  `peisong_map_google_ios` varchar(255) NOT NULL,
  `peisong_map_amap_android` varchar(255) NOT NULL,
  `peisong_map_amap_ios` varchar(255) NOT NULL,
  `peisong_map_set` tinyint(1) NOT NULL DEFAULT '1' COMMENT '默认地图',
  `template` varchar(50) NOT NULL DEFAULT '' COMMENT '风格管理',
  `customBottomButton` text NOT NULL COMMENT '自定义底部按钮',
  `ios_shelf` smallint(1) NOT NULL DEFAULT '0' COMMENT 'ios上架'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP基本配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_app_push_config`
--

DROP TABLE IF EXISTS `huoniao_app_push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_app_push_config` (
  `android_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access id',
  `android_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access key',
  `android_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓secret key',
  `ios_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access id',
  `ios_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access key',
  `ios_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果secret key',
  `platform` varchar(100) NOT NULL DEFAULT '' COMMENT '平台',
  `business_android_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access id',
  `business_android_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access key',
  `business_android_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓secret key',
  `business_ios_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access id',
  `business_ios_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access key',
  `business_ios_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果secret key',
  `peisong_android_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access id',
  `peisong_android_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓access key',
  `peisong_android_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '安卓secret key',
  `peisong_ios_access_id` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access id',
  `peisong_ios_access_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果access key',
  `peisong_ios_secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT '苹果secret key'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP推送配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_article`
--

DROP TABLE IF EXISTS `huoniao_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_article` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL COMMENT '信息ID',
  `body` mediumtext NOT NULL COMMENT '信息内容',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_article_breakup_table`
--

DROP TABLE IF EXISTS `huoniao_article_breakup_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_article_breakup_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) DEFAULT NULL COMMENT '表名',
  `begin_id` int(11) DEFAULT NULL COMMENT '开始id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分表记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_article_pagecount_cache`
--

DROP TABLE IF EXISTS `huoniao_article_pagecount_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_article_pagecount_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text,
  `value` int(30) DEFAULT NULL,
  `update_at` int(30) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='资讯列表count缓存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_articlecommon`
--

DROP TABLE IF EXISTS `huoniao_articlecommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_articlecommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_articlelist`
--

DROP TABLE IF EXISTS `huoniao_articlelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_articlelist` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `subtitle` char(36) NOT NULL DEFAULT '' COMMENT '短标题',
  `flag` set('h','r','b','p','t') NOT NULL DEFAULT '' COMMENT '附加属性',
  `redirecturl` varchar(255) DEFAULT '' COMMENT '跳转地址',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `litpic` char(255) DEFAULT '' COMMENT '缩略图',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `sourceurl` char(200) NOT NULL DEFAULT '' COMMENT '来源网址',
  `writer` char(20) NOT NULL DEFAULT '' COMMENT '作者',
  `typeid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `keywords` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `mbody` text COMMENT '手机端内容',
  `notpost` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评论开关',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `admin` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `audit_log` text COMMENT '审核记录',
  `audit_state` char(20) NOT NULL DEFAULT '' COMMENT '审核状态',
  `audit_edit` text COMMENT '审核修改记录',
  `reward_switch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '打赏开关',
  `flag_h` varchar(5) DEFAULT '',
  `flag_b` varchar(5) DEFAULT '',
  `flag_r` varchar(5) DEFAULT '',
  `flag_t` varchar(5) DEFAULT '',
  `flag_p` varchar(5) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE,
  KEY `del` (`del`,`arcrank`,`typeid`,`flag`,`litpic`,`weight`) USING BTREE,
  KEY `flag` (`flag`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `keywords` (`keywords`) USING BTREE,
  KEY `weight` (`weight`,`id`) USING BTREE,
  KEY `flag_` (`flag_h`,`flag_b`,`flag_r`,`flag_t`,`flag_p`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=237 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_articlepic`
--

DROP TABLE IF EXISTS `huoniao_articlepic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_articlepic` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL COMMENT '信息ID',
  `picPath` varchar(255) NOT NULL DEFAULT '' COMMENT '图片路径',
  `picInfo` text COMMENT '图片注释',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=342 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻图集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_articletype`
--

DROP TABLE IF EXISTS `huoniao_articletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_articletype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `pinyin` char(100) NOT NULL DEFAULT '' COMMENT '分类全拼',
  `py` char(50) NOT NULL DEFAULT '' COMMENT '分类首字母',
  `admin` char(50) DEFAULT '' COMMENT '管理员id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_attachment`
--

DROP TABLE IF EXISTS `huoniao_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_attachment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员id',
  `filename` char(100) NOT NULL DEFAULT '' COMMENT '文件名',
  `filetype` char(20) NOT NULL DEFAULT '' COMMENT '文件类型',
  `filesize` int(8) NOT NULL DEFAULT '0' COMMENT '文件大小',
  `path` char(100) NOT NULL DEFAULT '' COMMENT '文件路径',
  `width` int(10) NOT NULL DEFAULT '0' COMMENT '图片宽度',
  `height` int(10) NOT NULL DEFAULT '0' COMMENT '图片高度',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '信息ID',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `path` (`path`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=121691 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='网站附件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_about`
--

DROP TABLE IF EXISTS `huoniao_business_about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_about` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `body` text NOT NULL COMMENT '内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家介绍';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_addr`
--

DROP TABLE IF EXISTS `huoniao_business_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_addr` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_albums`
--

DROP TABLE IF EXISTS `huoniao_business_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_albums` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `litpic` varchar(100) NOT NULL DEFAULT '' COMMENT '图片地址',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `face` tinyint(1) NOT NULL DEFAULT '0' COMMENT '封面',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家相册';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_albums_type`
--

DROP TABLE IF EXISTS `huoniao_business_albums_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_albums_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `typename` char(20) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `typename` (`typename`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家相册分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_authattr`
--

DROP TABLE IF EXISTS `huoniao_business_authattr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_authattr` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `jc` char(5) NOT NULL DEFAULT '' COMMENT '简称',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家认证属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_comment`
--

DROP TABLE IF EXISTS `huoniao_business_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '商家ID',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `reply` text NOT NULL COMMENT '回复内容',
  `rtime` int(10) NOT NULL DEFAULT '0' COMMENT '回复时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`bid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_diancan_list`
--

DROP TABLE IF EXISTS `huoniao_business_diancan_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_diancan_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '商品名称',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '商品分类',
  `label` varchar(50) NOT NULL DEFAULT '' COMMENT '标签',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `descript` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `is_nature` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启商品属性',
  `nature` text NOT NULL COMMENT '商品属性',
  `pics` text NOT NULL COMMENT '商品图集',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `price` (`price`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家点餐商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_diancan_order`
--

DROP TABLE IF EXISTS `huoniao_business_diancan_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_diancan_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `table` char(15) NOT NULL DEFAULT '0' COMMENT '桌号',
  `people` int(10) NOT NULL DEFAULT '0' COMMENT '人数',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `fids` varchar(255) NOT NULL DEFAULT '' COMMENT '商品ID集合',
  `food` text NOT NULL COMMENT '商品内容',
  `paytype` varchar(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `priceinfo` text NOT NULL COMMENT '价格明细',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `confirmdate` int(10) NOT NULL DEFAULT '0' COMMENT '商家确认时间',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `print_dataid` varchar(50) NOT NULL DEFAULT '' COMMENT '打印成功接口ID',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `fids` (`fids`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家点餐订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_diancan_type`
--

DROP TABLE IF EXISTS `huoniao_business_diancan_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_diancan_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sid` (`uid`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家点餐商品分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_dingzuo_order`
--

DROP TABLE IF EXISTS `huoniao_business_dingzuo_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_dingzuo_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ordernum` varchar(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `timearea` int(10) NOT NULL DEFAULT '0' COMMENT '时间段',
  `time` int(10) NOT NULL DEFAULT '0' COMMENT '预定时间',
  `people` int(4) NOT NULL DEFAULT '0' COMMENT '人数',
  `table` int(10) NOT NULL DEFAULT '0' COMMENT '桌位id',
  `baofang` smallint(1) NOT NULL DEFAULT '0' COMMENT '包房',
  `baofang_only` smallint(1) NOT NULL DEFAULT '0' COMMENT '仅限包房',
  `name` char(15) NOT NULL DEFAULT '' COMMENT '联系人',
  `sex` smallint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `contact` char(15) NOT NULL DEFAULT '' COMMENT '联系方式',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态 0:待确认 1:已确认 2:已取消',
  `cancel_bec` char(60) NOT NULL DEFAULT '' COMMENT '取消原因',
  `cancel_date` int(10) NOT NULL DEFAULT '0' COMMENT '取消时间',
  `cancel_adm` smallint(1) NOT NULL DEFAULT '0' COMMENT '取消操作人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家订座订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_dingzuo_table`
--

DROP TABLE IF EXISTS `huoniao_business_dingzuo_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_dingzuo_table` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `min` tinyint(2) NOT NULL DEFAULT '0' COMMENT '最少人数',
  `max` tinyint(2) NOT NULL DEFAULT '0' COMMENT '最多人数',
  `code` char(10) NOT NULL DEFAULT '' COMMENT '代码',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家订座-桌位配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_dingzuo_time`
--

DROP TABLE IF EXISTS `huoniao_business_dingzuo_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_dingzuo_time` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_list`
--

DROP TABLE IF EXISTS `huoniao_business_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '店铺名称',
  `logo` varchar(100) NOT NULL DEFAULT '' COMMENT '店铺LOGO',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '经营品类',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '地图经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '地图纬度',
  `wechatname` varchar(50) NOT NULL DEFAULT '' COMMENT '微信公众号',
  `wechatcode` varchar(100) NOT NULL DEFAULT '' COMMENT '微信号',
  `wechatqr` varchar(100) NOT NULL DEFAULT '' COMMENT '微信二维码',
  `tel` varchar(50) NOT NULL DEFAULT '' COMMENT '联系电话',
  `qq` varchar(50) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `banner` text NOT NULL COMMENT 'banner广告图',
  `pics` text NOT NULL COMMENT '图集',
  `jingying` varchar(100) NOT NULL DEFAULT '' COMMENT '经营许可证',
  `certify` text NOT NULL COMMENT '其他证明文件',
  `opentime` varchar(100) NOT NULL DEFAULT '' COMMENT '营业时间',
  `amount` varchar(100) NOT NULL DEFAULT '' COMMENT '人均消费',
  `parking` varchar(100) NOT NULL DEFAULT '' COMMENT '停车位',
  `authattr` varchar(255) NOT NULL DEFAULT '' COMMENT '认证属性',
  `wifi` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否提供wifi',
  `wifiname` varchar(100) NOT NULL DEFAULT '' COMMENT 'wifi名称',
  `wifipasswd` varchar(100) NOT NULL DEFAULT '' COMMENT 'wifi密码',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '申请时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `stateinfo` text NOT NULL COMMENT '审核备注',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '姓名',
  `areaCode` varchar(10) NOT NULL DEFAULT '' COMMENT '手机区号',
  `phone` varchar(50) NOT NULL DEFAULT '' COMMENT '手机号码',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `cardnum` varchar(18) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `company` varchar(100) NOT NULL DEFAULT '' COMMENT '公司名称',
  `licensenum` varchar(50) NOT NULL DEFAULT '' COMMENT '营业执照号码',
  `license` varchar(100) NOT NULL DEFAULT '' COMMENT '营业执照',
  `accounts` varchar(100) NOT NULL DEFAULT '' COMMENT '开启许可证',
  `cardfront` varchar(100) NOT NULL DEFAULT '' COMMENT '身份证正面',
  `cardbehind` varchar(100) NOT NULL DEFAULT '' COMMENT '身份证背面',
  `body` text NOT NULL COMMENT '店铺详情',
  `diancan_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '点餐状态',
  `diancan_tableware_open` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否开启餐具费',
  `diancan_tableware_price` int(2) NOT NULL DEFAULT '0' COMMENT '餐具费',
  `dingzuo_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '订座状态',
  `dingzuo_advance_state` smallint(1) DEFAULT '0' COMMENT '订座是否开启提前预定',
  `dingzuo_advance_type` smallint(1) DEFAULT '0' COMMENT '订座提前预定时间类型',
  `dingzuo_advance_value` int(4) NOT NULL DEFAULT '0' COMMENT '订座提前预定时间值',
  `dingzuo_min_people` int(2) NOT NULL DEFAULT '0' COMMENT '最少预定人数',
  `dingzuo_baofang_open` smallint(1) NOT NULL DEFAULT '0' COMMENT '订座包房',
  `dingzuo_baofang_min` int(2) NOT NULL DEFAULT '0' COMMENT '订座包房最少人数',
  `paidui_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '排队状态',
  `maidan_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '买单状态',
  `maidan_youhui_open` smallint(1) NOT NULL DEFAULT '0' COMMENT '买单优惠',
  `maidan_youhui_value` int(2) NOT NULL DEFAULT '0' COMMENT '买单优惠比例',
  `maidan_youhui_limit` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠限制条件',
  `bind_print` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启打印机',
  `print_config` text NOT NULL COMMENT '用户ID',
  `print_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '打印机状态',
  `paidui_juli_limit` int(2) NOT NULL DEFAULT '0' COMMENT '距离限制',
  `paidui_oncetime` int(2) NOT NULL DEFAULT '60' COMMENT '平均吃饭时长',
  `paidui_overdue` char(60) NOT NULL DEFAULT '' COMMENT ' 过号处理',
  `touch_skin` varchar(50) NOT NULL DEFAULT '' COMMENT '移动端模板',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商家类型 1:免费2:企业',
  `expired` int(10) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `landmark` char(30) NOT NULL DEFAULT '' COMMENT '地标',
  `bind_module` varchar(255) NOT NULL DEFAULT '' COMMENT '开启的模块',
  `circle` char(10) NOT NULL DEFAULT '' COMMENT '所在商圈',
  `weeks` varchar(15) NOT NULL DEFAULT '' COMMENT '营业星期',
  `video` text COMMENT '视频',
  `video_pic` char(50) NOT NULL DEFAULT '' COMMENT '视频封面图',
  `qj_type` smallint(1) NOT NULL DEFAULT '0' COMMENT '全景类型0:图片1:url',
  `qj_file` text COMMENT '全景内容',
  `custom_nav` text COMMENT '自定义导航',
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT '特色标签',
  `expired_notify_day` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一天提醒',
  `expired_notify_week` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一周提醒',
  `expired_notify_month` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一月提醒',
  `tag_shop` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺标签',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `mappic` varchar(100) NOT NULL DEFAULT '' COMMENT '地图截图',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `lng` (`lng`) USING BTREE,
  KEY `lat` (`lat`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `pubdate` (`pubdate`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_maidan_order`
--

DROP TABLE IF EXISTS `huoniao_business_maidan_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_maidan_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ordernum` varchar(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `amount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `amount_alone` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '不参与优惠',
  `youhui_value` int(2) NOT NULL DEFAULT '0' COMMENT '折扣',
  `payamount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '应付金额',
  `balance` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '使用的余额',
  `paytype` char(20) NOT NULL DEFAULT '' COMMENT '付款方式',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家买单订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_menu`
--

DROP TABLE IF EXISTS `huoniao_business_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '标题',
  `jump` smallint(1) NOT NULL DEFAULT '0' COMMENT '跳转',
  `jump_url` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转url',
  `body` text NOT NULL COMMENT '内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家自定义导航';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_news`
--

DROP TABLE IF EXISTS `huoniao_business_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `body` text NOT NULL COMMENT '内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=286 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家动态';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_news_type`
--

DROP TABLE IF EXISTS `huoniao_business_news_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_news_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `typename` char(20) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `typename` (`typename`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家动态分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_noticelist`
--

DROP TABLE IF EXISTS `huoniao_business_noticelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_noticelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `redirecturl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `litpic` char(20) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_order`
--

DROP TABLE IF EXISTS `huoniao_business_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bid` int(10) NOT NULL DEFAULT '0' COMMENT '商家ID',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `totalprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `offer` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠金额',
  `balance` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付',
  `paytype` varchar(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `ordertype` char(15) NOT NULL DEFAULT '' COMMENT '入驻类型',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '入驻类型',
  `time` int(2) NOT NULL DEFAULT '0' COMMENT '时间',
  `time_type` char(5) NOT NULL DEFAULT '' COMMENT '时间类型',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `bid` (`bid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=388 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_order_module`
--

DROP TABLE IF EXISTS `huoniao_business_order_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_order_module` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `oid` int(10) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `module` varchar(50) NOT NULL DEFAULT '' COMMENT '模块标识',
  `unitprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `count` smallint(5) NOT NULL DEFAULT '0' COMMENT '几年',
  `expired` int(10) NOT NULL DEFAULT '0' COMMENT '到期时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `oid` (`oid`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `expired` (`expired`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=394 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家订单模块';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_paidui_order`
--

DROP TABLE IF EXISTS `huoniao_business_paidui_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_paidui_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordernum` varchar(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '桌位类别',
  `table` char(15) NOT NULL DEFAULT '' COMMENT '排队编号',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `people` int(4) NOT NULL DEFAULT '0' COMMENT '人数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态 0:排队中 1:结束 2:取消',
  `cancel_bec` char(60) NOT NULL DEFAULT '' COMMENT '取消原因',
  `cancel_date` int(10) NOT NULL DEFAULT '0' COMMENT '取消时间',
  `cancel_adm` smallint(1) NOT NULL DEFAULT '0' COMMENT '取消操作人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家排队订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_panor`
--

DROP TABLE IF EXISTS `huoniao_business_panor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_panor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '视频标题',
  `litpic` varchar(100) NOT NULL DEFAULT '' COMMENT '图片地址',
  `panor` varchar(255) NOT NULL DEFAULT '' COMMENT '全景地址',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `typeid` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家全景';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_type`
--

DROP TABLE IF EXISTS `huoniao_business_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商家分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_business_video`
--

DROP TABLE IF EXISTS `huoniao_business_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_business_video` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '视频标题',
  `litpic` varchar(100) NOT NULL DEFAULT '' COMMENT '图片地址',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频地址',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `typeid` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家视频';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_callrecord`
--

DROP TABLE IF EXISTS `huoniao_callrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_callrecord` (
  `caller` varchar(11) NOT NULL,
  `callee` varchar(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_activity`
--

DROP TABLE IF EXISTS `huoniao_dating_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_activity` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '活动标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `btime` char(30) NOT NULL DEFAULT '' COMMENT '活动时间',
  `deadline` char(10) NOT NULL DEFAULT '0' COMMENT '报名截止时间',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '活动地址',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `pcount` char(100) NOT NULL DEFAULT '' COMMENT '人数限制',
  `money` char(100) NOT NULL DEFAULT '' COMMENT '活动费用',
  `else` char(100) NOT NULL DEFAULT '' COMMENT '特别要求',
  `content` text NOT NULL COMMENT '活动详情',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_activity_take`
--

DROP TABLE IF EXISTS `huoniao_dating_activity_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_activity_take` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '活动ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '报名时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='活动参与会员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_album`
--

DROP TABLE IF EXISTS `huoniao_dating_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '系统会员ID',
  `atype` int(10) NOT NULL DEFAULT '0' COMMENT '相册分类',
  `path` char(100) NOT NULL DEFAULT '' COMMENT '照片地址',
  `note` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '上传时间',
  `zan` int(10) NOT NULL DEFAULT '0' COMMENT '赞',
  `zan_user` text NOT NULL COMMENT '赞过的用户',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `atype` (`atype`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友相册';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_album_review`
--

DROP TABLE IF EXISTS `huoniao_dating_album_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_album_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '相册ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `content` char(150) NOT NULL DEFAULT '' COMMENT '评论内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='相册评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_album_type`
--

DROP TABLE IF EXISTS `huoniao_dating_album_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_album_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '分类名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友相册分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_apply`
--

DROP TABLE IF EXISTS `huoniao_dating_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_apply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ufrom` int(10) NOT NULL DEFAULT '0' COMMENT '申请人id:交友id',
  `uto` int(10) NOT NULL DEFAULT '0' COMMENT '门店id',
  `ufor` int(10) NOT NULL DEFAULT '0' COMMENT '目标用户',
  `realname` char(20) NOT NULL DEFAULT '' COMMENT '姓名',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '电话',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `money` int(10) NOT NULL DEFAULT '0' COMMENT '月薪范围',
  `city` int(10) NOT NULL DEFAULT '0' COMMENT '城市id',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态0:待联系1:已联系',
  `dotime` int(10) NOT NULL DEFAULT '0' COMMENT '处理时间',
  `read` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友门店申请服务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_chat`
--

DROP TABLE IF EXISTS `huoniao_dating_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_chat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '对话第一条',
  `from` int(10) NOT NULL DEFAULT '0' COMMENT '发送人',
  `to` int(10) NOT NULL DEFAULT '0' COMMENT '接收人',
  `msg` text NOT NULL COMMENT '内容',
  `date` char(20) NOT NULL DEFAULT '' COMMENT '时间',
  `isread` smallint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  `delfrom` smallint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `delto` smallint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友即时聊天';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_circle`
--

DROP TABLE IF EXISTS `huoniao_dating_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_circle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型 1:说说,2:照片,3:视频',
  `content` text NOT NULL COMMENT '文字内容',
  `file` text NOT NULL COMMENT '附件',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `zan` int(10) NOT NULL DEFAULT '0' COMMENT '赞',
  `zan_user` text NOT NULL COMMENT '赞过的用户',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友动态';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_coverbg`
--

DROP TABLE IF EXISTS `huoniao_dating_coverbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_coverbg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(30) NOT NULL DEFAULT '' COMMENT '标题',
  `litpic` char(30) NOT NULL DEFAULT '' COMMENT '缩略图',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `litpic` (`litpic`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友会员封面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_gift`
--

DROP TABLE IF EXISTS `huoniao_dating_gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_gift` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '分类',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '标题',
  `litpic` char(30) NOT NULL DEFAULT '' COMMENT '缩略图',
  `price` int(10) NOT NULL DEFAULT '0' COMMENT '价格',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `litpic` (`litpic`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `rec` (`weight`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友礼物';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_gift_put`
--

DROP TABLE IF EXISTS `huoniao_dating_gift_put`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_gift_put` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ufrom` int(10) NOT NULL DEFAULT '0' COMMENT '发起人',
  `uto` int(10) NOT NULL DEFAULT '0' COMMENT '被发起人',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `read` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  `gid` int(10) NOT NULL DEFAULT '0' COMMENT '礼物id',
  `price` int(10) NOT NULL DEFAULT '0' COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友礼物';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_item`
--

DROP TABLE IF EXISTS `huoniao_dating_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_item` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `hide` tinyint(1) NOT NULL DEFAULT '0' COMMENT '隐藏',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=462 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友固定字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_lead`
--

DROP TABLE IF EXISTS `huoniao_dating_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_lead` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ufrom` int(10) NOT NULL DEFAULT '0' COMMENT '发起人id',
  `uto` int(10) NOT NULL DEFAULT '0' COMMENT '被牵线人id',
  `hnid` int(10) NOT NULL DEFAULT '0' COMMENT '红娘id',
  `pubdate` int(10) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态1:牵线中2:成功3:失败',
  `admin` int(10) NOT NULL DEFAULT '0' COMMENT '操作人',
  `dotime` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `new1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '新收到的牵线',
  `new2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '新成功的牵线',
  `new3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '新失败的牵线',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友牵线';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_level`
--

DROP TABLE IF EXISTS `huoniao_dating_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_level` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '等级名称',
  `cost` float(8,2) NOT NULL COMMENT '费用',
  `month` int(2) NOT NULL DEFAULT '0' COMMENT '月数',
  `privilege` text NOT NULL COMMENT '特权设置',
  `icon` char(60) NOT NULL DEFAULT '' COMMENT '图标',
  `tag` char(10) NOT NULL DEFAULT '' COMMENT '显示折扣',
  `def` tinyint(1) NOT NULL DEFAULT '0' COMMENT '普通用户',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友会员等级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_member`
--

DROP TABLE IF EXISTS `huoniao_dating_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_member` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型0:用户1:红娘2:门店',
  `entrust` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否委托红娘',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属会员',
  `fromage` int(2) NOT NULL DEFAULT '18' COMMENT '对象最小年龄',
  `toage` int(2) NOT NULL DEFAULT '22' COMMENT '对象最大年龄',
  `tags` char(255) NOT NULL DEFAULT '' COMMENT '标签',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `addrid_locktime` int(10) NOT NULL DEFAULT '0' COMMENT '区域地锁定时间',
  `sign` char(100) NOT NULL DEFAULT '' COMMENT '个性签名',
  `marriage` int(10) NOT NULL DEFAULT '0' COMMENT '婚姻状况',
  `child` int(10) NOT NULL DEFAULT '0' COMMENT '子女情况',
  `height` int(3) NOT NULL DEFAULT '0' COMMENT '身高',
  `height_locktime` int(10) NOT NULL DEFAULT '0' COMMENT '身高锁定时间',
  `bodytype` int(10) NOT NULL DEFAULT '0' COMMENT '体型',
  `housetag` int(10) NOT NULL DEFAULT '0' COMMENT '居住情况',
  `workstatus` int(10) NOT NULL DEFAULT '0' COMMENT '工作状态',
  `income` int(10) NOT NULL DEFAULT '0' COMMENT '收入',
  `income_locktime` int(10) DEFAULT '0' COMMENT '收入锁定时间',
  `education` int(10) NOT NULL DEFAULT '0' COMMENT '学历',
  `education_locktime` int(10) NOT NULL DEFAULT '0' COMMENT '学历锁定时间',
  `smoke` int(10) NOT NULL DEFAULT '0' COMMENT '吸烟',
  `drink` int(10) NOT NULL DEFAULT '0' COMMENT '饮酒',
  `workandrest` int(10) NOT NULL DEFAULT '0' COMMENT '作息情况',
  `cartag` int(10) NOT NULL DEFAULT '0' COMMENT '购车情况',
  `dfage` int(2) NOT NULL DEFAULT '0' COMMENT '择偶年龄范围',
  `dtage` int(2) NOT NULL DEFAULT '0' COMMENT '择偶年龄范围',
  `dfheight` int(3) NOT NULL DEFAULT '0' COMMENT '择偶身高范围',
  `dtheight` int(3) NOT NULL DEFAULT '0' COMMENT '择偶身高范围',
  `daddr` int(10) NOT NULL DEFAULT '0' COMMENT '择偶地区',
  `dmarriage` int(10) NOT NULL DEFAULT '0' COMMENT '婚姻情况',
  `dhousetag` int(10) NOT NULL DEFAULT '0' COMMENT '居住情况',
  `deducation` int(10) NOT NULL DEFAULT '0' COMMENT '学历',
  `dincome` int(10) NOT NULL DEFAULT '0' COMMENT '收入情况',
  `jointime` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  `numid` int(10) unsigned NOT NULL COMMENT 'id编号',
  `nickname` char(20) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `sex_lock` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别锁定',
  `birthday` int(10) NOT NULL DEFAULT '0' COMMENT '出生日期',
  `birthday_lock` tinyint(1) NOT NULL DEFAULT '0' COMMENT '禁止修改生日',
  `interests` varchar(255) NOT NULL DEFAULT '' COMMENT '兴趣爱好',
  `hometown` int(10) NOT NULL DEFAULT '0' COMMENT '家乡',
  `household` int(10) NOT NULL DEFAULT '0' COMMENT '户口',
  `nation` int(4) NOT NULL DEFAULT '0' COMMENT '民族',
  `zodiac` char(10) NOT NULL DEFAULT '' COMMENT '属相',
  `constellation` char(10) NOT NULL DEFAULT '' COMMENT '星座',
  `bloodtype` char(10) NOT NULL DEFAULT '' COMMENT '血型',
  `bodyweight` int(10) NOT NULL DEFAULT '0' COMMENT '体重',
  `looks` tinyint(2) NOT NULL DEFAULT '0' COMMENT '相貌自评',
  `religion` int(10) NOT NULL DEFAULT '0' COMMENT '宗教信仰',
  `school` char(60) NOT NULL DEFAULT '0' COMMENT '毕业院校',
  `major` int(10) NOT NULL DEFAULT '0' COMMENT '所学专业',
  `duties` int(10) NOT NULL DEFAULT '0' COMMENT '职业职务',
  `nature` int(10) NOT NULL DEFAULT '0' COMMENT '公司性质',
  `industry` int(10) NOT NULL DEFAULT '0' COMMENT '公司行业',
  `language` char(30) NOT NULL DEFAULT '' COMMENT '掌握语言',
  `familyrank` int(4) NOT NULL DEFAULT '0' COMMENT '家庭排行',
  `parentstatus` int(10) NOT NULL DEFAULT '0' COMMENT '父母情况',
  `fatherwork` int(10) NOT NULL DEFAULT '0' COMMENT '父亲工作',
  `motherwork` int(10) NOT NULL DEFAULT '0' COMMENT '母亲工作',
  `parenteconomy` int(10) NOT NULL DEFAULT '0' COMMENT '父母经济',
  `parentinsurance` int(10) NOT NULL DEFAULT '0' COMMENT '父母医保',
  `marriagetime` int(10) NOT NULL DEFAULT '0' COMMENT '何时结婚',
  `datetype` int(10) NOT NULL DEFAULT '0' COMMENT '约会方式',
  `othervalue` int(10) NOT NULL DEFAULT '0' COMMENT '希望对方看重',
  `weddingtype` int(10) NOT NULL DEFAULT '0' COMMENT '婚礼形式',
  `livetogeparent` int(10) NOT NULL DEFAULT '0' COMMENT '愿与对方父母同住',
  `givebaby` int(10) NOT NULL DEFAULT '0' COMMENT '是否想要孩子',
  `cooking` int(10) NOT NULL DEFAULT '0' COMMENT '厨艺状况',
  `housework` int(10) NOT NULL DEFAULT '0' COMMENT '厨艺状况',
  `profile` varchar(255) NOT NULL DEFAULT '' COMMENT '自我介绍',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '维度',
  `phone` char(20) NOT NULL DEFAULT '' COMMENT '电话',
  `phoneCheck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '手机认证',
  `qq` char(15) NOT NULL DEFAULT '' COMMENT 'QQ',
  `wechat` char(30) NOT NULL DEFAULT '' COMMENT '微信号',
  `tel` char(15) NOT NULL DEFAULT '' COMMENT '电话',
  `bus` varchar(255) NOT NULL DEFAULT '' COMMENT '公交',
  `dfeducation` int(10) NOT NULL DEFAULT '0' COMMENT '最低学历',
  `dteducation` int(10) NOT NULL DEFAULT '0' COMMENT '最高学历',
  `dfincome` int(10) NOT NULL DEFAULT '0' COMMENT '最低月收入',
  `dtincome` int(10) NOT NULL DEFAULT '0' COMMENT '最高收入',
  `dchild` int(10) NOT NULL DEFAULT '0' COMMENT '子女情况',
  `dateswitch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '交友开关 1:关闭',
  `my_voice` varchar(255) NOT NULL DEFAULT '' COMMENT '语音介绍',
  `my_voice_state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '语音认证状态',
  `my_video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频认证',
  `my_video_state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '视频认证状态',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
  `level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '会员等级',
  `expired` int(10) NOT NULL DEFAULT '0' COMMENT '过期时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 1:正常',
  `case` int(10) NOT NULL DEFAULT '0' COMMENT '成功案例',
  `year` int(2) NOT NULL DEFAULT '0' COMMENT '经验',
  `company` int(11) NOT NULL DEFAULT '0' COMMENT '所属门店',
  `honor` varchar(255) NOT NULL COMMENT '荣誉',
  `advice` varchar(255) NOT NULL DEFAULT '' COMMENT '婚恋建议',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '地址',
  `like` int(10) NOT NULL DEFAULT '0' COMMENT '喜欢数',
  `activedate` int(10) NOT NULL DEFAULT '0' COMMENT '最后活跃时间',
  `money` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `key` smallint(2) NOT NULL DEFAULT '0' COMMENT '钥匙',
  `key_buy` smallint(2) NOT NULL DEFAULT '0' COMMENT '购买的聊天钥匙',
  `lead` int(4) NOT NULL DEFAULT '0' COMMENT '牵线次数',
  `leadExpired` int(10) NOT NULL DEFAULT '0' COMMENT '牵线过期时间',
  `dayinit` char(8) NOT NULL DEFAULT '' COMMENT '每日更新',
  `visit_circle_date` int(10) NOT NULL DEFAULT '0' COMMENT '访问动态时间',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `fromage` (`fromage`) USING BTREE,
  KEY `toage` (`toage`) USING BTREE,
  KEY `tags` (`tags`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友会员管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_money`
--

DROP TABLE IF EXISTS `huoniao_dating_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_money` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '交友用户id',
  `fuid` int(10) NOT NULL DEFAULT '0' COMMENT '来源用户(红娘下属会员)',
  `puid` int(10) NOT NULL DEFAULT '0' COMMENT '付费用户id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型1:收入0:支出',
  `category` char(10) NOT NULL DEFAULT '' COMMENT '类别',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '标题',
  `oid` int(10) NOT NULL DEFAULT '0' COMMENT '订单id',
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单编号',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `extRatio` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '提成比例',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  `extnew0` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  `extnew1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  `extnew2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友余额收入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_order`
--

DROP TABLE IF EXISTS `huoniao_dating_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型0:升级会员,1:充值金币,2:购买牵线,3:购买钥匙,4:牵线成功,5:收礼物',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `orderdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytype` char(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `orderstate` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `payprice` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '支付的费用',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '数量,时长',
  `totalPrice` float(8,2) DEFAULT '0.00' COMMENT '总价',
  `param` text NOT NULL COMMENT '更多参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='交友订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_review`
--

DROP TABLE IF EXISTS `huoniao_dating_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ufrom` int(10) NOT NULL DEFAULT '0' COMMENT '发信人',
  `uto` int(10) NOT NULL DEFAULT '0' COMMENT '收信人',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ufrom` (`ufrom`) USING BTREE,
  KEY `uto` (`uto`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友私信';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_review_list`
--

DROP TABLE IF EXISTS `huoniao_dating_review_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_review_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '私信ID',
  `from` int(10) NOT NULL DEFAULT '0' COMMENT '发送人',
  `to` int(10) NOT NULL DEFAULT '0' COMMENT '接收人',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '私信内容',
  `isread` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已读',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发送时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE,
  KEY `from` (`from`) USING BTREE,
  KEY `to` (`to`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='私信对话';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_skill`
--

DROP TABLE IF EXISTS `huoniao_dating_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_skill` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友技能';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_story`
--

DROP TABLE IF EXISTS `huoniao_dating_story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_story` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '另一半用户ID',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '合影',
  `process` smallint(1) NOT NULL DEFAULT '0' COMMENT '甜蜜进程',
  `kdate` int(10) NOT NULL DEFAULT '0' COMMENT '确定关系时间',
  `tags` char(50) NOT NULL DEFAULT '' COMMENT '标签',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '故事标题',
  `content` text NOT NULL COMMENT '故事内容',
  `pics` text NOT NULL COMMENT '图集',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '审核状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fid` (`fid`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='成功故事';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_tags`
--

DROP TABLE IF EXISTS `huoniao_dating_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_tags` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_dating_visit`
--

DROP TABLE IF EXISTS `huoniao_dating_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_dating_visit` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ufrom` int(10) NOT NULL DEFAULT '0' COMMENT '发起人',
  `uto` int(10) NOT NULL DEFAULT '0' COMMENT '被发起人',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型1:看过2:关注3:打招呼10:隐身11:隐藏动态12:隐藏相册',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `readfrom` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已读',
  `readto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已读',
  `delfrom` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `delto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ufrom` (`ufrom`) USING BTREE,
  KEY `uto` (`uto`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友人气';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_datingaddr`
--

DROP TABLE IF EXISTS `huoniao_datingaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_datingaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='交友地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_domain`
--

DROP TABLE IF EXISTS `huoniao_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_domain` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `domain` char(50) NOT NULL DEFAULT '' COMMENT '域名',
  `module` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `part` char(30) NOT NULL DEFAULT '' COMMENT '栏目',
  `iid` int(10) DEFAULT '0' COMMENT '信息ID',
  `expires` int(10) DEFAULT '0' COMMENT '过期时间',
  `note` text COMMENT '过期提示',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `refund` text COMMENT '失败原因',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `domain` (`domain`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `part` (`part`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=296 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='域名管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_failedlogin`
--

DROP TABLE IF EXISTS `huoniao_failedlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_failedlogin` (
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `count` smallint(1) NOT NULL DEFAULT '0' COMMENT '错误次数',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='登录错误次数记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_360qj`
--

DROP TABLE IF EXISTS `huoniao_house_360qj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_360qj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '全景标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `typeid` smallint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `file` char(255) NOT NULL DEFAULT '' COMMENT '文件地址',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`loupan`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='楼盘全景';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_album`
--

DROP TABLE IF EXISTS `huoniao_house_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `action` char(30) NOT NULL DEFAULT '' COMMENT '类型',
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '所属楼盘',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1493 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房源相册';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_apartment`
--

DROP TABLE IF EXISTS `huoniao_house_apartment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_apartment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `action` char(30) NOT NULL DEFAULT '' COMMENT '类型',
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '户型名',
  `room` smallint(2) NOT NULL DEFAULT '0' COMMENT '室',
  `hall` smallint(2) NOT NULL DEFAULT '0' COMMENT '厅',
  `guard` smallint(2) NOT NULL DEFAULT '0' COMMENT '卫',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `area` int(5) NOT NULL DEFAULT '0' COMMENT '面积',
  `direction` int(10) NOT NULL DEFAULT '0' COMMENT '朝向',
  `high` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '层高',
  `note` char(255) NOT NULL COMMENT '户型解析',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `price` float(5,1) NOT NULL DEFAULT '0.0' COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=204 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='户型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_booking`
--

DROP TABLE IF EXISTS `huoniao_house_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_booking` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `loupan` char(100) NOT NULL DEFAULT '' COMMENT '意向楼盘',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '预算价格',
  `huxing` char(100) NOT NULL DEFAULT '' COMMENT '户型',
  `name` char(50) NOT NULL DEFAULT '' COMMENT '联系人',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '备注',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '发布IP',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房管家预约';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_cf`
--

DROP TABLE IF EXISTS `huoniao_house_cf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_cf` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '供求',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `nearby` char(60) NOT NULL DEFAULT '' COMMENT '靠近',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `protype` int(10) NOT NULL DEFAULT '0' COMMENT '类型',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `transfer` int(5) NOT NULL DEFAULT '0' COMMENT '转让费',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '房源介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `cenggao` float(3,1) DEFAULT '0.0' COMMENT '层高',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `proprice` char(100) NOT NULL DEFAULT '0.0' COMMENT '物业费',
  `paytype` int(10) NOT NULL DEFAULT '0' COMMENT '付款方式',
  `mintime` char(20) DEFAULT '' COMMENT '起租期',
  `bno` int(3) NOT NULL DEFAULT '0' COMMENT '第几层',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '共几层',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `floortype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '楼层类型:1跃层,0单层',
  `floorspr` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '跃层数',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `wuye_in` tinyint(1) NOT NULL DEFAULT '0' COMMENT '价格是否包含物业费0:未知,1不含,2包含',
  `resource` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  `externalno` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `usertype` (`usertype`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='厂房/仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_community`
--

DROP TABLE IF EXISTS `huoniao_house_community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_community` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '小区名称',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域板块',
  `addr` char(100) NOT NULL DEFAULT '' COMMENT '地址',
  `longitude` char(50) NOT NULL DEFAULT '' COMMENT '经度',
  `latitude` char(50) NOT NULL DEFAULT '' COMMENT '纬度',
  `subway` char(100) NOT NULL DEFAULT '' COMMENT '地铁',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '图片',
  `tags` char(100) NOT NULL DEFAULT '' COMMENT '小区标签',
  `post` char(10) NOT NULL DEFAULT '0' COMMENT '邮编',
  `buildage` tinyint(3) NOT NULL DEFAULT '0' COMMENT '产权年限',
  `protype` char(30) NOT NULL DEFAULT '' COMMENT '物业类型',
  `buildtype` char(50) NOT NULL DEFAULT '' COMMENT '建筑类型',
  `property` char(30) NOT NULL DEFAULT '' COMMENT '物业公司',
  `proprice` char(100) NOT NULL DEFAULT '' COMMENT '物业费',
  `protel` char(20) NOT NULL DEFAULT '' COMMENT '物业电话',
  `proaddr` char(50) NOT NULL DEFAULT '' COMMENT '物业办公地点',
  `water` char(50) NOT NULL DEFAULT '' COMMENT '供水',
  `heat` char(50) NOT NULL DEFAULT '' COMMENT '供暖',
  `power` char(100) NOT NULL DEFAULT '' COMMENT '供电',
  `gas` char(50) NOT NULL DEFAULT '' COMMENT '燃气',
  `newsletter` char(100) NOT NULL DEFAULT '' COMMENT '通讯设备',
  `elevator` char(100) NOT NULL DEFAULT '' COMMENT '电梯',
  `safe` char(100) NOT NULL DEFAULT '' COMMENT '安全管理',
  `clean` char(50) NOT NULL DEFAULT '' COMMENT '清洁',
  `entrance` char(50) NOT NULL DEFAULT '' COMMENT '小区入口',
  `opendate` int(10) NOT NULL DEFAULT '0' COMMENT '竣工时间',
  `kfs` char(50) NOT NULL DEFAULT '' COMMENT '开发商',
  `price` float(8,0) NOT NULL DEFAULT '0' COMMENT '报价',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问ID',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示状态',
  `note` text NOT NULL COMMENT '小区概述',
  `planhouse` int(10) NOT NULL DEFAULT '0' COMMENT '规划户数',
  `parknum` char(100) NOT NULL DEFAULT '' COMMENT '车位数',
  `rongji` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '容积率',
  `planarea` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '占地面积',
  `buildarea` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '建筑面积',
  `green` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '绿化率',
  `config` text NOT NULL COMMENT '周边配置',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `hot` smallint(1) NOT NULL DEFAULT '0' COMMENT '热销楼盘',
  `rec` smallint(1) NOT NULL DEFAULT '0' COMMENT '推荐楼盘',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `addr` (`addr`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='小区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_cw`
--

DROP TABLE IF EXISTS `huoniao_house_cw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_cw` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '供求',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `communityid` int(10) NOT NULL DEFAULT '0' COMMENT '小区ID',
  `community` char(60) NOT NULL DEFAULT '' COMMENT '小区',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `price` int(10) NOT NULL DEFAULT '0' COMMENT '售价',
  `paytype` int(10) NOT NULL DEFAULT '0' COMMENT '付款方式',
  `mintime` char(20) DEFAULT '' COMMENT '起租时间',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '车位介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `protype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '车位类型',
  `transfer` int(5) NOT NULL DEFAULT '0' COMMENT '转让费',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `proprice` char(100) NOT NULL DEFAULT '' COMMENT '物业费',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `wuye_in` tinyint(1) NOT NULL DEFAULT '0' COMMENT '价格是否包含物业费0:未知,1不含,2包含',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `communityid` (`communityid`),
  KEY `addrid` (`addrid`),
  KEY `address` (`address`),
  KEY `usertype` (`usertype`),
  KEY `userid` (`userid`),
  KEY `refreshSmart` (`refreshSmart`),
  KEY `refreshNext` (`refreshNext`),
  KEY `refreshFree` (`refreshFree`),
  KEY `bid_type` (`bid_type`),
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='车位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_entrust`
--

DROP TABLE IF EXISTS `huoniao_house_entrust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_entrust` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `zjuid` int(10) NOT NULL DEFAULT '0' COMMENT '中介id',
  `zjcom` int(10) NOT NULL DEFAULT '0' COMMENT '中介公司',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '委托类型',
  `address` char(120) NOT NULL DEFAULT '' COMMENT '地址',
  `doornumber` char(20) DEFAULT '' COMMENT '门牌号',
  `area` float(6,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '报价',
  `transfer` int(5) NOT NULL DEFAULT '0' COMMENT '转让费',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `note` char(60) DEFAULT '' COMMENT '备注',
  `del1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '用户删除',
  `del2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '中介删除',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `zjuid` (`zjuid`),
  KEY `zjcom` (`zjcom`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='房产房源委托';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_faq`
--

DROP TABLE IF EXISTS `huoniao_house_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(200) NOT NULL DEFAULT '' COMMENT '信息标题',
  `body` text NOT NULL COMMENT '内容',
  `people` char(10) NOT NULL DEFAULT '' COMMENT '联系人',
  `phone` char(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览',
  `state` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房产问答';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_faqtype`
--

DROP TABLE IF EXISTS `huoniao_house_faqtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_faqtype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房产问答分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_gw`
--

DROP TABLE IF EXISTS `huoniao_house_gw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_gw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属开发商',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `stores` char(60) NOT NULL DEFAULT '' COMMENT '所在门店',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '工作区域',
  `card` char(100) NOT NULL DEFAULT '0' COMMENT '证件',
  `weight` int(10) NOT NULL COMMENT '排序',
  `state` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  `post` char(25) NOT NULL DEFAULT '' COMMENT '职位',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `stores` (`stores`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='置业顾问';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_gw_tj`
--

DROP TABLE IF EXISTS `huoniao_house_gw_tj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_gw_tj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gw` int(10) NOT NULL DEFAULT '0' COMMENT '顾问id',
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘id',
  `see` int(10) NOT NULL DEFAULT '0' COMMENT '看房次数',
  `suc` int(10) NOT NULL DEFAULT '0' COMMENT '成交次数',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='房产顾问业绩';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_industry`
--

DROP TABLE IF EXISTS `huoniao_house_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_industry` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行业分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_kfs`
--

DROP TABLE IF EXISTS `huoniao_house_kfs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_kfs` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='开发商';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_listing`
--

DROP TABLE IF EXISTS `huoniao_house_listing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_listing` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `room` smallint(2) NOT NULL DEFAULT '0' COMMENT '室',
  `hall` smallint(2) NOT NULL DEFAULT '0' COMMENT '厅',
  `guard` smallint(2) NOT NULL DEFAULT '0' COMMENT '卫',
  `area` int(5) NOT NULL DEFAULT '0' COMMENT '面积',
  `bno` char(10) NOT NULL DEFAULT '' COMMENT '楼号',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '总楼层',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `salable` int(5) NOT NULL DEFAULT '0' COMMENT '可售套数',
  `launch` int(10) NOT NULL DEFAULT '0' COMMENT '交房时间',
  `flist` text NOT NULL COMMENT '可售楼层',
  `note` text NOT NULL COMMENT '房源介绍',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新房源';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_loupan`
--

DROP TABLE IF EXISTS `huoniao_house_loupan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_loupan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '楼盘名称',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域板块',
  `addr` char(100) NOT NULL DEFAULT '' COMMENT '楼盘地址',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `subway` char(100) NOT NULL DEFAULT '' COMMENT '地铁站',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '楼盘图片',
  `bussiness` char(30) NOT NULL DEFAULT '' COMMENT '所属商圈',
  `deliverdate` char(10) NOT NULL DEFAULT '' COMMENT '预计开盘时间',
  `opendate` char(10) NOT NULL DEFAULT '' COMMENT '预计交房时间',
  `price` float(10,0) NOT NULL DEFAULT '0' COMMENT '售价',
  `ptype` smallint(1) NOT NULL DEFAULT '1' COMMENT '价格单位',
  `views` int(10) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示状态',
  `salestate` smallint(1) NOT NULL DEFAULT '0' COMMENT '销售状态',
  `hot` smallint(1) NOT NULL DEFAULT '0' COMMENT '热销楼盘',
  `rec` smallint(1) NOT NULL DEFAULT '0' COMMENT '推荐楼盘',
  `tuan` smallint(1) NOT NULL DEFAULT '0' COMMENT '开放团购',
  `tuantitle` char(30) NOT NULL DEFAULT '' COMMENT '团购标题',
  `tuanbegan` int(10) NOT NULL DEFAULT '0' COMMENT '团购开始时间',
  `tuanend` int(10) NOT NULL DEFAULT '0' COMMENT '团购结束',
  `userid` char(30) NOT NULL DEFAULT '' COMMENT '置业顾问ID',
  `investor` char(60) NOT NULL DEFAULT '' COMMENT '投资商',
  `protype` char(20) NOT NULL DEFAULT '0' COMMENT '物业类型',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '售楼处地址',
  `tel` char(20) NOT NULL DEFAULT '' COMMENT '售楼处电话',
  `worktime` char(30) NOT NULL DEFAULT '' COMMENT '售楼处服务时间',
  `note` text NOT NULL COMMENT '楼盘概述',
  `buildtype` char(60) NOT NULL DEFAULT '' COMMENT '建筑类型',
  `zhuangxiu` int(5) NOT NULL DEFAULT '0' COMMENT '装修情况',
  `buildage` int(3) NOT NULL DEFAULT '0' COMMENT '产权年限',
  `planarea` float(10,2) DEFAULT '0.00' COMMENT '规划面积',
  `buildarea` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '建筑面积',
  `planhouse` int(10) NOT NULL DEFAULT '0' COMMENT '规划户数',
  `linklocal` char(30) NOT NULL DEFAULT '' COMMENT '环线位置',
  `parknum` char(30) NOT NULL DEFAULT '' COMMENT '车位数',
  `rongji` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '容积率',
  `green` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '绿化率',
  `floor` char(200) NOT NULL DEFAULT '' COMMENT '楼层状况',
  `property` char(30) NOT NULL DEFAULT '' COMMENT '物业公司',
  `proprice` char(50) NOT NULL DEFAULT '' COMMENT '物业费',
  `config` text NOT NULL COMMENT '轨道交通',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `onsale_hx` char(60) DEFAULT '' COMMENT '在售户型',
  `existing` tinyint(1) NOT NULL DEFAULT '0' COMMENT '现房:1期房:2',
  `banner` varchar(255) DEFAULT '' COMMENT '横幅',
  `phone` char(20) NOT NULL DEFAULT '' COMMENT '售楼处电话2',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `resource` varchar(50) DEFAULT NULL,
  `externalno` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `addr` (`addr`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1449 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='楼盘';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_loupannews`
--

DROP TABLE IF EXISTS `huoniao_house_loupannews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_loupannews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loupan` int(8) NOT NULL COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1490 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='楼盘资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_loupantuan`
--

DROP TABLE IF EXISTS `huoniao_house_loupantuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_loupantuan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘ID',
  `uid` char(30) NOT NULL DEFAULT '0' COMMENT '报名会员',
  `name` char(20) NOT NULL DEFAULT '' COMMENT '联系人',
  `phone` char(15) NOT NULL DEFAULT '' COMMENT '联系方式',
  `pubdate` int(10) NOT NULL COMMENT '订阅时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='楼盘团购报名';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_loupanvideo`
--

DROP TABLE IF EXISTS `huoniao_house_loupanvideo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_loupanvideo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `loupan` int(8) NOT NULL COMMENT '所属分类',
  `litpic` char(200) NOT NULL DEFAULT '' COMMENT '缩略图',
  `videotype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '视频类型',
  `videourl` char(200) NOT NULL COMMENT '视频地址',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='楼盘视频';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_news`
--

DROP TABLE IF EXISTS `huoniao_house_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览',
  `weight` int(10) NOT NULL COMMENT '排序',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `writer` char(30) NOT NULL DEFAULT '' COMMENT '作者',
  `keyword` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(255) NOT NULL DEFAULT '' COMMENT '描述',
  `body` mediumtext NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房产资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_newstype`
--

DROP TABLE IF EXISTS `huoniao_house_newstype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_newstype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房产资讯分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_notice`
--

DROP TABLE IF EXISTS `huoniao_house_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` char(30) NOT NULL DEFAULT '' COMMENT '类型',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '订阅会员',
  `type` char(10) NOT NULL DEFAULT '0' COMMENT '号码类型',
  `name` char(20) NOT NULL DEFAULT '' COMMENT '联系人',
  `phone` char(20) NOT NULL DEFAULT '' COMMENT '联系方式',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '订阅时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='降价通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_pic`
--

DROP TABLE IF EXISTS `huoniao_house_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_pic` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` char(30) NOT NULL DEFAULT '' COMMENT '栏目',
  `aid` int(8) NOT NULL DEFAULT '0' COMMENT '信息ID',
  `picPath` varchar(255) NOT NULL DEFAULT '' COMMENT '图片路径',
  `picInfo` text COMMENT '图片注释',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=24583 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻图集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_sale`
--

DROP TABLE IF EXISTS `huoniao_house_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `communityid` int(10) NOT NULL DEFAULT '0' COMMENT '小区ID',
  `community` char(60) NOT NULL DEFAULT '' COMMENT '小区',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `unitprice` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `protype` int(10) NOT NULL DEFAULT '0' COMMENT '房屋类型',
  `room` smallint(2) NOT NULL DEFAULT '0' COMMENT '室',
  `hall` smallint(2) NOT NULL DEFAULT '0' COMMENT '厅',
  `guard` smallint(2) NOT NULL DEFAULT '0' COMMENT '卫',
  `bno` int(3) NOT NULL DEFAULT '0' COMMENT '楼号',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '总楼层',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `direction` int(10) NOT NULL DEFAULT '0' COMMENT '朝向',
  `zhuangxiu` int(10) NOT NULL DEFAULT '0' COMMENT '装修',
  `buildage` int(4) NOT NULL DEFAULT '0' COMMENT '建造年代',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '房源介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `flag` char(60) NOT NULL DEFAULT '' COMMENT '属性',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `elevator` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有电梯',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `buildpos` char(15) NOT NULL DEFAULT '' COMMENT '楼栋',
  `floortype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '楼层类型:1跃层,0单层',
  `floorspr` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '跃层数',
  `paytax` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '付税方式:1双方各自付税,2房主净得价',
  `rights_to` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '产权:1使用权房,2产权房',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `sourceid` char(15) NOT NULL DEFAULT '' COMMENT '房源编号',
  `resource` varchar(20) DEFAULT NULL,
  `externalno` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`) USING BTREE,
  KEY `communityid` (`communityid`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `usertype` (`usertype`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=309 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='二手房';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_shapan`
--

DROP TABLE IF EXISTS `huoniao_house_shapan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_shapan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `loupan` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `data` text NOT NULL COMMENT '沙盘数据',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='电子沙盘';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_sp`
--

DROP TABLE IF EXISTS `huoniao_house_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_sp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '供求',
  `industry` int(10) NOT NULL DEFAULT '0' COMMENT '经营行业',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `nearby` char(60) NOT NULL DEFAULT '' COMMENT '靠近',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `proprice` float(3,1) NOT NULL DEFAULT '0.0' COMMENT '物业费',
  `protype` int(10) NOT NULL DEFAULT '0' COMMENT '类型',
  `zhuangxiu` int(10) NOT NULL DEFAULT '0' COMMENT '装修情况',
  `bno` int(3) NOT NULL DEFAULT '0' COMMENT '第几层',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '共几层',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `transfer` int(5) NOT NULL DEFAULT '0' COMMENT '转让费',
  `config` char(100) NOT NULL DEFAULT '' COMMENT '配套设施',
  `suitable` char(100) NOT NULL DEFAULT '' COMMENT '适合经营行业',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '房源介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `paytype` int(10) NOT NULL DEFAULT '0' COMMENT '付款方式',
  `operating_state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '经营状态',
  `loupanid` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘id',
  `loupan` char(30) DEFAULT '' COMMENT '楼铺名称',
  `miankuan` float(3,1) NOT NULL DEFAULT '0.0' COMMENT '面宽',
  `jinshen` float(3,1) NOT NULL DEFAULT '0.0' COMMENT '进深',
  `cenggao` float(3,1) NOT NULL COMMENT '层高',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `floortype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '楼层类型:1跃层,0单层',
  `floorspr` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '跃层数',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `wuye_in` tinyint(1) NOT NULL DEFAULT '0' COMMENT '价格是否包含物业费0:未知,1不含,2包含',
  `flag` char(60) NOT NULL DEFAULT '' COMMENT '特色',
  `externalno` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  `resource` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `industry` (`industry`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `usertype` (`usertype`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商铺';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_xzl`
--

DROP TABLE IF EXISTS `huoniao_house_xzl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_xzl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '供求',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `loupan` char(60) NOT NULL DEFAULT '' COMMENT '小区',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `nearby` char(60) NOT NULL DEFAULT '' COMMENT '靠近',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `proprice` float(3,1) NOT NULL DEFAULT '0.0' COMMENT '物业费',
  `protype` int(10) NOT NULL DEFAULT '0' COMMENT '物业类型',
  `zhuangxiu` int(10) NOT NULL DEFAULT '0' COMMENT '装修情况',
  `bno` int(3) NOT NULL DEFAULT '0' COMMENT '第几层',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '共几层',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '房源介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `config` char(60) NOT NULL DEFAULT '' COMMENT '特色',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `loupanid` int(10) NOT NULL DEFAULT '0' COMMENT '楼盘id',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `fg` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可分割',
  `level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '级别',
  `peitao` varchar(255) DEFAULT '' COMMENT '配套设施',
  `floortype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '楼层类型:1跃层,0单层',
  `floorspr` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '跃层数',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `wuye_in` tinyint(1) NOT NULL DEFAULT '0' COMMENT '价格是否包含物业费0:未知,1不含,2包含',
  `resource` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  `externalno` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `loupan` (`loupan`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `usertype` (`usertype`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='写字楼';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_yuyue`
--

DROP TABLE IF EXISTS `huoniao_house_yuyue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_yuyue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(15) NOT NULL DEFAULT '' COMMENT '类型',
  `aid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '信息id',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `foruid` int(10) NOT NULL DEFAULT '0' COMMENT '房源发布人id',
  `date` char(10) NOT NULL DEFAULT '' COMMENT '看房时间',
  `note` varchar(255) DEFAULT '' COMMENT '备注',
  `username` char(15) NOT NULL DEFAULT '' COMMENT '联系人',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '联系电话',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态0:未标记1:已看房',
  `del1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '提交人删除',
  `del2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '经纪人删除',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `aid` (`aid`),
  KEY `uid` (`uid`),
  KEY `foruid` (`foruid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_zjcom`
--

DROP TABLE IF EXISTS `huoniao_house_zjcom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_zjcom` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '公司名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '公司logo',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `tel` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '公司地址',
  `email` char(60) NOT NULL DEFAULT '' COMMENT '邮箱',
  `note` text NOT NULL COMMENT '公司介绍',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `flag` smallint(1) NOT NULL DEFAULT '0' COMMENT '属性',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '置顶',
  `counts` int(10) NOT NULL DEFAULT '0' COMMENT '房源数量',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房产中介公司';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_zjuser`
--

DROP TABLE IF EXISTS `huoniao_house_zjuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_zjuser` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `zjcom` int(10) NOT NULL DEFAULT '0' COMMENT '中介公司',
  `store` char(20) NOT NULL DEFAULT '' COMMENT '门店',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '服务区域',
  `community` char(255) NOT NULL DEFAULT '' COMMENT '主营小区',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '公司logo',
  `note` text NOT NULL COMMENT '公司介绍',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `flag` smallint(1) NOT NULL DEFAULT '0' COMMENT '属性',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `by_zjcom` int(10) NOT NULL DEFAULT '0' COMMENT '公司添加',
  `wx` char(30) DEFAULT '' COMMENT '微信号',
  `wxQr` char(100) DEFAULT '' COMMENT '微信二维码',
  `qq` char(30) DEFAULT '' COMMENT 'qq号',
  `qqQr` char(100) DEFAULT '' COMMENT 'qq二维码',
  `license` char(100) DEFAULT '' COMMENT '职业许可证',
  `post` tinyint(1) NOT NULL DEFAULT '0' COMMENT '职位',
  `suc` int(4) NOT NULL DEFAULT '0' COMMENT '成交数',
  `fail_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '拒绝原因类型',
  `fail_info` varchar(255) DEFAULT '' COMMENT '拒绝详细理由',
  `joindate` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  `meal` varchar(255) DEFAULT '' COMMENT '套餐',
  `counts` int(10) NOT NULL DEFAULT '0' COMMENT '房源数量',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `zjcom` (`zjcom`) USING BTREE,
  KEY `store` (`store`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房产经纪人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_zjuser_order`
--

DROP TABLE IF EXISTS `huoniao_house_zjuser_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_zjuser_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `zjuid` int(10) NOT NULL DEFAULT '0' COMMENT '商家ID',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `totalprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `balance` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付',
  `paytype` varchar(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `config` varchar(255) NOT NULL COMMENT '详情',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`),
  KEY `bid` (`zjuid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='房产经纪人订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_zjusergroup`
--

DROP TABLE IF EXISTS `huoniao_house_zjusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_zjusergroup` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '房源数',
  `icon` char(60) NOT NULL DEFAULT '' COMMENT '图标地址',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='经纪人等级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_house_zu`
--

DROP TABLE IF EXISTS `huoniao_house_zu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_house_zu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '名称',
  `communityid` int(10) NOT NULL DEFAULT '0' COMMENT '小区ID',
  `community` char(60) NOT NULL DEFAULT '' COMMENT '小区',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '详细地址',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `price` int(10) NOT NULL DEFAULT '0' COMMENT '售价',
  `paytype` int(10) NOT NULL DEFAULT '0' COMMENT '付款方式',
  `rentype` smallint(1) NOT NULL DEFAULT '0' COMMENT '出租方式',
  `protype` int(10) NOT NULL DEFAULT '0' COMMENT '房屋类型',
  `room` smallint(2) NOT NULL DEFAULT '0' COMMENT '室',
  `hall` smallint(2) NOT NULL DEFAULT '0' COMMENT '厅',
  `guard` smallint(2) NOT NULL DEFAULT '0' COMMENT '卫',
  `sharetype` int(10) NOT NULL DEFAULT '0' COMMENT '出租间',
  `sharesex` smallint(1) NOT NULL DEFAULT '0' COMMENT '男女限制',
  `bno` int(3) NOT NULL DEFAULT '0' COMMENT '楼号',
  `floor` int(3) NOT NULL DEFAULT '0' COMMENT '总楼层',
  `area` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '面积',
  `direction` int(10) NOT NULL DEFAULT '0' COMMENT '朝向',
  `zhuangxiu` int(10) NOT NULL DEFAULT '0' COMMENT '装修',
  `buildage` int(4) NOT NULL DEFAULT '0' COMMENT '建造年代',
  `config` char(60) NOT NULL DEFAULT '' COMMENT '配置',
  `usertype` smallint(1) NOT NULL DEFAULT '0' COMMENT '房源性质',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '顾问',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `note` text NOT NULL COMMENT '房源介绍',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `elevator` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有电梯',
  `video` char(100) DEFAULT '' COMMENT '视频',
  `qj_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `qj_file` varchar(300) DEFAULT '' COMMENT '全景',
  `longitude` char(30) DEFAULT '' COMMENT '经度',
  `latitude` char(30) NOT NULL DEFAULT '' COMMENT '纬度',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `buildpos` char(15) NOT NULL DEFAULT '' COMMENT '楼栋',
  `floortype` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '楼层类型:1跃层,0单层',
  `floorspr` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '跃层数',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  `wx_tel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机号是微信:1是',
  `flag` char(60) NOT NULL DEFAULT '' COMMENT '特色',
  `resource` varchar(50) DEFAULT NULL,
  `externalno` varchar(50) DEFAULT NULL,
  `link` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `communityid` (`communityid`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `usertype` (`usertype`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='出租房';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_houseaddr`
--

DROP TABLE IF EXISTS `huoniao_houseaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_houseaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `longitude` char(50) NOT NULL DEFAULT '' COMMENT '经度',
  `latitude` char(50) NOT NULL DEFAULT '' COMMENT '纬度',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=282 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房产地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_housecommon`
--

DROP TABLE IF EXISTS `huoniao_housecommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_housecommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` char(20) NOT NULL DEFAULT '' COMMENT '房源类型',
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='房源评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_housedemand`
--

DROP TABLE IF EXISTS `huoniao_housedemand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_housedemand` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `note` text NOT NULL COMMENT '需求',
  `action` smallint(1) NOT NULL DEFAULT '0' COMMENT '栏目',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类别',
  `addr` int(5) NOT NULL DEFAULT '0' COMMENT '区域',
  `person` char(30) NOT NULL,
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `password` varchar(100) NOT NULL DEFAULT '' COMMENT '管理密码',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '发布人',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '联系人性别:1男,2:女',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='求租求购';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_houseitem`
--

DROP TABLE IF EXISTS `huoniao_houseitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_houseitem` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='房产字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huangyeaddr`
--

DROP TABLE IF EXISTS `huoniao_huangyeaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huangyeaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='黄页地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huangyecommon`
--

DROP TABLE IF EXISTS `huoniao_huangyecommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huangyecommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '评论会员',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '信息状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='黄页评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huangyelist`
--

DROP TABLE IF EXISTS `huoniao_huangyelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huangyelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `typeid` int(10) NOT NULL COMMENT '分类ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `peise` smallint(1) NOT NULL COMMENT '配色方案',
  `litpic` char(100) NOT NULL,
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `valid` int(11) NOT NULL DEFAULT '0' COMMENT '有效期',
  `addr` int(10) NOT NULL COMMENT '所属地区',
  `address` char(60) NOT NULL COMMENT '联系地址',
  `longitude` char(50) NOT NULL COMMENT '经度',
  `latitude` char(50) NOT NULL COMMENT '维度',
  `project` varchar(255) NOT NULL COMMENT '主营项目',
  `pics` text NOT NULL COMMENT '图集',
  `person` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `tel` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `teladdr` char(20) NOT NULL DEFAULT '' COMMENT '手机归属地',
  `qq` char(30) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `email` char(40) NOT NULL COMMENT '邮箱',
  `weixin` char(20) NOT NULL COMMENT '联系人微信',
  `weixinQr` char(100) NOT NULL COMMENT '微信二维码',
  `click` mediumint(8) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `ip` char(20) NOT NULL DEFAULT '' COMMENT '发布IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '对应会员',
  `admin` int(10) NOT NULL COMMENT '发布人',
  `rec` smallint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `fire` smallint(1) NOT NULL DEFAULT '0' COMMENT '急',
  `top` smallint(1) NOT NULL DEFAULT '0' COMMENT '置顶',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否推广',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '推广单价',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '推广开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '推广结束时间',
  `rz1` smallint(1) NOT NULL COMMENT '手机认证',
  `rz2` smallint(1) NOT NULL COMMENT '邮箱认证',
  `rz3` smallint(1) NOT NULL COMMENT '身份验证',
  `rz4` smallint(1) NOT NULL COMMENT '执照验证',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='黄页列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huangyenav`
--

DROP TABLE IF EXISTS `huoniao_huangyenav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huangyenav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL COMMENT '所属黄页id',
  `nav` char(20) NOT NULL COMMENT '导航名称',
  `body` text NOT NULL COMMENT 'pc正文',
  `mbody` text NOT NULL COMMENT 'mobile正文',
  `show` tinyint(1) NOT NULL COMMENT '是否显示 1：显示；0：隐藏',
  `weight` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huangyetype`
--

DROP TABLE IF EXISTS `huoniao_huangyetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huangyetype` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='黄页分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_addr`
--

DROP TABLE IF EXISTS `huoniao_huodong_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_addr` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='活动区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_fee`
--

DROP TABLE IF EXISTS `huoniao_huodong_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_fee` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hid` int(10) NOT NULL DEFAULT '0' COMMENT '活动ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '名称',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '费用',
  `max` int(10) NOT NULL DEFAULT '0' COMMENT '人数上限',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `hid` (`hid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='活动电子票';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_list`
--

DROP TABLE IF EXISTS `huoniao_huodong_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '类型ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '活动主题',
  `litpic` char(255) NOT NULL DEFAULT '' COMMENT '海报',
  `began` int(10) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `baoming` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动结束前都可报名',
  `baomingend` int(10) NOT NULL DEFAULT '0' COMMENT '报名截止时间',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域ID',
  `address` char(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `body` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '活动详情',
  `feetype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '费用类型',
  `max` int(10) NOT NULL DEFAULT '0' COMMENT '人数上限',
  `contact` char(100) NOT NULL DEFAULT '' COMMENT '主办方联系方式',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `property` text NOT NULL COMMENT '报名填写信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `began` (`began`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `feetype` (`feetype`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='活动列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_order`
--

DROP TABLE IF EXISTS `huoniao_huodong_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordernum` char(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `hid` int(10) NOT NULL DEFAULT '0' COMMENT '活动ID',
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '费用ID',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `paytype` char(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `point` int(10) NOT NULL DEFAULT '0' COMMENT '使用的积分',
  `balance` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '使用的余额',
  `payprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付',
  `property` text NOT NULL COMMENT '报名信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `hid` (`hid`) USING BTREE,
  KEY `fid` (`fid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='活动订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_reg`
--

DROP TABLE IF EXISTS `huoniao_huodong_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_reg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hid` int(10) NOT NULL DEFAULT '0' COMMENT '活动ID',
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '费用ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '报名时间',
  `property` text NOT NULL COMMENT '报名信息',
  `state` smallint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `code` varchar(255) NOT NULL DEFAULT '' COMMENT '电子票号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `hid` (`hid`) USING BTREE,
  KEY `fid` (`fid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='活动报名';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_reply`
--

DROP TABLE IF EXISTS `huoniao_huodong_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_reply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hid` int(10) NOT NULL DEFAULT '0' COMMENT '活动ID',
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '回复信息ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` text NOT NULL COMMENT '回复内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '回复时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `hid` (`hid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='活动回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_huodong_type`
--

DROP TABLE IF EXISTS `huoniao_huodong_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_huodong_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='活动分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_imagelist`
--

DROP TABLE IF EXISTS `huoniao_imagelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_imagelist` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `subtitle` char(36) NOT NULL DEFAULT '' COMMENT '短标题',
  `flag` set('h','r','b','p','t') NOT NULL DEFAULT '' COMMENT '附加属性',
  `redirecturl` varchar(255) DEFAULT '' COMMENT '跳转地址',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `litpic` char(255) DEFAULT '' COMMENT '缩略图',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `sourceurl` char(200) NOT NULL DEFAULT '' COMMENT '来源网址',
  `writer` char(20) NOT NULL DEFAULT '' COMMENT '作者',
  `typeid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `keywords` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `admin` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE,
  KEY `del` (`del`,`arcrank`,`typeid`,`flag`,`litpic`,`weight`) USING BTREE,
  KEY `flag` (`flag`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `keywords` (`keywords`) USING BTREE,
  KEY `weight` (`weight`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=568 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_imagepic`
--

DROP TABLE IF EXISTS `huoniao_imagepic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_imagepic` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL COMMENT '信息ID',
  `picPath` varchar(255) NOT NULL DEFAULT '' COMMENT '图片路径',
  `picInfo` text COMMENT '图片注释',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3379 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片图集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_imagetype`
--

DROP TABLE IF EXISTS `huoniao_imagetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_imagetype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `pinyin` char(100) NOT NULL DEFAULT '' COMMENT '分类全拼',
  `py` char(50) NOT NULL DEFAULT '' COMMENT '分类首字母',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_info_order`
--

DROP TABLE IF EXISTS `huoniao_info_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_info_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `store` int(10) NOT NULL COMMENT '商铺ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `prod` int(20) DEFAULT NULL,
  `orderstate` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态： 0. 已下单，1. 已支付，2. 待发货，3. 已发货, 4:已完成 6： 申请退款 7：退款成功 8: 退款中',
  `orderdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytype` char(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `price` varchar(10) DEFAULT NULL,
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '收货地址',
  `contact` char(60) NOT NULL DEFAULT '' COMMENT '联系方式',
  `note` char(100) NOT NULL DEFAULT '' COMMENT '买家备注',
  `common` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价',
  `exp-company` char(20) DEFAULT '' COMMENT '发货快递公司',
  `exp-number` char(20) DEFAULT '' COMMENT '发货快递单号',
  `exp-date` int(20) NOT NULL DEFAULT '0' COMMENT '发货时间',
  `ret-state` tinyint(1) DEFAULT '0' COMMENT '申请退款',
  `ret-type` char(20) DEFAULT '' COMMENT '退款原因',
  `ret-note` text COMMENT '退款说明',
  `ret-pics` char(255) DEFAULT '' COMMENT '恳款凭证',
  `ret-date` int(10) DEFAULT '0' COMMENT '申请时间',
  `ret-s-note` text COMMENT '卖家回复',
  `ret-s-pics` char(255) DEFAULT '' COMMENT '卖家回复凭证',
  `ret-s-date` int(10) DEFAULT '0' COMMENT '卖家回复时间',
  `ret-ok-date` int(10) DEFAULT '0' COMMENT '退款确定时间',
  `payprice` varchar(20) DEFAULT NULL COMMENT '实际支付',
  `point` varchar(20) DEFAULT NULL COMMENT '使用的积分',
  `balance` varchar(20) DEFAULT NULL COMMENT '使用的余额',
  `tab` varchar(20) NOT NULL DEFAULT 'info' COMMENT '模块',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `orderstate` (`orderstate`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='二手信息订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_info_shopcommon`
--

DROP TABLE IF EXISTS `huoniao_info_shopcommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_info_shopcommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `userid` int(11) NOT NULL COMMENT '评论id',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '信息状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infoaddr`
--

DROP TABLE IF EXISTS `huoniao_infoaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infoaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=277 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='信息地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infocommon`
--

DROP TABLE IF EXISTS `huoniao_infocommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infocommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '评论会员',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '信息状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='信息评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infoitem`
--

DROP TABLE IF EXISTS `huoniao_infoitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infoitem` (
  `id` mediumint(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL COMMENT '信息ID',
  `iid` int(10) NOT NULL COMMENT '字段ID',
  `value` char(50) NOT NULL DEFAULT '' COMMENT '字段内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1740 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='信息字段内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infolist`
--

DROP TABLE IF EXISTS `huoniao_infolist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infolist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `typeid` int(10) NOT NULL COMMENT '分类ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `valid` int(10) NOT NULL DEFAULT '0' COMMENT '有效期',
  `addr` int(10) NOT NULL COMMENT '所属地区',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `body` text NOT NULL COMMENT '信息内容',
  `mbody` text COMMENT '移动端内容',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `person` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `tel` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `teladdr` char(20) NOT NULL DEFAULT '' COMMENT '手机归属地',
  `qq` char(30) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `click` mediumint(8) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `ip` char(20) NOT NULL DEFAULT '' COMMENT '发布IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '发布人',
  `rec` smallint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `fire` smallint(1) NOT NULL DEFAULT '0' COMMENT '急',
  `top` smallint(1) NOT NULL DEFAULT '0' COMMENT '置顶',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `yunfei` int(20) NOT NULL DEFAULT '0' COMMENT '运费',
  `is_valid` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否过期，是否有效（默认有效：0）',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE,
  KEY `cityid` (`cityid`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE,
  KEY `waitpay` (`waitpay`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类信息列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infopic`
--

DROP TABLE IF EXISTS `huoniao_infopic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infopic` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL COMMENT '信息ID',
  `picPath` varchar(255) NOT NULL COMMENT '图片路径',
  `picInfo` text COMMENT '图片注释',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1052 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类信息图集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infoshop`
--

DROP TABLE IF EXISTS `huoniao_infoshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infoshop` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `stype` int(10) NOT NULL DEFAULT '0' COMMENT '商家类型',
  `subway` char(50) NOT NULL DEFAULT '' COMMENT '附近地铁',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `circle` char(50) NOT NULL DEFAULT '' COMMENT '所在商圈',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `tel` char(50) NOT NULL DEFAULT '' COMMENT '电话',
  `openStart` char(4) NOT NULL DEFAULT '' COMMENT '营业开始时间',
  `openEnd` char(4) NOT NULL DEFAULT '' COMMENT '营业结束时间',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '简介',
  `body` text NOT NULL COMMENT '详细介绍',
  `score` float(3,1) DEFAULT '0.0' COMMENT '总评分',
  `jointime` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `top` tinyint(3) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL COMMENT '视频',
  `video_pic` varchar(255) DEFAULT NULL COMMENT '视频封面',
  `pic` varchar(255) DEFAULT NULL COMMENT '图片',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '座机',
  `wechat_pic` varchar(255) NOT NULL DEFAULT '0' COMMENT '商家微信二维码',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infotype`
--

DROP TABLE IF EXISTS `huoniao_infotype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infotype` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='信息分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_infotypeitem`
--

DROP TABLE IF EXISTS `huoniao_infotypeitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_infotypeitem` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `field` char(20) NOT NULL DEFAULT '0' COMMENT '字段名',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '字段别名',
  `orderby` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `formtype` char(10) NOT NULL DEFAULT '50' COMMENT '字段类型',
  `required` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否必填',
  `options` text NOT NULL COMMENT '选项列表',
  `default` char(50) NOT NULL DEFAULT '' COMMENT '默认值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=346 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='信息分类字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_integral_common`
--

DROP TABLE IF EXISTS `huoniao_integral_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_integral_common` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '订单ID',
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `score1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分1',
  `score2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分2',
  `score3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分3',
  `pics` tinytext COMMENT '图片',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='积分商城评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_integral_order`
--

DROP TABLE IF EXISTS `huoniao_integral_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_integral_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `proid` int(10) NOT NULL DEFAULT '0' COMMENT '商品id',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '现金',
  `point` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '数量',
  `orderstate` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `orderdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytype` char(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '收货地址',
  `contact` char(60) NOT NULL DEFAULT '' COMMENT '联系方式',
  `note` char(100) NOT NULL DEFAULT '' COMMENT '买家备注',
  `common` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价',
  `exp-company` char(20) DEFAULT '' COMMENT '发货快递公司',
  `exp-number` char(20) DEFAULT '' COMMENT '发货快递单号',
  `exp-date` int(10) DEFAULT '0' COMMENT '发货时间',
  `freight` float(4,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `priceinfo` text NOT NULL COMMENT '费用详情',
  `courier` int(10) NOT NULL DEFAULT '0' COMMENT '指定骑手id',
  `peidate` int(10) NOT NULL DEFAULT '0' COMMENT '接单时间',
  `peisongid` int(10) NOT NULL DEFAULT '0' COMMENT '配送员',
  `peisongidlog` text NOT NULL COMMENT '配送员变更记录',
  `songdate` int(10) NOT NULL DEFAULT '0' COMMENT '配送时间-取货',
  `okdate` int(10) NOT NULL DEFAULT '0' COMMENT '成功时间',
  `courier_pushed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '骑手推送',
  `ret-state` tinyint(1) DEFAULT '0' COMMENT '申请退款',
  `ret-type` char(20) DEFAULT '' COMMENT '退款原因',
  `ret-note` text COMMENT '退款说明',
  `ret-pics` char(255) DEFAULT '' COMMENT '恳款凭证',
  `ret-date` int(10) DEFAULT '0' COMMENT '申请时间',
  `ret-s-note` text COMMENT '卖家回复',
  `ret-s-pics` char(255) DEFAULT '' COMMENT '卖家回复凭证',
  `ret-s-date` int(10) DEFAULT '0' COMMENT '卖家回复时间',
  `ret-ok-date` int(10) DEFAULT '0' COMMENT '退款确定时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `orderstate` (`orderstate`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='积分商城订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_integral_product`
--

DROP TABLE IF EXISTS `huoniao_integral_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_integral_product` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `mprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '原价',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '现金',
  `point` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `litpic` char(100) DEFAULT '' COMMENT '缩略图',
  `pics` text NOT NULL COMMENT '图集',
  `flag` set('0','1','2') NOT NULL DEFAULT '' COMMENT '附加属性',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `body` text NOT NULL COMMENT '电脑端内容',
  `mbody` text NOT NULL COMMENT '手机端内容',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `sales` int(10) NOT NULL DEFAULT '0' COMMENT '销量',
  `inventory` int(10) NOT NULL DEFAULT '0' COMMENT '库存',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `admin` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布人',
  `delivery` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否配送上门',
  `freight` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `video` varchar(255) DEFAULT '' COMMENT '视频',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `flag` (`flag`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `weight` (`weight`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='积分商城商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_integral_type`
--

DROP TABLE IF EXISTS `huoniao_integral_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_integral_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `spe` char(255) NOT NULL DEFAULT '' COMMENT '关联规格',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_bole`
--

DROP TABLE IF EXISTS `huoniao_job_bole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_bole` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '所在公司',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属会员',
  `work` char(50) NOT NULL DEFAULT '' COMMENT '职位名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '身份类型',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '招聘状态',
  `industry` char(255) NOT NULL DEFAULT '' COMMENT '招聘行业',
  `zhineng` char(255) NOT NULL DEFAULT '' COMMENT '招聘职能',
  `note` text NOT NULL COMMENT '招聘简介',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `addr` (`addr`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='伯乐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_bole_review`
--

DROP TABLE IF EXISTS `huoniao_job_bole_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_bole_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bole` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评论内容',
  `gx` tinyint(1) NOT NULL DEFAULT '1' COMMENT '关系',
  `ischeck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `dtime` int(10) NOT NULL DEFAULT '0' COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `gx` (`gx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='伯乐评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_company`
--

DROP TABLE IF EXISTS `huoniao_job_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '公司名称',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `nature` int(10) NOT NULL DEFAULT '0' COMMENT '公司性质',
  `scale` int(10) NOT NULL DEFAULT '0' COMMENT '公司规模',
  `industry` int(10) NOT NULL DEFAULT '0' COMMENT '经营行业',
  `logo` char(100) NOT NULL DEFAULT '' COMMENT 'logo',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属会员',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '公司地址',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `postcode` int(6) NOT NULL DEFAULT '0' COMMENT '邮编',
  `email` char(60) NOT NULL DEFAULT '' COMMENT '邮箱',
  `site` char(60) NOT NULL DEFAULT '' COMMENT '公司网址',
  `body` text NOT NULL COMMENT '公司介绍',
  `pics` text NOT NULL COMMENT '图集',
  `seotitle` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题 ',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `property` char(10) NOT NULL DEFAULT '' COMMENT '附加属性',
  `score` tinyint(1) NOT NULL DEFAULT '0' COMMENT '综合评分',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `welfare` text NOT NULL COMMENT '公司福利',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `nature` (`nature`) USING BTREE,
  KEY `industry` (`industry`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1251 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘企业';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_company_review`
--

DROP TABLE IF EXISTS `huoniao_job_company_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_company_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `floor` int(5) NOT NULL DEFAULT '0' COMMENT '楼层',
  `score` tinyint(1) NOT NULL DEFAULT '1' COMMENT '评分',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评论内容',
  `gx` tinyint(1) NOT NULL DEFAULT '1' COMMENT '关系',
  `ischeck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `dtime` int(10) NOT NULL DEFAULT '0' COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `score` (`score`) USING BTREE,
  KEY `gx` (`gx`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='企业评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_delivery`
--

DROP TABLE IF EXISTS `huoniao_job_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_delivery` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '简历ID',
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '职位ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '投递时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '不合适原因',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='简历投递';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_download`
--

DROP TABLE IF EXISTS `huoniao_job_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `file` char(50) NOT NULL DEFAULT '' COMMENT '缩略图',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览',
  `weight` int(10) NOT NULL COMMENT '排序',
  `note` text NOT NULL COMMENT '介绍',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘文档下载';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_download_type`
--

DROP TABLE IF EXISTS `huoniao_job_download_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_download_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='招聘资讯分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_fairs`
--

DROP TABLE IF EXISTS `huoniao_job_fairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_fairs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '会馆ID',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '招聘会名称',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '举办时间',
  `began` char(5) NOT NULL DEFAULT '' COMMENT '开始时间',
  `end` char(5) NOT NULL COMMENT '结束时间',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `note` text NOT NULL COMMENT '介绍',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘会';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_fairs_center`
--

DROP TABLE IF EXISTS `huoniao_job_fairs_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_fairs_center` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '会馆名称',
  `people` char(10) NOT NULL DEFAULT '' COMMENT '联系人',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '联系手机',
  `tel` char(15) NOT NULL DEFAULT '' COMMENT '固定电话',
  `fax` char(15) NOT NULL DEFAULT '' COMMENT '传真',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(50) NOT NULL DEFAULT '' COMMENT '具体地址',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `email` char(50) NOT NULL DEFAULT '' COMMENT '联系邮箱',
  `qq` char(15) NOT NULL DEFAULT '' COMMENT '联系qq',
  `note` text NOT NULL COMMENT '介绍',
  `traffic` text NOT NULL COMMENT '交通路线',
  `pics` text NOT NULL COMMENT '图集',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `laglat` (`lnglat`) USING BTREE,
  KEY `addr` (`addr`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘会馆';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_industry`
--

DROP TABLE IF EXISTS `huoniao_job_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_industry` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='招聘行业';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_invitation`
--

DROP TABLE IF EXISTS `huoniao_job_invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_invitation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '职位ID',
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '简历ID',
  `date` int(20) NOT NULL DEFAULT '0' COMMENT '邀请时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `place` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `contacts` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邀请面试记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_news`
--

DROP TABLE IF EXISTS `huoniao_job_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `litpic` char(50) NOT NULL DEFAULT '' COMMENT '缩略图',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览',
  `weight` int(10) NOT NULL COMMENT '排序',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `sourceUrl` char(100) NOT NULL DEFAULT '' COMMENT '来源网址',
  `writer` char(30) NOT NULL DEFAULT '' COMMENT '作者',
  `keyword` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(255) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_newstype`
--

DROP TABLE IF EXISTS `huoniao_job_newstype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_newstype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='招聘资讯分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_post`
--

DROP TABLE IF EXISTS `huoniao_job_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_post` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '职位名称',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '职位类别',
  `company` int(10) NOT NULL DEFAULT '0' COMMENT '所属公司',
  `bole` int(10) NOT NULL DEFAULT '0' COMMENT '所属伯乐',
  `sex` smallint(1) NOT NULL DEFAULT '0' COMMENT '性别要求',
  `nature` smallint(1) NOT NULL DEFAULT '0' COMMENT '职位性质',
  `valid` int(10) NOT NULL DEFAULT '0' COMMENT '有效期',
  `number` int(5) NOT NULL DEFAULT '0' COMMENT '招聘人数',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '区域',
  `experience` int(10) NOT NULL DEFAULT '0' COMMENT '工作经验',
  `educational` int(10) NOT NULL DEFAULT '0' COMMENT '学历要求',
  `language` char(20) NOT NULL DEFAULT '' COMMENT '语言能力',
  `salary` int(10) NOT NULL DEFAULT '0' COMMENT '薪资范围',
  `note` text NOT NULL COMMENT '职位描述',
  `claim` text NOT NULL COMMENT '职位要求',
  `tel` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `email` char(60) NOT NULL DEFAULT '' COMMENT '邮箱',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `property` char(10) NOT NULL DEFAULT '' COMMENT '属性',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `isbid` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `bid_type` varchar(10) NOT NULL DEFAULT '' COMMENT '置顶类型',
  `bid_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '置顶价格',
  `bid_start` int(10) NOT NULL DEFAULT '0' COMMENT '置顶开始时间',
  `bid_end` int(10) NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `bid_week0` varchar(10) NOT NULL DEFAULT '' COMMENT '周日置顶',
  `bid_week1` varchar(10) NOT NULL DEFAULT '' COMMENT '周一置顶',
  `bid_week2` varchar(10) NOT NULL DEFAULT '' COMMENT '周二置顶',
  `bid_week3` varchar(10) NOT NULL DEFAULT '' COMMENT '周三置顶',
  `bid_week4` varchar(10) NOT NULL DEFAULT '' COMMENT '周四置顶',
  `bid_week5` varchar(10) NOT NULL DEFAULT '' COMMENT '周五置顶',
  `refreshSmart` smallint(1) NOT NULL DEFAULT '0' COMMENT '智能刷新',
  `refreshCount` int(10) NOT NULL DEFAULT '0' COMMENT '刷新总次数',
  `refreshTimes` int(10) NOT NULL DEFAULT '0' COMMENT '刷新时长',
  `refreshPrice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '刷新价格',
  `refreshBegan` int(10) NOT NULL DEFAULT '0' COMMENT '开始刷新时间',
  `refreshNext` int(10) NOT NULL DEFAULT '0' COMMENT '下次刷新时间',
  `refreshSurplus` int(10) NOT NULL DEFAULT '0' COMMENT '刷新剩余次数',
  `refreshFree` smallint(1) NOT NULL DEFAULT '0' COMMENT '免费刷新',
  `bid_week6` varchar(10) NOT NULL DEFAULT '' COMMENT '周六置顶',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `nature` (`nature`) USING BTREE,
  KEY `refreshSmart` (`refreshSmart`) USING BTREE,
  KEY `refreshNext` (`refreshNext`) USING BTREE,
  KEY `refreshFree` (`refreshFree`) USING BTREE,
  KEY `bid_type` (`bid_type`) USING BTREE,
  KEY `bid_week` (`bid_week0`,`bid_week1`,`bid_week2`,`bid_week3`,`bid_week4`,`bid_week5`,`bid_week6`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=551 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘职位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_resume`
--

DROP TABLE IF EXISTS `huoniao_job_resume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_resume` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属会员',
  `name` char(15) NOT NULL DEFAULT '' COMMENT '姓名',
  `sex` smallint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `nature` smallint(1) NOT NULL DEFAULT '0' COMMENT '期望工作性质',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '职业类别',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '工作区域',
  `birth` char(10) NOT NULL DEFAULT '' COMMENT '出生日期',
  `photo` char(100) NOT NULL DEFAULT '' COMMENT '照片',
  `home` char(20) NOT NULL DEFAULT '' COMMENT '故乡',
  `address` char(20) NOT NULL DEFAULT '' COMMENT '所在地',
  `phone` char(11) NOT NULL DEFAULT '' COMMENT '手机号',
  `email` char(30) NOT NULL DEFAULT '' COMMENT '邮箱',
  `salary` int(8) NOT NULL DEFAULT '0' COMMENT '期望薪资',
  `startwork` int(10) NOT NULL DEFAULT '0' COMMENT '到岗时间',
  `evaluation` text NOT NULL COMMENT '自我评价',
  `objective` text NOT NULL COMMENT '职业目标',
  `workyear` int(2) NOT NULL DEFAULT '0' COMMENT '工作年限',
  `experience` text NOT NULL COMMENT '工作经验',
  `educational` int(10) NOT NULL DEFAULT '0' COMMENT '最高学历',
  `college` char(30) NOT NULL DEFAULT '' COMMENT '毕业学院',
  `graduation` int(10) NOT NULL DEFAULT '0' COMMENT '毕业时间',
  `professional` char(20) NOT NULL DEFAULT '' COMMENT '专业',
  `language` char(20) NOT NULL DEFAULT '' COMMENT '外语水平',
  `computer` char(20) NOT NULL DEFAULT '' COMMENT '计算机水平',
  `education` text NOT NULL COMMENT '教育经历',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览',
  `gz` int(5) NOT NULL DEFAULT '0' COMMENT '关注数',
  `guanzhu` text COMMENT '关注',
  `fs` int(5) NOT NULL DEFAULT '0' COMMENT '粉丝数',
  `fensi` text COMMENT '粉丝',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `sex` (`sex`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='招聘简历';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_resume_view`
--

DROP TABLE IF EXISTS `huoniao_job_resume_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_resume_view` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '简历ID',
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '企业ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '查看时间',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注（是否合适）',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='企业查看简历记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_sentence`
--

DROP TABLE IF EXISTS `huoniao_job_sentence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_sentence` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类别',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '职位名',
  `people` char(10) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(13) NOT NULL DEFAULT '' COMMENT '联系电话',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '管理密码',
  `note` text NOT NULL COMMENT '说明',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='一句话招聘/求职';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_type`
--

DROP TABLE IF EXISTS `huoniao_job_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(50) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=400 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='职位类别';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_job_wage`
--

DROP TABLE IF EXISTS `huoniao_job_wage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_job_wage` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '工作地点',
  `work` char(30) NOT NULL DEFAULT '' COMMENT '职位',
  `wage` smallint(6) NOT NULL DEFAULT '0' COMMENT '工资',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '填写时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='工资统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_jobaddr`
--

DROP TABLE IF EXISTS `huoniao_jobaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_jobaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=277 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='招聘地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_jobitem`
--

DROP TABLE IF EXISTS `huoniao_jobitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_jobitem` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='招聘分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_follow`
--

DROP TABLE IF EXISTS `huoniao_live_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_follow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL COMMENT '会员ID',
  `tid` int(10) NOT NULL COMMENT '关注ID',
  `date` int(10) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='直播关注列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_gift`
--

DROP TABLE IF EXISTS `huoniao_live_gift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gift_name` varchar(255) NOT NULL COMMENT '礼物名称',
  `gift_price` varchar(255) NOT NULL COMMENT '礼物价格',
  `gift_litpic` varchar(255) NOT NULL COMMENT '礼物图标',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_hongbao`
--

DROP TABLE IF EXISTS `huoniao_live_hongbao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_hongbao` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `live_id` int(20) NOT NULL COMMENT '直播id',
  `amount` varchar(20) NOT NULL COMMENT '总金额',
  `user_id` int(20) NOT NULL COMMENT '发红包的用户',
  `count` tinyint(4) NOT NULL COMMENT '红包个数',
  `payid` varchar(100) NOT NULL COMMENT '支付记录id',
  `date` int(20) NOT NULL COMMENT '时间',
  `note` varchar(100) DEFAULT NULL COMMENT '备注',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '红包状态0：未领完 1：领完',
  `amount1` varchar(255) NOT NULL COMMENT '红包剩余金额',
  `count1` int(20) NOT NULL COMMENT '剩余红包数量',
  `chatid` varchar(255) NOT NULL COMMENT '聊天室id',
  PRIMARY KEY (`id`),
  KEY `chatid` (`chatid`),
  KEY `liveid` (`live_id`),
  KEY `userid` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='红包表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_hrecv_list`
--

DROP TABLE IF EXISTS `huoniao_live_hrecv_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_hrecv_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hid` int(11) NOT NULL COMMENT '红包id',
  `recv_user` int(255) NOT NULL COMMENT '领红包的用户',
  `recv_money` varchar(255) NOT NULL COMMENT '领取到的金额',
  `date` int(15) DEFAULT NULL COMMENT '领取时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='红包领取记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_payorder`
--

DROP TABLE IF EXISTS `huoniao_live_payorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_payorder` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `live_id` int(30) DEFAULT NULL COMMENT '直播id',
  `user_id` int(30) DEFAULT NULL COMMENT '用户id',
  `order_id` varchar(200) DEFAULT NULL COMMENT '订单号',
  `date` int(20) DEFAULT NULL COMMENT '支付时间',
  `amount` varchar(20) DEFAULT NULL COMMENT '金额',
  `status` tinyint(3) DEFAULT '0' COMMENT '状态:0默认；1成功',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户支付订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_reward`
--

DROP TABLE IF EXISTS `huoniao_live_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_id` int(11) NOT NULL COMMENT '直播id',
  `reward_userid` int(11) NOT NULL COMMENT '打赏人',
  `amount` varchar(20) NOT NULL COMMENT '打赏金额',
  `payid` varchar(50) NOT NULL COMMENT '支付订单id',
  `date` int(20) NOT NULL COMMENT '打赏时间',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `num` int(20) NOT NULL,
  `gift_id` int(20) NOT NULL,
  `chatid` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='打赏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_share`
--

DROP TABLE IF EXISTS `huoniao_live_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_share` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `live_id` int(20) NOT NULL DEFAULT '0' COMMENT '直播id',
  `share_userid` int(20) NOT NULL DEFAULT '0' COMMENT '分享人',
  `date` int(20) NOT NULL COMMENT '分享时间',
  PRIMARY KEY (`id`),
  KEY `shareuser` (`share_userid`),
  KEY `liveid` (`live_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='直播邀请二维码信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_live_share_success_user`
--

DROP TABLE IF EXISTS `huoniao_live_share_success_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_live_share_success_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_id` int(11) NOT NULL COMMENT '直播id',
  `share_user` int(255) NOT NULL COMMENT '邀请人',
  `success_share_user` int(255) NOT NULL COMMENT '成功邀请的人',
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分享成功记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_liveaccount`
--

DROP TABLE IF EXISTS `huoniao_liveaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_liveaccount` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL DEFAULT '' COMMENT '名称',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(50) NOT NULL DEFAULT '' COMMENT '密码',
  `appname` char(50) NOT NULL COMMENT '直播流所属应用名称',
  `pushdomain` varchar(255) NOT NULL COMMENT '推流地址',
  `vhost` char(255) NOT NULL DEFAULT '' COMMENT '加速域名',
  `website` char(100) NOT NULL DEFAULT '' COMMENT '平台网址',
  `contact` char(200) NOT NULL DEFAULT '' COMMENT '联系方式',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `privatekey` char(100) NOT NULL DEFAULT '' COMMENT '鉴权Key',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='直播平台账号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_livechat`
--

DROP TABLE IF EXISTS `huoniao_livechat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_livechat` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `chatid` char(20) NOT NULL COMMENT '聊天ID',
  `userid` int(8) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` char(40) NOT NULL COMMENT '用户名',
  `userphoto` char(150) NOT NULL COMMENT '用户头像',
  `content` text NOT NULL COMMENT '内容',
  `ftime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='直播聊天信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_livelist`
--

DROP TABLE IF EXISTS `huoniao_livelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_livelist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` mediumint(8) NOT NULL COMMENT '用户ID',
  `pushurl` char(255) NOT NULL DEFAULT '' COMMENT '推流地址',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '标题',
  `catid` smallint(2) NOT NULL DEFAULT '0' COMMENT '直播类型 0：公开；1：加密；2：收费',
  `typeid` smallint(4) NOT NULL COMMENT '直播分类',
  `streamname` char(50) NOT NULL COMMENT '直播流名',
  `starttime` int(11) NOT NULL COMMENT '时间',
  `litpic` varchar(255) NOT NULL COMMENT '封面地址',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '直播状态：0：未直播；1：正在直播；2：结束直播；',
  `way` tinyint(1) NOT NULL DEFAULT '0' COMMENT '直播方式：0：横屏；1：竖屏',
  `password` varchar(47) NOT NULL DEFAULT '' COMMENT '加密密码',
  `flow` tinyint(1) NOT NULL DEFAULT '0' COMMENT '流畅度：0：流畅；1：普清；2：高清',
  `startmoney` decimal(10,2) NOT NULL COMMENT '开始收费',
  `endmoney` decimal(10,2) NOT NULL COMMENT '结束收费',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `livetime` int(10) NOT NULL DEFAULT '0' COMMENT '直播时间',
  `ftime` int(10) NOT NULL DEFAULT '0' COMMENT '直播时间',
  `ossurl` char(255) NOT NULL DEFAULT '' COMMENT '录播地址',
  `up` int(10) NOT NULL DEFAULT '0' COMMENT '直播时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='直播列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_livetype`
--

DROP TABLE IF EXISTS `huoniao_livetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_livetype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `pinyin` char(100) NOT NULL DEFAULT '' COMMENT '分类全拼',
  `py` char(50) NOT NULL DEFAULT '' COMMENT '分类首字母',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='直播分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member`
--

DROP TABLE IF EXISTS `huoniao_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `mtype` tinyint(1) NOT NULL DEFAULT '1' COMMENT '会员类型',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(47) NOT NULL DEFAULT '' COMMENT '登录密码',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '等级',
  `expired` int(10) NOT NULL DEFAULT '0' COMMENT '过期时间',
  `discount` char(60) NOT NULL DEFAULT '' COMMENT '打折卡',
  `nickname` char(36) NOT NULL DEFAULT '' COMMENT '昵称',
  `realname` char(10) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `idcard` char(18) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `idcardFront` char(60) NOT NULL DEFAULT '' COMMENT '身份证正面照片',
  `idcardBack` char(60) NOT NULL DEFAULT '' COMMENT '身份证反面照片',
  `certifyState` tinyint(1) NOT NULL DEFAULT '0' COMMENT '实名认证',
  `certifyInfo` char(255) NOT NULL DEFAULT '' COMMENT '认证备注',
  `email` char(60) NOT NULL DEFAULT '' COMMENT '联系邮箱',
  `emailCheck` smallint(1) NOT NULL DEFAULT '0' COMMENT '邮箱验证',
  `sendEmail` int(10) NOT NULL DEFAULT '0' COMMENT '发送邮件验证时间',
  `areaCode` char(10) NOT NULL DEFAULT '' COMMENT '手机区域代码',
  `phone` char(13) NOT NULL DEFAULT '' COMMENT '联系电话',
  `phoneCheck` smallint(1) NOT NULL DEFAULT '0' COMMENT '手机验证',
  `sendPhone` int(10) NOT NULL DEFAULT '0' COMMENT '发送手机验证时间',
  `paypwd` char(47) NOT NULL DEFAULT '' COMMENT '支付密码',
  `paypwdCheck` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付密码验证',
  `qq` char(11) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint(1) NOT NULL DEFAULT '1' COMMENT '性别',
  `birthday` char(10) NOT NULL DEFAULT '' COMMENT '出生日期',
  `mgroupid` int(10) DEFAULT '0' COMMENT '管理组',
  `company` char(100) NOT NULL DEFAULT '' COMMENT '公司名称',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '联系地址',
  `license` char(50) NOT NULL DEFAULT '' COMMENT '营业执照',
  `licenseState` tinyint(1) NOT NULL DEFAULT '0' COMMENT '营业执照认证',
  `licenseInfo` char(255) NOT NULL DEFAULT '' COMMENT '认证备注',
  `regtime` int(10) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `regip` char(15) NOT NULL DEFAULT '' COMMENT '注册IP',
  `regipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP详细地址',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '帐户余额',
  `freeze` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '冻结金额',
  `point` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `promotion` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '保障金',
  `recid` int(10) NOT NULL DEFAULT '0' COMMENT '推广会员ID',
  `recfan` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已返现',
  `rectime` int(10) NOT NULL DEFAULT '0' COMMENT '返现时间',
  `online` int(10) NOT NULL DEFAULT '0' COMMENT '是否在线',
  `tempbg` int(10) NOT NULL DEFAULT '0' COMMENT '自定义背景图片',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `stateinfo` char(200) NOT NULL DEFAULT '' COMMENT '审核备注',
  `from` char(20) NOT NULL DEFAULT '' COMMENT '注册来源',
  `logincount` int(10) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `lastlogintime` int(10) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `lastloginip` char(15) NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `lastloginipaddr` char(100) NOT NULL DEFAULT '' COMMENT 'IP详细地址',
  `qq_conn` char(50) NOT NULL DEFAULT '' COMMENT 'qq快捷登录',
  `sina_conn` char(50) NOT NULL DEFAULT '' COMMENT '新浪微博快捷登录',
  `baidu_conn` char(50) NOT NULL DEFAULT '' COMMENT '百度快捷登录',
  `alipay_conn` char(50) NOT NULL DEFAULT '' COMMENT '支付宝快捷登录',
  `tqq_conn` char(50) NOT NULL DEFAULT '' COMMENT '腾讯微博快捷登录',
  `360_conn` char(50) NOT NULL DEFAULT '' COMMENT '360快捷登录',
  `renren_conn` char(50) NOT NULL DEFAULT '' COMMENT '人人快捷登录',
  `douban_conn` char(50) NOT NULL DEFAULT '' COMMENT '豆瓣快捷登录',
  `facebook_conn` char(50) NOT NULL DEFAULT '' COMMENT 'facebook快捷登录',
  `wechat_conn` char(50) NOT NULL DEFAULT '' COMMENT '微信快捷登录',
  `wechat_openid` char(50) NOT NULL DEFAULT '' COMMENT '微信openid',
  `wechat_mini_openid` char(50) DEFAULT '' COMMENT '小程序openid',
  `wechat_mini_session` char(50) DEFAULT '' COMMENT '小程序登陆session',
  `expired_notify_day` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一天提醒',
  `expired_notify_week` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一周提醒',
  `expired_notify_month` smallint(1) NOT NULL DEFAULT '0' COMMENT '到期前一月提醒',
  `purviews` text COMMENT '权限',
  `sourceclient` text COMMENT '来源客户端',
  `from_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分享人uid',
  `usertags` tinyint(4) NOT NULL DEFAULT '0',
  `overide` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `username` (`username`) USING BTREE,
  KEY `nickname` (`nickname`) USING BTREE,
  KEY `email` (`email`) USING BTREE,
  KEY `discount` (`discount`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `mtype` (`mtype`) USING BTREE,
  KEY `online` (`online`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1389 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网站会员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_address`
--

DROP TABLE IF EXISTS `huoniao_member_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `person` char(25) NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `tel` char(22) NOT NULL DEFAULT '' COMMENT '电话号码',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员收货地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_bid`
--

DROP TABLE IF EXISTS `huoniao_member_bid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_bid` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordernum` char(100) NOT NULL DEFAULT '' COMMENT '订单号',
  `module` char(50) NOT NULL DEFAULT '' COMMENT '模块',
  `part` char(50) NOT NULL DEFAULT '' COMMENT '栏目',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '推广会员',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '推广信息',
  `start` int(10) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '每日预算',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='竞价推广';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_cart`
--

DROP TABLE IF EXISTS `huoniao_member_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `shop` text COMMENT '商城',
  `tuan` text COMMENT '团购',
  `waimai` text COMMENT '外卖',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员购物车';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_collect`
--

DROP TABLE IF EXISTS `huoniao_member_collect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_collect` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `action` char(30) NOT NULL DEFAULT '' COMMENT '动作',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '信息ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  `visualphone` char(11) DEFAULT NULL,
  `visitorphone` char(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=160 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_complain`
--

DROP TABLE IF EXISTS `huoniao_member_complain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_complain` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `action` char(20) NOT NULL DEFAULT '' COMMENT '动作',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '信息ID',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '举报类型',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '举报说明',
  `phone` varchar(50) NOT NULL DEFAULT '' COMMENT '联系电话',
  `qq` varchar(50) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '举报会员',
  `ip` char(20) NOT NULL DEFAULT '' COMMENT '提交IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '操作备注',
  `opuid` int(10) NOT NULL DEFAULT '0' COMMENT '处理人',
  `optime` int(10) NOT NULL DEFAULT '0' COMMENT '处理时间',
  `commonid` int(10) NOT NULL DEFAULT '0' COMMENT '评论ID',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `action` (`action`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员举报';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_coverbg`
--

DROP TABLE IF EXISTS `huoniao_member_coverbg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_coverbg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '分类',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '标题',
  `litpic` char(30) NOT NULL DEFAULT '' COMMENT '缩略图',
  `big` char(30) NOT NULL DEFAULT '' COMMENT '大图',
  `rec` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `big` (`big`) USING BTREE,
  KEY `litpic` (`litpic`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `rec` (`rec`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员中心封面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_coverbg_type`
--

DROP TABLE IF EXISTS `huoniao_member_coverbg_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_coverbg_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员中心封面分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_fenxiao`
--

DROP TABLE IF EXISTS `huoniao_member_fenxiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_fenxiao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `by` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '来源uid',
  `child` int(10) NOT NULL DEFAULT '0' COMMENT '直接下线',
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分销等级',
  `amount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '佣金',
  `product` varchar(1000) NOT NULL DEFAULT '' COMMENT '商品',
  `fee` char(5) NOT NULL DEFAULT '' COMMENT '佣金比例',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `level` (`level`) USING BTREE,
  KEY `child` (`child`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分销记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_fenxiao_user`
--

DROP TABLE IF EXISTS `huoniao_member_fenxiao_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_fenxiao_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `phone` char(13) NOT NULL DEFAULT '' COMMENT '手机号',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态0-待审核1-已审核2审核拒绝',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分销商列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_follow`
--

DROP TABLE IF EXISTS `huoniao_member_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_follow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '会员id',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '关注的会员ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '关注时间',
  `for` char(5) NOT NULL DEFAULT '' COMMENT '关注类型',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `fid` (`fid`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员关注列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_friend`
--

DROP TABLE IF EXISTS `huoniao_member_friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_friend` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fid` int(10) NOT NULL DEFAULT '0' COMMENT '添加方',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '被添加方',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态(是否为好友)',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `delfrom` smallint(1) NOT NULL DEFAULT '0' COMMENT '添加方删除(隐藏)',
  `delto` smallint(1) NOT NULL DEFAULT '0' COMMENT '被添加方删除(隐藏)',
  `temp` smallint(1) NOT NULL DEFAULT '0' COMMENT '临时会话',
  `tempdelfrom` smallint(1) NOT NULL DEFAULT '0' COMMENT '添加方删除(隐藏)',
  `tempdelto` smallint(1) NOT NULL DEFAULT '0' COMMENT '被添加方删除(隐藏)',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`),
  KEY `tid` (`tid`),
  KEY `state` (`state`),
  KEY `date` (`date`),
  KEY `delfrom` (`delfrom`),
  KEY `delto` (`delto`),
  KEY `temp` (`temp`),
  KEY `tempdelfrom` (`tempdelfrom`),
  KEY `tempdelto` (`tempdelto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员好友';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_letter`
--

DROP TABLE IF EXISTS `huoniao_member_letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_letter` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `admin` int(10) NOT NULL DEFAULT '0' COMMENT '操作管理员',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0系统消息1邮件2短信',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '标题',
  `body` text NOT NULL COMMENT '内容',
  `urlParam` char(255) NOT NULL DEFAULT '' COMMENT '链接参数',
  `success` int(10) NOT NULL DEFAULT '0' COMMENT '成功',
  `error` int(10) NOT NULL DEFAULT '0' COMMENT '失败',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=417 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='站内信';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_letter_log`
--

DROP TABLE IF EXISTS `huoniao_member_letter_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_letter_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lid` int(10) NOT NULL DEFAULT '0' COMMENT '站内信ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '查看时间',
  `notice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已经通知',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `lid` (`lid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=443 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='站内信发送记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_level`
--

DROP TABLE IF EXISTS `huoniao_member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_level` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '等级名称',
  `cost` text NOT NULL COMMENT '费用设置',
  `privilege` text NOT NULL COMMENT '特权设置',
  `icon` char(60) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员等级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_login`
--

DROP TABLE IF EXISTS `huoniao_member_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `logintime` int(10) NOT NULL DEFAULT '0' COMMENT '登录时间',
  `loginip` char(15) NOT NULL DEFAULT '' COMMENT '登录IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5107 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员登录记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_message`
--

DROP TABLE IF EXISTS `huoniao_member_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '被留言会员ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '留言会员ID',
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '回复的留言ID',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '留言内容',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT 'ip',
  `ipaddr` varchar(50) NOT NULL DEFAULT '' COMMENT 'ip详细地址',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '留言时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员留言';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_money`
--

DROP TABLE IF EXISTS `huoniao_member_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_money` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '收支',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '操作金额',
  `info` char(255) NOT NULL DEFAULT '' COMMENT '操作原因',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=466 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员余额记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_point`
--

DROP TABLE IF EXISTS `huoniao_member_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_point` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '收支',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '操作积分',
  `info` char(100) NOT NULL DEFAULT '' COMMENT '操作原因',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1477 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员积分记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_promotion`
--

DROP TABLE IF EXISTS `huoniao_member_promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_promotion` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单编号',
  `title` varchar(50) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '说明',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='保障金记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_putforward`
--

DROP TABLE IF EXISTS `huoniao_member_putforward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_putforward` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `utype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型:交友会员类型',
  `module` char(15) NOT NULL DEFAULT '' COMMENT '模块',
  `type` char(15) NOT NULL DEFAULT '' COMMENT '提现方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `order_id` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提现时间',
  `paydate` char(20) NOT NULL DEFAULT '' COMMENT '支付成功时间',
  `cardname` char(30) NOT NULL COMMENT '收款人',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `bank` char(50) NOT NULL COMMENT '银行名称',
  `note` char(255) DEFAULT NULL COMMENT '提现结果',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='提现到第三方支付平台';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_qiandao`
--

DROP TABLE IF EXISTS `huoniao_member_qiandao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_qiandao` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `reward` varchar(100) NOT NULL DEFAULT '' COMMENT '获得积分',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '签到时间',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT 'ip',
  `ipaddr` varchar(100) NOT NULL DEFAULT '' COMMENT 'ip地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `date` (`date`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='签到记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_reward`
--

DROP TABLE IF EXISTS `huoniao_member_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_reward` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordernum` char(100) NOT NULL DEFAULT '' COMMENT '订单号',
  `module` char(50) NOT NULL DEFAULT '' COMMENT '模块',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '打赏会员',
  `to` int(10) NOT NULL DEFAULT '0' COMMENT '受赏会员',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '打赏信息',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '打赏金额',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '打赏时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `to` (`to`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='打赏记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_security`
--

DROP TABLE IF EXISTS `huoniao_member_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_security` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `question` char(50) NOT NULL DEFAULT '' COMMENT '问题',
  `answer` char(50) NOT NULL DEFAULT '' COMMENT '答案',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `question` (`question`) USING BTREE,
  KEY `answer` (`answer`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员密保问题';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_suggestion`
--

DROP TABLE IF EXISTS `huoniao_member_suggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_suggestion` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '意见内容',
  `phone` varchar(50) NOT NULL DEFAULT '' COMMENT '联系电话',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `ip` char(20) NOT NULL DEFAULT '' COMMENT '提交IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '操作备注',
  `opuid` int(10) NOT NULL DEFAULT '0' COMMENT '处理人',
  `optime` int(10) NOT NULL DEFAULT '0' COMMENT '处理时间',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='反馈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_visitor`
--

DROP TABLE IF EXISTS `huoniao_member_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_visitor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '被浏览会员ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '浏览时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员访客列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_withdraw`
--

DROP TABLE IF EXISTS `huoniao_member_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_withdraw` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `bank` char(50) NOT NULL DEFAULT '' COMMENT '银行名称',
  `cardnum` char(50) NOT NULL DEFAULT '' COMMENT '卡号',
  `cardname` char(30) NOT NULL DEFAULT '' COMMENT '收款人',
  `amount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `tdate` int(10) NOT NULL DEFAULT '0' COMMENT '申请时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `note` char(255) DEFAULT '' COMMENT '提现结果',
  `rdate` int(10) DEFAULT '0' COMMENT '回复时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='提现申请';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_member_withdraw_card`
--

DROP TABLE IF EXISTS `huoniao_member_withdraw_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_member_withdraw_card` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `bank` char(50) NOT NULL DEFAULT '' COMMENT '银行名称',
  `cardnum` char(50) NOT NULL DEFAULT '' COMMENT '帐号',
  `cardname` char(30) NOT NULL DEFAULT '' COMMENT '收款人姓名',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员提现账号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_mytag`
--

DROP TABLE IF EXISTS `huoniao_mytag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_mytag` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(60) NOT NULL DEFAULT '' COMMENT '标记说明',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `type` char(20) DEFAULT '' COMMENT '栏目',
  `start` int(10) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `config` text NOT NULL COMMENT '标记配置',
  `expbody` text NOT NULL COMMENT '过期显示内容',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '生成时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自定义标记';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_mytag_temp`
--

DROP TABLE IF EXISTS `huoniao_mytag_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_mytag_temp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '所属模块',
  `type` char(20) NOT NULL DEFAULT '' COMMENT '所属类别',
  `litpic` char(50) NOT NULL DEFAULT '' COMMENT '缩略图',
  `css` text NOT NULL COMMENT '样式代码',
  `isSystem` smallint(1) NOT NULL DEFAULT '1' COMMENT '是否为系统默认',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='标记模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_pageelement`
--

DROP TABLE IF EXISTS `huoniao_pageelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_pageelement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sort` char(20) NOT NULL DEFAULT '' COMMENT '分类',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '元素名称',
  `type` char(20) NOT NULL DEFAULT '' COMMENT '元素英文名称',
  `appstype` int(10) NOT NULL DEFAULT '0' COMMENT '应用分类',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `config` text NOT NULL COMMENT '设置',
  `theme` char(20) NOT NULL DEFAULT '' COMMENT '风格目录',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `appstype` (`appstype`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='专题拖动元素';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_pageelement_theme`
--

DROP TABLE IF EXISTS `huoniao_pageelement_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_pageelement_theme` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '元素ID',
  `name` char(20) NOT NULL DEFAULT '' COMMENT '风格名',
  `color` char(20) NOT NULL DEFAULT '' COMMENT '颜色名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=280 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='专题元素风格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_pageelement_type`
--

DROP TABLE IF EXISTS `huoniao_pageelement_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_pageelement_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '分类名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='专题元素分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_paotui_order`
--

DROP TABLE IF EXISTS `huoniao_paotui_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_paotui_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型 1:帮我买 2:帮我送',
  `shop` varchar(255) NOT NULL DEFAULT '' COMMENT '商品',
  `buyaddress` varchar(255) NOT NULL DEFAULT '' COMMENT '取货地址',
  `buylng` varchar(50) NOT NULL DEFAULT '' COMMENT '购买地址-经度',
  `buylat` varchar(50) NOT NULL DEFAULT '' COMMENT '购买地址-维度',
  `totime` int(10) NOT NULL DEFAULT '0' COMMENT '预计送达时间 分钟',
  `price` char(20) NOT NULL DEFAULT '' COMMENT '物品价值',
  `money` float(10,2) DEFAULT NULL COMMENT '物品价值',
  `tip` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '小费',
  `freight` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '跑腿费',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `peidate` int(10) NOT NULL DEFAULT '0' COMMENT '接单时间',
  `peisongid` int(10) NOT NULL DEFAULT '0' COMMENT '配送员',
  `person` varchar(50) NOT NULL DEFAULT '' COMMENT '联系人',
  `tel` varchar(50) NOT NULL DEFAULT '' COMMENT '电话',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '收货详细地址',
  `paytype` varchar(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '总费用',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '收货地址-经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '收货地址-维度',
  `okdate` int(10) NOT NULL DEFAULT '0' COMMENT '成功时间',
  `songdate` int(10) NOT NULL DEFAULT '0' COMMENT '配送时间',
  `failed` varchar(255) NOT NULL DEFAULT '' COMMENT '订单失败原因',
  `failedadmin` int(10) NOT NULL DEFAULT '0' COMMENT '无效订单操作人id',
  `refrundstate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款状态 1:成功',
  `refrunddate` int(10) NOT NULL DEFAULT '0' COMMENT '退款时间',
  `refrundno` varchar(50) DEFAULT '' COMMENT '退款流水号',
  `refrundfailed` varchar(255) NOT NULL DEFAULT '' COMMENT '退款失败错误码',
  `refrundadmin` int(10) NOT NULL DEFAULT '0' COMMENT '操作人id',
  `iscomment` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价 0:未评价 1:已评价',
  `peisongidlog` text COMMENT '配送员变更记录',
  `confirmdate` int(10) NOT NULL DEFAULT '0' COMMENT '确认时间',
  `weight` int(2) NOT NULL DEFAULT '0' COMMENT '重量',
  `addr1` int(10) NOT NULL DEFAULT '0' COMMENT '发货地址id',
  `addr2` int(10) NOT NULL DEFAULT '0' COMMENT '收货地址id',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `gettime` int(10) NOT NULL DEFAULT '0' COMMENT '取件时间',
  `gettel` varchar(50) NOT NULL DEFAULT '' COMMENT '取件电话',
  `getperson` varchar(50) NOT NULL DEFAULT '' COMMENT '取货联系人',
  `peisongpath` text COMMENT '地图路径',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `courier_pushed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '骑手推送',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='跑腿订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_paper_company`
--

DROP TABLE IF EXISTS `huoniao_paper_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_paper_company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '期刊名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `qq` char(20) NOT NULL DEFAULT '' COMMENT '联系QQ',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='报刊公司';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_paper_content`
--

DROP TABLE IF EXISTS `huoniao_paper_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_paper_content` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `forum` int(10) NOT NULL DEFAULT '0' COMMENT '所属版面',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `author` char(10) NOT NULL DEFAULT '' COMMENT '作者',
  `from` char(10) NOT NULL DEFAULT '' COMMENT '来源',
  `coor` char(15) NOT NULL DEFAULT '' COMMENT '座标',
  `body` text NOT NULL COMMENT '内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `litpic` char(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `forum` (`forum`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=756 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='报刊内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_paper_forum`
--

DROP TABLE IF EXISTS `huoniao_paper_forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_paper_forum` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company` int(10) NOT NULL DEFAULT '0' COMMENT '所属报刊',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '日期',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '版面名',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类别',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '图片',
  `seotitle` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `pdf` char(255) NOT NULL DEFAULT '' COMMENT 'pdf',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `date` (`date`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=205 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='报刊版面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_pay_log`
--

DROP TABLE IF EXISTS `huoniao_pay_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_pay_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordertype` char(20) NOT NULL DEFAULT '' COMMENT '订单类型',
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `body` text NOT NULL COMMENT '包含订单',
  `amount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `paytype` char(30) NOT NULL DEFAULT '' COMMENT '支付方式',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '生成时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordertype` (`ordertype`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1430 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='付款记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_paycard`
--

DROP TABLE IF EXISTS `huoniao_paycard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_paycard` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(20) NOT NULL DEFAULT '' COMMENT '所属模块',
  `cardnum` char(30) NOT NULL DEFAULT '' COMMENT '卡号',
  `memberid` int(8) NOT NULL DEFAULT '0' COMMENT '使用者',
  `usedate` int(10) NOT NULL DEFAULT '0' COMMENT '使用日期',
  `carddate` int(10) NOT NULL DEFAULT '0' COMMENT '生成日期',
  `expireddate` int(10) NOT NULL DEFAULT '0' COMMENT '有效期',
  `cardmoney` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '面值',
  `orderid` int(10) NOT NULL DEFAULT '0' COMMENT '所属订单',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cardnum` (`cardnum`) USING BTREE,
  KEY `memberid` (`memberid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='充值卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_phonebind`
--

DROP TABLE IF EXISTS `huoniao_phonebind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_phonebind` (
  `caller` char(11) NOT NULL,
  `callee` char(11) NOT NULL,
  `relationphone` char(11) NOT NULL,
  `expire` datetime DEFAULT NULL,
  `subscriptionId` varchar(50) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `reason` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_public_comment`
--

DROP TABLE IF EXISTS `huoniao_public_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_public_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '父id',
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '被回复的评论id',
  `type` char(60) NOT NULL DEFAULT '' COMMENT '评论对象',
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '评论对象id',
  `oid` int(10) NOT NULL DEFAULT '0' COMMENT '订单id',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价1:好评2:中评3:差评',
  `sco1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分',
  `content` text NOT NULL COMMENT '评论内容',
  `pics` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `audio` char(50) NOT NULL DEFAULT '' COMMENT '语音',
  `video` char(50) NOT NULL DEFAULT '' COMMENT '视频',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `zan` int(10) NOT NULL DEFAULT '0' COMMENT '赞',
  `zan_user` text NOT NULL COMMENT '赞过的用户',
  `isanony` tinyint(1) NOT NULL DEFAULT '0' COMMENT '匿名',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '三级id',
  `sco2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分2',
  `sco3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分3',
  `speid` char(50) NOT NULL DEFAULT '' COMMENT '产品规格',
  `specation` char(100) NOT NULL DEFAULT '' COMMENT '规格值',
  `peisongid` int(10) NOT NULL DEFAULT '0' COMMENT '配送员id',
  `star` tinyint(1) NOT NULL DEFAULT '0' COMMENT '星级',
  `starps` tinyint(1) NOT NULL DEFAULT '0' COMMENT '星级-配送员',
  `contentps` text COMMENT '评论内容-配送员',
  `reply` text COMMENT '回复内容',
  `replydate` int(10) NOT NULL DEFAULT '0' COMMENT '回复时间',
  `time` int(4) NOT NULL DEFAULT '0' COMMENT '订单完成时间',
  `masterid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息发布者ID',
  `isread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已阅读',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `oid` (`oid`) USING BTREE,
  KEY `rating` (`rating`) USING BTREE,
  KEY `star` (`sco1`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='通用评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_public_up`
--

DROP TABLE IF EXISTS `huoniao_public_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_public_up` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '点赞ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '信息ID',
  `ruid` int(10) NOT NULL DEFAULT '0' COMMENT '点赞人uid',
  `action` char(60) NOT NULL DEFAULT '' COMMENT '动作',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `puctime` int(10) NOT NULL DEFAULT '0' COMMENT '点赞时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0：信息；1：评论',
  `isread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已阅读',
  PRIMARY KEY (`id`),
  KEY `ruid` (`ruid`),
  KEY `uid` (`uid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='点赞表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_quanjingcommon`
--

DROP TABLE IF EXISTS `huoniao_quanjingcommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_quanjingcommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='全景评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_quanjinglist`
--

DROP TABLE IF EXISTS `huoniao_quanjinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_quanjinglist` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `subtitle` char(100) NOT NULL DEFAULT '' COMMENT '短标题',
  `flag` set('h','r','b','p','t') NOT NULL DEFAULT '' COMMENT '附加属性',
  `redirecturl` varchar(255) DEFAULT '' COMMENT '跳转地址',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `litpic` char(255) DEFAULT '' COMMENT '缩略图',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `sourceurl` char(200) NOT NULL DEFAULT '' COMMENT '来源网址',
  `quanjingtype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '视频类型',
  `file` varchar(255) NOT NULL DEFAULT '' COMMENT '文件地址',
  `writer` char(20) NOT NULL DEFAULT '' COMMENT '作者',
  `typeid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `keywords` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `admin` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE,
  KEY `del` (`del`,`arcrank`,`typeid`,`flag`,`litpic`,`weight`) USING BTREE,
  KEY `flag` (`flag`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `keywords` (`keywords`) USING BTREE,
  KEY `weight` (`weight`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='全景信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_quanjingtype`
--

DROP TABLE IF EXISTS `huoniao_quanjingtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_quanjingtype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `pinyin` char(100) NOT NULL DEFAULT '' COMMENT '分类全拼',
  `py` char(50) NOT NULL DEFAULT '' COMMENT '分类首字母',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='全景分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_relationphone`
--

DROP TABLE IF EXISTS `huoniao_relationphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_relationphone` (
  `phone` char(11) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_case`
--

DROP TABLE IF EXISTS `huoniao_renovation_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_case` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类别',
  `kongjian` char(50) NOT NULL DEFAULT '' COMMENT '装修空间',
  `jubu` char(50) NOT NULL DEFAULT '' COMMENT '局部位置',
  `comstyle` int(10) NOT NULL DEFAULT '0' COMMENT '商业分类',
  `style` int(10) NOT NULL DEFAULT '0' COMMENT '风格',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `designer` int(10) NOT NULL DEFAULT '0' COMMENT '设计师',
  `apartment` int(10) NOT NULL DEFAULT '0' COMMENT '预算',
  `units` int(10) NOT NULL DEFAULT '0' COMMENT '户型',
  `area` int(5) NOT NULL DEFAULT '0' COMMENT '面积',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '1' COMMENT '浏览量',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `note` text NOT NULL COMMENT '简介',
  `pics` text NOT NULL COMMENT '图集',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `designer` (`designer`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='效果图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_community`
--

DROP TABLE IF EXISTS `huoniao_renovation_community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_community` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '楼盘名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '楼盘图片',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标位置',
  `price` int(5) NOT NULL DEFAULT '0' COMMENT '售价',
  `protype` char(10) NOT NULL DEFAULT '' COMMENT '物业类别',
  `tese` char(100) NOT NULL DEFAULT '' COMMENT '楼盘特色',
  `zhuangxiu` char(20) NOT NULL DEFAULT '' COMMENT '装修情况',
  `kfs` char(50) NOT NULL DEFAULT '' COMMENT '开发商',
  `buildage` int(3) NOT NULL DEFAULT '0' COMMENT '产权年限',
  `opendate` int(10) NOT NULL DEFAULT '0' COMMENT '竣工时间',
  `buildtype` char(50) NOT NULL DEFAULT '' COMMENT '建筑类别',
  `huanxian` char(20) NOT NULL DEFAULT '' COMMENT '环线位置',
  `rongji` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '容积率',
  `green` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '绿化率',
  `proprice` char(30) NOT NULL DEFAULT '' COMMENT '物业费',
  `property` char(50) NOT NULL DEFAULT '' COMMENT '物业公司',
  `buildarea` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '建筑面积',
  `planarea` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '占地面积',
  `planhouse` int(10) NOT NULL DEFAULT '0' COMMENT '总户数',
  `note` text NOT NULL COMMENT '楼盘介绍',
  `config` text NOT NULL COMMENT '周边配套',
  `pics` text NOT NULL COMMENT '相册',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修小区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_diary`
--

DROP TABLE IF EXISTS `huoniao_renovation_diary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_diary` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `style` int(10) NOT NULL DEFAULT '0' COMMENT '风格',
  `units` int(10) NOT NULL DEFAULT '0' COMMENT '户型',
  `comstyle` int(10) NOT NULL DEFAULT '0' COMMENT '公装类型',
  `btype` int(10) NOT NULL DEFAULT '0' COMMENT '装修方式',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `area` int(5) NOT NULL DEFAULT '0' COMMENT '面积',
  `unitspic` char(100) NOT NULL DEFAULT '' COMMENT '户型图',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `designer` int(10) NOT NULL DEFAULT '0' COMMENT '设计师',
  `case` int(10) NOT NULL DEFAULT '0' COMMENT '设计图',
  `communityid` int(10) NOT NULL DEFAULT '0' COMMENT '小区ID',
  `began` int(10) NOT NULL DEFAULT '0' COMMENT '开工日期',
  `end` char(30) NOT NULL DEFAULT '' COMMENT '竣工日期',
  `visit` smallint(1) NOT NULL DEFAULT '0' COMMENT '接受参观',
  `pics` text NOT NULL COMMENT '工地现场',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '1' COMMENT '浏览量',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `designer` (`designer`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='施工案例';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_diarylist`
--

DROP TABLE IF EXISTS `huoniao_renovation_diarylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_diarylist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `diary` int(10) NOT NULL DEFAULT '0' COMMENT '所属日记',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `body` text NOT NULL COMMENT '日记内容',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `diary` (`diary`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修日记列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_entrust`
--

DROP TABLE IF EXISTS `huoniao_renovation_entrust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_entrust` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '区域ID',
  `body` text NOT NULL COMMENT '其他',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `ipaddr` char(100) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `ip` (`ip`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修免费设计申请';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_guest`
--

DROP TABLE IF EXISTS `huoniao_renovation_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_guest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company` int(10) NOT NULL DEFAULT '0' COMMENT '公司ID',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `ipaddr` char(60) NOT NULL,
  `note` text NOT NULL,
  `reply` text COMMENT '回复',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '留言时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修留言';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_news`
--

DROP TABLE IF EXISTS `huoniao_renovation_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `click` int(8) NOT NULL DEFAULT '0' COMMENT '浏览',
  `weight` int(10) NOT NULL COMMENT '排序',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `writer` char(30) NOT NULL DEFAULT '' COMMENT '作者',
  `keyword` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(255) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=488 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_newstype`
--

DROP TABLE IF EXISTS `huoniao_renovation_newstype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_newstype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='装修资讯分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_rese`
--

DROP TABLE IF EXISTS `huoniao_renovation_rese`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_rese` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company` int(10) NOT NULL DEFAULT '0' COMMENT '预约公司',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '设计师',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `community` char(60) NOT NULL DEFAULT '' COMMENT '小区',
  `appointment` int(10) NOT NULL DEFAULT '0' COMMENT '预约时间',
  `budget` char(30) NOT NULL DEFAULT '' COMMENT '预算',
  `units` char(30) NOT NULL DEFAULT '' COMMENT '户型',
  `body` text NOT NULL COMMENT '留言内容',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `ipaddr` char(100) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `community` (`community`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修预约';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_store`
--

DROP TABLE IF EXISTS `huoniao_renovation_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_store` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `company` char(60) NOT NULL DEFAULT '' COMMENT '公司名称',
  `safeguard` float(8,0) NOT NULL DEFAULT '0' COMMENT '保障金',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `logo` char(100) NOT NULL DEFAULT '' COMMENT '公司LOGO',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '对应会员',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '客服电话',
  `qq` char(30) NOT NULL DEFAULT '' COMMENT '客服QQ',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '公司地址',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '经纬度',
  `range` char(100) NOT NULL DEFAULT '' COMMENT '服务区域',
  `jiastyle` char(100) NOT NULL DEFAULT '' COMMENT '家庭装修分类',
  `comstyle` char(100) NOT NULL DEFAULT '' COMMENT '商业装修分类',
  `style` char(100) NOT NULL DEFAULT '' COMMENT '装修风格',
  `body` text NOT NULL COMMENT '公司介绍',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `license` smallint(1) NOT NULL DEFAULT '0' COMMENT '营业执照认证',
  `certi` smallint(1) NOT NULL DEFAULT '0' COMMENT '认证',
  `property` char(50) NOT NULL DEFAULT '' COMMENT '属性',
  `storetemp` char(30) NOT NULL DEFAULT '' COMMENT '模板',
  `seotitle` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `scale` char(255) NOT NULL DEFAULT '' COMMENT '公司规模',
  `afterService` text NOT NULL COMMENT '装后服务',
  `initDesign` text NOT NULL COMMENT '初期设计/量房',
  `initBudget` text NOT NULL COMMENT '初期预算/洽谈方式',
  `detaDesign` text NOT NULL COMMENT '深化设计',
  `detaBudget` text NOT NULL COMMENT '深化预算',
  `material` text NOT NULL COMMENT '材料质量',
  `normative` text NOT NULL COMMENT '合同规范性',
  `speService` text NOT NULL COMMENT '特色服务',
  `certs` text COMMENT '资质',
  `comType` char(60) NOT NULL DEFAULT '' COMMENT '企业类型',
  `regFunds` char(50) NOT NULL DEFAULT '' COMMENT '注册资金',
  `operPeriodb` int(10) NOT NULL DEFAULT '0' COMMENT '营业开始时间',
  `operPeriode` int(10) NOT NULL DEFAULT '0' COMMENT '营业结束时间',
  `founded` int(10) NOT NULL DEFAULT '0' COMMENT '成立日期',
  `authority` char(100) NOT NULL DEFAULT '' COMMENT '登记机关',
  `operRange` char(255) NOT NULL DEFAULT '' COMMENT '经营范围',
  `inspection` int(10) NOT NULL DEFAULT '0' COMMENT '年检时间',
  `regnumber` char(60) NOT NULL DEFAULT '' COMMENT '注册号',
  `legalPer` char(20) NOT NULL DEFAULT '' COMMENT '法定代表人',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修公司';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_storesale`
--

DROP TABLE IF EXISTS `huoniao_renovation_storesale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_storesale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `store` int(8) NOT NULL COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `store` (`store`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='公司促销';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_team`
--

DROP TABLE IF EXISTS `huoniao_renovation_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_team` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '姓名',
  `works` int(2) NOT NULL DEFAULT '0' COMMENT '工作经验',
  `post` char(20) NOT NULL DEFAULT '' COMMENT '职位',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属会员',
  `photo` char(100) NOT NULL DEFAULT '' COMMENT '头像',
  `company` int(10) NOT NULL DEFAULT '0' COMMENT '所属公司',
  `special` char(100) NOT NULL DEFAULT '' COMMENT '专长',
  `style` char(100) NOT NULL DEFAULT '' COMMENT '风格',
  `idea` char(100) NOT NULL DEFAULT '' COMMENT '理念',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '个人介绍',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `works` (`works`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `company` (`company`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='设计师';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_toubiao`
--

DROP TABLE IF EXISTS `huoniao_renovation_toubiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_toubiao` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aid` int(10) NOT NULL DEFAULT '0' COMMENT '投标对象',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '投标人',
  `material` int(8) NOT NULL DEFAULT '0' COMMENT '主材费',
  `auxiliary` int(8) NOT NULL DEFAULT '0' COMMENT '辅材费',
  `labor` int(8) NOT NULL DEFAULT '0' COMMENT '人工费',
  `manage` int(8) NOT NULL DEFAULT '0' COMMENT '管理费',
  `design` int(8) NOT NULL DEFAULT '0' COMMENT '设计费',
  `note` text NOT NULL COMMENT '备注',
  `property` smallint(1) NOT NULL DEFAULT '0' COMMENT '附件属性',
  `file` char(100) NOT NULL DEFAULT '' COMMENT '附件',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '投标时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修投标';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_type`
--

DROP TABLE IF EXISTS `huoniao_renovation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=595 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='装修分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_visit`
--

DROP TABLE IF EXISTS `huoniao_renovation_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_visit` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `case` int(10) NOT NULL DEFAULT '0' COMMENT '施工案例',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `ipaddr` char(100) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `company` (`case`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='装修预约';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovation_zhaobiao`
--

DROP TABLE IF EXISTS `huoniao_renovation_zhaobiao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovation_zhaobiao` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `btype` int(10) NOT NULL DEFAULT '0' COMMENT '类型',
  `budget` int(10) NOT NULL DEFAULT '0' COMMENT '预算',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '地址',
  `community` char(60) NOT NULL DEFAULT '' COMMENT '小区名称',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `nature` int(10) NOT NULL DEFAULT '0' COMMENT '性质',
  `area` int(5) NOT NULL DEFAULT '0' COMMENT '面积',
  `floorplans` char(100) NOT NULL DEFAULT '' COMMENT '户型图',
  `start` int(10) NOT NULL DEFAULT '0' COMMENT '开工时间',
  `end` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `note` text NOT NULL COMMENT '说明',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '管理会员',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `email` char(100) NOT NULL DEFAULT '' COMMENT '邮箱',
  `qq` char(30) NOT NULL DEFAULT '' COMMENT 'QQ',
  `appointment` smallint(1) NOT NULL DEFAULT '0' COMMENT '预约时间',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '查看次数',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `btype` (`btype`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `community` (`community`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='装修招标';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_renovationaddr`
--

DROP TABLE IF EXISTS `huoniao_renovationaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_renovationaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=279 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='装修区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_safeqa`
--

DROP TABLE IF EXISTS `huoniao_safeqa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_safeqa` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `question` char(30) NOT NULL DEFAULT '' COMMENT '问题',
  `answer` char(30) NOT NULL DEFAULT '' COMMENT '答案',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `question` (`question`) USING BTREE,
  KEY `answer` (`answer`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='安全问答';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_brand`
--

DROP TABLE IF EXISTS `huoniao_shop_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '网站名称',
  `logo` char(100) NOT NULL DEFAULT '' COMMENT '品牌logo',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `rec` smallint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城品牌';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_brandtype`
--

DROP TABLE IF EXISTS `huoniao_shop_brandtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_brandtype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城品牌分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_category`
--

DROP TABLE IF EXISTS `huoniao_shop_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=474 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城店铺分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_common`
--

DROP TABLE IF EXISTS `huoniao_shop_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_common` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '订单ID',
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `speid` char(50) NOT NULL DEFAULT '' COMMENT '产品规格',
  `specation` char(100) NOT NULL DEFAULT '' COMMENT '规格值',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `score1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分1',
  `score2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分2',
  `score3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分3',
  `pics` tinytext COMMENT '图片',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_item`
--

DROP TABLE IF EXISTS `huoniao_shop_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_item` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `flag` set('r','w','c') NOT NULL COMMENT 'r:必填 w:可输入 c:多选',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城分类属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_logistictemplate`
--

DROP TABLE IF EXISTS `huoniao_shop_logistictemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_logistictemplate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '商家ID',
  `title` char(50) NOT NULL DEFAULT '' COMMENT '名称',
  `bearFreight` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否包邮',
  `valuation` tinyint(1) NOT NULL DEFAULT '0' COMMENT '计价方式',
  `express_start` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '默认运费单位/数量',
  `express_postage` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '默认运费',
  `express_plus` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '续加单位/数量',
  `express_postageplus` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '增加运费',
  `preferentialStandard` tinyint(5) NOT NULL DEFAULT '0' COMMENT '满几件包邮',
  `preferentialMoney` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '满多少元包邮',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='运费模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_news`
--

DROP TABLE IF EXISTS `huoniao_shop_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `litpic` char(50) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_news_type`
--

DROP TABLE IF EXISTS `huoniao_shop_news_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_news_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城资讯分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_noticelist`
--

DROP TABLE IF EXISTS `huoniao_shop_noticelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_noticelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `redirecturl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `litpic` char(20) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_order`
--

DROP TABLE IF EXISTS `huoniao_shop_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ordernum` char(30) NOT NULL DEFAULT '' COMMENT '订单号',
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '商铺ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `orderstate` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `orderdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytype` char(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '收货地址',
  `contact` char(60) NOT NULL DEFAULT '' COMMENT '联系方式',
  `note` char(100) NOT NULL DEFAULT '' COMMENT '买家备注',
  `common` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价',
  `exp-company` char(20) DEFAULT '' COMMENT '发货快递公司',
  `exp-number` char(20) DEFAULT '' COMMENT '发货快递单号',
  `exp-date` int(10) DEFAULT '0' COMMENT '发货时间',
  `ret-state` tinyint(1) DEFAULT '0' COMMENT '申请退款',
  `ret-type` char(20) DEFAULT '' COMMENT '退款原因',
  `ret-note` text COMMENT '退款说明',
  `ret-pics` char(255) DEFAULT '' COMMENT '恳款凭证',
  `ret-date` int(10) DEFAULT '0' COMMENT '申请时间',
  `ret-s-note` text COMMENT '卖家回复',
  `ret-s-pics` char(255) DEFAULT '' COMMENT '卖家回复凭证',
  `ret-s-date` int(10) DEFAULT '0' COMMENT '卖家回复时间',
  `ret-ok-date` int(10) DEFAULT '0' COMMENT '退款确定时间',
  `tab` varchar(255) NOT NULL DEFAULT '' COMMENT '模块名',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE,
  KEY `orderstate` (`orderstate`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_order_product`
--

DROP TABLE IF EXISTS `huoniao_shop_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_order_product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(10) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `proid` int(10) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `speid` char(50) NOT NULL DEFAULT '' COMMENT '规格值',
  `specation` char(50) NOT NULL DEFAULT '' COMMENT '规格描述',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '数量',
  `logistic` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `discount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '涨价/折扣',
  `point` int(10) NOT NULL DEFAULT '0' COMMENT '使用的积分',
  `balance` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '使用的余额',
  `payprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城订单商品内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_product`
--

DROP TABLE IF EXISTS `huoniao_shop_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '商品名称',
  `brand` int(10) NOT NULL DEFAULT '0' COMMENT '品牌',
  `property` text NOT NULL COMMENT '商品属性',
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '所属商家',
  `category` char(60) NOT NULL DEFAULT '0' COMMENT '店铺分类',
  `mprice` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '市场价格',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '一口价',
  `logistic` int(10) NOT NULL DEFAULT '0' COMMENT '物流模板',
  `volume` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '体积',
  `weight` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `specification` text NOT NULL COMMENT '规格匹配表',
  `inventory` int(5) NOT NULL DEFAULT '0' COMMENT '库存量',
  `limit` int(5) NOT NULL DEFAULT '0' COMMENT '限购数量',
  `sales` int(8) NOT NULL DEFAULT '0' COMMENT '销量',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `flag` char(30) NOT NULL DEFAULT '' COMMENT '属性',
  `btime` int(10) NOT NULL DEFAULT '0' COMMENT '限时抢开始时间',
  `etime` int(10) NOT NULL DEFAULT '0' COMMENT '限时抢结束时间',
  `pics` text NOT NULL COMMENT '图集',
  `body` text NOT NULL COMMENT '商品描述',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `kstime` int(10) NOT NULL DEFAULT '0' COMMENT '秒杀开始时间',
  `ketime` int(10) NOT NULL DEFAULT '0' COMMENT '秒杀结束时间',
  `fx_reward` char(6) NOT NULL DEFAULT '' COMMENT '分销奖励金',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `brand` (`brand`) USING BTREE,
  KEY `store` (`store`) USING BTREE,
  KEY `category` (`category`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=993 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_specification`
--

DROP TABLE IF EXISTS `huoniao_shop_specification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_specification` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城规格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_store`
--

DROP TABLE IF EXISTS `huoniao_shop_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_store` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '店铺名',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `company` char(60) NOT NULL DEFAULT '' COMMENT '公司名称',
  `referred` char(20) NOT NULL DEFAULT '' COMMENT '简称',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在地',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '地址',
  `industry` int(10) NOT NULL DEFAULT '0' COMMENT '经营行业',
  `project` char(100) NOT NULL DEFAULT '' COMMENT '主营项目',
  `logo` char(100) NOT NULL DEFAULT '' COMMENT '店铺logo',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '所属用户',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `tel` char(30) NOT NULL DEFAULT '' COMMENT '客服电话',
  `qq` char(30) NOT NULL DEFAULT '' COMMENT '客服QQ',
  `note` text NOT NULL COMMENT '店铺简介',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '店铺状态',
  `certi` smallint(1) NOT NULL DEFAULT '0' COMMENT '认证',
  `rec` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `company` (`company`) USING BTREE,
  KEY `addrid` (`addrid`) USING BTREE,
  KEY `industry` (`industry`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城店铺';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shop_type`
--

DROP TABLE IF EXISTS `huoniao_shop_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shop_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `spe` char(255) NOT NULL DEFAULT '' COMMENT '关联规格',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=259 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商城分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_shopaddr`
--

DROP TABLE IF EXISTS `huoniao_shopaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_shopaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=276 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='商城地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_admin_notice`
--

DROP TABLE IF EXISTS `huoniao_site_admin_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_admin_notice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(50) NOT NULL DEFAULT '' COMMENT '所属模块',
  `part` char(100) NOT NULL DEFAULT '' COMMENT '栏目',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=288 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='后台消息通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_area`
--

DROP TABLE IF EXISTS `huoniao_site_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_area` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '上级地区 ID',
  `typename` varchar(20) NOT NULL DEFAULT '' COMMENT '区域名称',
  `weight` smallint(6) NOT NULL DEFAULT '0' COMMENT '排列顺序',
  `pinyin` varchar(50) NOT NULL DEFAULT '' COMMENT '拼音',
  `level` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '地区等级：1 省级；2 市级；3 县级；4 乡镇',
  `weather_code` varchar(20) NOT NULL DEFAULT '' COMMENT '天气代码',
  `longitude` char(50) NOT NULL DEFAULT '' COMMENT '经度',
  `latitude` char(50) NOT NULL DEFAULT '' COMMENT '纬度',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parentid` (`parentid`) USING BTREE,
  KEY `typename` (`typename`) USING BTREE,
  KEY `pinyin` (`pinyin`) USING BTREE,
  KEY `weather_coe` (`weather_code`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=45094 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_city`
--

DROP TABLE IF EXISTS `huoniao_site_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_city` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `admin` int(10) NOT NULL DEFAULT '0' COMMENT '城市管理员',
  `default` smallint(1) NOT NULL DEFAULT '0' COMMENT '默认城市',
  `hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '热门',
  `config` text NOT NULL COMMENT '配置信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=164 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分站城市';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_city_circle`
--

DROP TABLE IF EXISTS `huoniao_site_city_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_city_circle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `qid` int(10) NOT NULL DEFAULT '0' COMMENT '区域ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '热门',
  `openStart` char(4) DEFAULT NULL COMMENT '开始时间',
  `openEnd` char(4) DEFAULT NULL COMMENT '结束时间',
  `tel` char(50) DEFAULT NULL COMMENT '电话',
  `address` char(100) DEFAULT NULL COMMENT '地址',
  `litpic` char(100) DEFAULT '' COMMENT '缩略图',
  `lng` varchar(50) DEFAULT '' COMMENT '地图经度',
  `lat` varchar(50) DEFAULT '' COMMENT '地图纬度',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='城市商圈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_cron`
--

DROP TABLE IF EXISTS `huoniao_site_cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_cron` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '所属频道',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '任务名称',
  `type` varchar(10) NOT NULL DEFAULT '' COMMENT '任务类型month/week/day/hour/now',
  `daytime` varchar(50) NOT NULL DEFAULT '' COMMENT '循环类型时间（日-时-分）',
  `file` varchar(30) NOT NULL DEFAULT '' COMMENT '计划任务执行文件',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `ctime` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ltime` int(10) NOT NULL DEFAULT '0' COMMENT '上次执行结束时间',
  `ntime` int(10) NOT NULL DEFAULT '0' COMMENT '下一次执行时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id` (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `daytime` (`daytime`) USING BTREE,
  KEY `file` (`file`) USING BTREE,
  KEY `ltime` (`ltime`) USING BTREE,
  KEY `ntime` (`ntime`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='计划任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_followmap`
--

DROP TABLE IF EXISTS `huoniao_site_followmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_followmap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL COMMENT '点关注的用户',
  `userid_b` int(255) NOT NULL COMMENT '被关注的用户',
  `date` int(11) NOT NULL,
  `temp` varchar(255) NOT NULL COMMENT '模板(video、quanjing、live）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='关注表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_friendlinklist`
--

DROP TABLE IF EXISTS `huoniao_site_friendlinklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_friendlinklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `module` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `sitename` char(60) NOT NULL DEFAULT '' COMMENT '网站名称',
  `sitelink` char(255) NOT NULL DEFAULT '' COMMENT '网站地址',
  `litpic` char(100) NOT NULL DEFAULT '0' COMMENT '网站LOGO',
  `weight` int(10) NOT NULL COMMENT '排序',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=223 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='友情链接';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_friendlinktype`
--

DROP TABLE IF EXISTS `huoniao_site_friendlinktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_friendlinktype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `model` char(30) NOT NULL DEFAULT '' COMMENT '属性模块',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='友情链接分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_helpslist`
--

DROP TABLE IF EXISTS `huoniao_site_helpslist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_helpslist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='帮助信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_helpstype`
--

DROP TABLE IF EXISTS `huoniao_site_helpstype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_helpstype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='帮助分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_hotkeywords`
--

DROP TABLE IF EXISTS `huoniao_site_hotkeywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_hotkeywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `module` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `keyword` char(30) NOT NULL DEFAULT '' COMMENT '关键字',
  `href` char(100) NOT NULL DEFAULT '' COMMENT '链接地址',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '字体颜色',
  `target` smallint(1) NOT NULL DEFAULT '0' COMMENT '打开方式',
  `blod` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否加粗',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `keyword` (`keyword`) USING BTREE,
  KEY `module` (`module`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='网站热门关键字';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_loginconnect`
--

DROP TABLE IF EXISTS `huoniao_site_loginconnect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_loginconnect` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` char(30) NOT NULL DEFAULT '' COMMENT '支付代码',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '支付方式名称',
  `desc` text NOT NULL COMMENT '说明',
  `config` text NOT NULL COMMENT '帐号配置',
  `weight` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '安装时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='整合第三方登录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_mailtemp`
--

DROP TABLE IF EXISTS `huoniao_site_mailtemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_mailtemp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(50) NOT NULL DEFAULT '' COMMENT '频道',
  `system` smallint(1) NOT NULL DEFAULT '0' COMMENT '系统模板，不可删除',
  `temp` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '邮件标题',
  `content` text NOT NULL COMMENT '邮件内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_messagelog`
--

DROP TABLE IF EXISTS `huoniao_site_messagelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_messagelog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(30) NOT NULL DEFAULT '' COMMENT '信息类型',
  `user` char(60) NOT NULL DEFAULT '' COMMENT '收件人',
  `lei` char(20) NOT NULL DEFAULT '' COMMENT '发送类型',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '主题',
  `body` text NOT NULL COMMENT '内容',
  `code` char(20) NOT NULL DEFAULT '' COMMENT '验证关键字',
  `tempid` char(100) NOT NULL DEFAULT '' COMMENT '平台模板ID',
  `by` int(10) NOT NULL COMMENT '操作人',
  `state` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发送时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `user` (`user`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1097 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='信息发送日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_module`
--

DROP TABLE IF EXISTS `huoniao_site_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_module` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `parentid` int(5) NOT NULL DEFAULT '0' COMMENT '上线目录',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模块名',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '英文识别码',
  `icon` char(100) NOT NULL DEFAULT '' COMMENT '图标',
  `note` text COMMENT '模块描述',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `weight` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `subnav` text COMMENT '子级菜单',
  `filelist` text COMMENT '模块文件列表',
  `domainRules` text COMMENT '一级、二级域名规则',
  `catalogRules` text COMMENT '子目录规则',
  `delsql` text COMMENT '卸载',
  `version` char(30) NOT NULL DEFAULT '' COMMENT '版本号',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '安装时间',
  `wx` smallint(1) NOT NULL DEFAULT '0' COMMENT '小程序开关',
  `bold` smallint(1) NOT NULL DEFAULT '0' COMMENT '加粗',
  `target` smallint(1) NOT NULL DEFAULT '0' COMMENT '新窗口',
  `color` varchar(7) NOT NULL DEFAULT '' COMMENT '颜色',
  `link` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `subject` varchar(30) NOT NULL DEFAULT '' COMMENT '自定义标题',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统模块管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_noticelist`
--

DROP TABLE IF EXISTS `huoniao_site_noticelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_noticelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `redirecturl` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网站公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_notify`
--

DROP TABLE IF EXISTS `huoniao_site_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_notify` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '消息名称',
  `email_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '邮件状态',
  `email_title` varchar(255) NOT NULL DEFAULT '' COMMENT '邮件标题',
  `email_body` text NOT NULL COMMENT '邮件模板',
  `sms_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '短信状态',
  `sms_tempid` varchar(100) NOT NULL DEFAULT '' COMMENT '平台模板ID',
  `sms_body` text NOT NULL COMMENT '短信模板',
  `wechat_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '微信状态',
  `wechat_tempid` varchar(100) NOT NULL DEFAULT '' COMMENT '微信模板ID',
  `wechat_body` text NOT NULL COMMENT '微信模板',
  `site_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '网页通知状态',
  `site_title` varchar(255) NOT NULL DEFAULT '' COMMENT '网页通知标题',
  `site_body` text NOT NULL COMMENT '网页通知内容',
  `app_state` smallint(1) NOT NULL DEFAULT '0' COMMENT 'app推送状态',
  `app_title` varchar(100) NOT NULL DEFAULT '' COMMENT 'APP推送标题',
  `app_body` varchar(255) NOT NULL DEFAULT '' COMMENT 'APP推送内容',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `system` smallint(1) NOT NULL DEFAULT '1' COMMENT '系统模板',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='消息通知配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_organizat`
--

DROP TABLE IF EXISTS `huoniao_site_organizat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_organizat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parentid` int(10) NOT NULL DEFAULT '0' COMMENT '父级id',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '组织名称',
  `admin` char(50) NOT NULL DEFAULT '' COMMENT '管理员id',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='审批流程组织架构';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_payment`
--

DROP TABLE IF EXISTS `huoniao_site_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_payment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pay_code` char(30) NOT NULL DEFAULT '' COMMENT '支付代码',
  `pay_name` char(30) NOT NULL DEFAULT '' COMMENT '支付方式名称',
  `pay_desc` text NOT NULL COMMENT '说明',
  `pay_config` text NOT NULL COMMENT '帐号配置',
  `weight` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '安装时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='支付方式';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_plugins`
--

DROP TABLE IF EXISTS `huoniao_site_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_plugins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '插件官网ID',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '插件名称',
  `version` varchar(100) NOT NULL DEFAULT '' COMMENT '版本号',
  `update` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `author` varchar(100) NOT NULL DEFAULT '' COMMENT '作者',
  `delsql` text NOT NULL COMMENT '卸载表',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '安装时间',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统插件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_process`
--

DROP TABLE IF EXISTS `huoniao_site_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_process` (
  `processid` char(32) NOT NULL,
  `expiry` int(10) DEFAULT NULL,
  `extra` int(10) DEFAULT NULL,
  PRIMARY KEY (`processid`) USING BTREE,
  KEY `expiry` (`expiry`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='计划任务进程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_search`
--

DROP TABLE IF EXISTS `huoniao_site_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_search` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `module` char(30) NOT NULL DEFAULT '' COMMENT '所属模块',
  `keyword` char(50) NOT NULL DEFAULT '' COMMENT '关键词',
  `count` mediumint(8) NOT NULL DEFAULT '0' COMMENT '搜索次数',
  `lasttime` int(10) NOT NULL DEFAULT '0' COMMENT '最后搜索时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=842 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='搜索关键词';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_singellist`
--

DROP TABLE IF EXISTS `huoniao_site_singellist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_singellist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(30) NOT NULL DEFAULT '' COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `body` text NOT NULL COMMENT '内容',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='单页文档';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_smstemp`
--

DROP TABLE IF EXISTS `huoniao_site_smstemp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_smstemp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(50) NOT NULL DEFAULT '' COMMENT '频道',
  `system` smallint(1) NOT NULL DEFAULT '0' COMMENT '系统模板，不可删除',
  `temp` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `tempid` char(100) NOT NULL DEFAULT '' COMMENT '模板ID',
  `content` text NOT NULL COMMENT '短信内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='短信模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_sub_tablelist`
--

DROP TABLE IF EXISTS `huoniao_site_sub_tablelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_sub_tablelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service` varchar(50) NOT NULL COMMENT '服务',
  `table_name` varchar(100) NOT NULL COMMENT '分表名',
  `begin_id` int(20) NOT NULL COMMENT '开始自增id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分表信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_subway`
--

DROP TABLE IF EXISTS `huoniao_site_subway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_subway` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '线路名',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='城市地铁';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_subway_station`
--

DROP TABLE IF EXISTS `huoniao_site_subway_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_subway_station` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '线路ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '站点名',
  `weight` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2285 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='地铁站点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_verify`
--

DROP TABLE IF EXISTS `huoniao_site_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_verify` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` char(10) NOT NULL DEFAULT '' COMMENT '平台分类',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `type` char(15) NOT NULL DEFAULT '' COMMENT '类型',
  `account` char(50) NOT NULL DEFAULT '' COMMENT '发送的号码',
  `code` char(10) NOT NULL DEFAULT '' COMMENT '验证码',
  `char` text NOT NULL COMMENT '发送内容',
  `time` int(10) NOT NULL DEFAULT '0' COMMENT '发送时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '发送ip',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='验证码发送记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wechat_autoreply`
--

DROP TABLE IF EXISTS `huoniao_site_wechat_autoreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wechat_autoreply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `type` smallint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `body` varchar(255) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `media` varchar(100) NOT NULL DEFAULT '' COMMENT '微信素材ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信自动回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wechat_menu`
--

DROP TABLE IF EXISTS `huoniao_site_wechat_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wechat_menu` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT 'key或链接',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信自定义菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wxlogin`
--

DROP TABLE IF EXISTS `huoniao_site_wxlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wxlogin` (
  `state` varchar(50) NOT NULL DEFAULT '' COMMENT '登录参数',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '登录会员ID',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `loginUid` int(10) NOT NULL DEFAULT '0' COMMENT '已登陆用户id',
  `sameConn` char(60) NOT NULL DEFAULT '' COMMENT '已绑定此微信的用户',
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信登录临时验证';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wxmini_scene`
--

DROP TABLE IF EXISTS `huoniao_site_wxmini_scene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wxmini_scene` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转链接',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `fid` varchar(255) NOT NULL DEFAULT '' COMMENT '附件ID',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '访问次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='小程序自定义二维码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wxmini_unionid`
--

DROP TABLE IF EXISTS `huoniao_site_wxmini_unionid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wxmini_unionid` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `conn` varchar(255) NOT NULL DEFAULT '' COMMENT '标识信息',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `unionid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `conn` (`conn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='微信小程序unionid记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_wxupimg`
--

DROP TABLE IF EXISTS `huoniao_site_wxupimg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_wxupimg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `FromUserName` varchar(255) NOT NULL DEFAULT '' COMMENT '微信用户标识',
  `ticket` varchar(255) NOT NULL DEFAULT '' COMMENT '随机标识',
  `time` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  `PicUrl` varchar(255) NOT NULL DEFAULT '' COMMENT '图片地址',
  `MediaId` varchar(255) NOT NULL DEFAULT '' COMMENT '微信素材ID',
  `fid` varchar(50) NOT NULL DEFAULT '' COMMENT '附件ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信传图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_site_zanmap`
--

DROP TABLE IF EXISTS `huoniao_site_zanmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_site_zanmap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL COMMENT '点赞的人',
  `temp` varchar(255) NOT NULL COMMENT '模板（vide、quanjing、live）',
  `date` int(11) NOT NULL,
  `vid` int(11) NOT NULL COMMENT '点赞的视频id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='点赞表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_siteaddr`
--

DROP TABLE IF EXISTS `huoniao_siteaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_siteaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=284 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='网站地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_sitelog`
--

DROP TABLE IF EXISTS `huoniao_sitelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_sitelog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin` int(10) NOT NULL COMMENT '操作人',
  `name` char(100) NOT NULL DEFAULT '' COMMENT '动作',
  `note` text NOT NULL COMMENT '描述',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '操作IP',
  `pubdate` int(10) NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=51620 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_sitesms`
--

DROP TABLE IF EXISTS `huoniao_sitesms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_sitesms` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL DEFAULT '' COMMENT '名称',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(50) NOT NULL DEFAULT '' COMMENT '密码',
  `signCode` char(50) NOT NULL DEFAULT '' COMMENT '签名',
  `charset` tinyint(1) NOT NULL DEFAULT '0' COMMENT '编码',
  `sendUrl` char(255) NOT NULL DEFAULT '' COMMENT '发送地址',
  `sendCode` char(100) NOT NULL DEFAULT '' COMMENT '成功状态',
  `accountUrl` char(255) NOT NULL DEFAULT '' COMMENT '查询地址',
  `accountCode` char(100) NOT NULL DEFAULT '' COMMENT '查询代码',
  `website` char(100) NOT NULL DEFAULT '' COMMENT '平台网址',
  `contact` char(200) NOT NULL DEFAULT '' COMMENT '联系方式',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `international` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支持国际短信',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='短信平台账号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_special`
--

DROP TABLE IF EXISTS `huoniao_special`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_special` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '分类ID',
  `note` text NOT NULL COMMENT '摘要',
  `head` text NOT NULL COMMENT '头部代码',
  `footer` text NOT NULL COMMENT '底部代码',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='专题列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_special_design`
--

DROP TABLE IF EXISTS `huoniao_special_design`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_special_design` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `projectid` int(10) NOT NULL DEFAULT '0' COMMENT '专题ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '页面名称',
  `alias` char(30) NOT NULL DEFAULT '' COMMENT '文件名',
  `islink` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否为链接',
  `title` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pagedata` longtext COMMENT '页面内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `projectid` (`projectid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `alias` (`alias`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='专题设计内容表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_special_temp`
--

DROP TABLE IF EXISTS `huoniao_special_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_special_temp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '模板名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `html` longtext NOT NULL COMMENT '页面代码',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='专题模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_special_temptype`
--

DROP TABLE IF EXISTS `huoniao_special_temptype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_special_temptype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='专题模板分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_special_type`
--

DROP TABLE IF EXISTS `huoniao_special_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_special_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='专题分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tieba_list`
--

DROP TABLE IF EXISTS `huoniao_tieba_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tieba_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '发布会员',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '发布IP',
  `ipaddr` varchar(100) NOT NULL DEFAULT '' COMMENT 'ip详细地址',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `bold` tinyint(1) NOT NULL DEFAULT '0' COMMENT '加粗',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `isreply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可回复',
  `jinghua` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精华',
  `top` tinyint(1) NOT NULL DEFAULT '0' COMMENT '置顶',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '发布时所在地址',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  `up` int(10) NOT NULL DEFAULT '0' COMMENT '点赞',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `jinghua` (`jinghua`) USING BTREE,
  KEY `top` (`top`) USING BTREE,
  KEY `weight` (`top`,`jinghua`,`weight`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='贴吧帖子';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tieba_reply`
--

DROP TABLE IF EXISTS `huoniao_tieba_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tieba_reply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '帖子ID',
  `rid` int(10) NOT NULL DEFAULT '0' COMMENT '回复信息ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` text NOT NULL COMMENT '回复内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '回复时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`tid`) USING BTREE,
  KEY `rid` (`rid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='贴吧回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tieba_type`
--

DROP TABLE IF EXISTS `huoniao_tieba_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tieba_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='贴吧分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tieba_up`
--

DROP TABLE IF EXISTS `huoniao_tieba_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tieba_up` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '点赞ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '帖子ID',
  `ruid` int(10) NOT NULL DEFAULT '0' COMMENT '点赞人uid',
  `puctime` int(10) NOT NULL DEFAULT '0' COMMENT '点赞时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ruid` (`ruid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_transactionlogs`
--

DROP TABLE IF EXISTS `huoniao_transactionlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_transactionlogs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(8) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `amout` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '操作类型',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '备注',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='消费记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_business`
--

DROP TABLE IF EXISTS `huoniao_tuan_business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_business` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '称呼',
  `phone` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `shopname` char(60) NOT NULL DEFAULT '' COMMENT '商家名称',
  `pubdate` int(10) NOT NULL COMMENT '申请时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '申请IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'ip归属地',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `shopname` (`shopname`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购商务合作';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_circle`
--

DROP TABLE IF EXISTS `huoniao_tuan_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_circle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `qid` int(10) NOT NULL DEFAULT '0' COMMENT '区域ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '热门',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=404 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购区域商圈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_city`
--

DROP TABLE IF EXISTS `huoniao_tuan_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_city` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `type` smallint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购城市';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_faqlist`
--

DROP TABLE IF EXISTS `huoniao_tuan_faqlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_faqlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `weight` int(10) NOT NULL COMMENT '排序',
  `body` text NOT NULL COMMENT '内容',
  `arcrank` smallint(1) NOT NULL COMMENT '状态',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购常见问题';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_faqtype`
--

DROP TABLE IF EXISTS `huoniao_tuan_faqtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_faqtype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购常见问题分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_order`
--

DROP TABLE IF EXISTS `huoniao_tuan_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ordernum` char(18) NOT NULL DEFAULT '' COMMENT '订单号',
  `userid` int(8) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `proid` int(10) NOT NULL DEFAULT '0' COMMENT '团购产品',
  `procount` int(10) NOT NULL DEFAULT '0' COMMENT '团购数量',
  `point` int(10) DEFAULT '0' COMMENT '使用的积分',
  `balance` float(8,2) DEFAULT '0.00' COMMENT '使用的余额',
  `payprice` float(8,2) DEFAULT '0.00' COMMENT '支付的费用',
  `orderprice` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '团购单价',
  `propolic` char(255) NOT NULL DEFAULT '' COMMENT '产品物流策略',
  `orderstate` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `orderdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytype` char(30) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `deliveryType` tinyint(1) NOT NULL DEFAULT '0' COMMENT '送货时间',
  `useraddr` char(50) DEFAULT '' COMMENT '收货地址',
  `username` char(15) DEFAULT '' COMMENT '收货人',
  `usercontact` char(50) DEFAULT '' COMMENT '联系方式',
  `usernote` char(255) DEFAULT '' COMMENT '备注',
  `common` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价',
  `exp-company` char(20) DEFAULT '' COMMENT '发货快递公司',
  `exp-number` char(20) DEFAULT '' COMMENT '发货快递单号',
  `exp-date` int(10) DEFAULT '0' COMMENT '发货时间',
  `ret-state` tinyint(1) DEFAULT '0' COMMENT '申请退款',
  `ret-type` char(20) DEFAULT '' COMMENT '退款原因',
  `ret-note` text COMMENT '退款说明',
  `ret-pics` char(255) DEFAULT '' COMMENT '恳款凭证',
  `ret-date` int(10) DEFAULT '0' COMMENT '申请时间',
  `ret-s-note` text COMMENT '卖家回复',
  `ret-s-pics` char(255) DEFAULT '' COMMENT '卖家回复凭证',
  `ret-s-date` int(10) DEFAULT '0' COMMENT '卖家回复时间',
  `ret-ok-date` int(10) DEFAULT '0' COMMENT '退款确定时间',
  `tab` varchar(255) NOT NULL DEFAULT '' COMMENT '模块名',
  `pinid` int(10) NOT NULL DEFAULT '0' COMMENT '拼团id',
  `pinstate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '拼状态 0:待成团 1:成团',
  `pintype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '成员类别 0:成员 1:团长',
  `voucher` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否领券',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `proid` (`proid`) USING BTREE,
  KEY `orderstate` (`orderstate`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=168 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_pin`
--

DROP TABLE IF EXISTS `huoniao_tuan_pin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_pin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `oid` char(18) NOT NULL DEFAULT '0' COMMENT '订单id',
  `tid` int(10) NOT NULL DEFAULT '0' COMMENT '团购id',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 1:正常 2:失效 3:成功 4:退款中',
  `people` int(4) NOT NULL DEFAULT '0' COMMENT '已参加人数',
  `enddate` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `okdate` int(10) NOT NULL DEFAULT '0' COMMENT '成团时间',
  `user` char(100) NOT NULL DEFAULT '' COMMENT '成员ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购拼团';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_question`
--

DROP TABLE IF EXISTS `huoniao_tuan_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '提问人',
  `content` text NOT NULL COMMENT '提问内容',
  `by` int(8) DEFAULT NULL COMMENT '回复人',
  `replay` text COMMENT '回复内容',
  `rtime` int(10) DEFAULT NULL COMMENT '回复时间',
  `dtime` int(10) NOT NULL COMMENT '提问时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '提问IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购答疑';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_remind`
--

DROP TABLE IF EXISTS `huoniao_tuan_remind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_remind` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '提醒ID',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT '团购ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `puctime` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `state` tinyint(10) NOT NULL DEFAULT '0' COMMENT '是否已发送',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购提醒';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_store`
--

DROP TABLE IF EXISTS `huoniao_tuan_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_store` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `stype` int(10) NOT NULL DEFAULT '0' COMMENT '商家类型',
  `subway` char(50) NOT NULL DEFAULT '' COMMENT '附近地铁',
  `addrid` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `circle` char(50) NOT NULL DEFAULT '' COMMENT '所在商圈',
  `lnglat` char(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `tel` char(50) NOT NULL DEFAULT '' COMMENT '电话',
  `openStart` char(4) NOT NULL DEFAULT '' COMMENT '营业开始时间',
  `openEnd` char(4) NOT NULL DEFAULT '' COMMENT '营业结束时间',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '简介',
  `body` text NOT NULL COMMENT '详细介绍',
  `score` float(3,1) DEFAULT '0.0' COMMENT '总评分',
  `jointime` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `istop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '地图经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '地图纬度',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `pics` text NOT NULL COMMENT '图集',
  `phone` char(50) DEFAULT '' COMMENT '电话1',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购商家';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_storecommon`
--

DROP TABLE IF EXISTS `huoniao_tuan_storecommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_storecommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `score1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分1',
  `score2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分2',
  `score3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分3',
  `pics` tinytext COMMENT '图片',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='商家评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_subscribe`
--

DROP TABLE IF EXISTS `huoniao_tuan_subscribe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_subscribe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` char(30) NOT NULL DEFAULT '' COMMENT '订阅地址',
  `pubdate` int(10) NOT NULL COMMENT '订阅时间',
  `arcrank` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购订阅';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuan_voucher`
--

DROP TABLE IF EXISTS `huoniao_tuan_voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuan_voucher` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '领取ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT '团购ID',
  `puctime` int(11) NOT NULL DEFAULT '0' COMMENT '领取时间',
  `endtime` int(11) NOT NULL DEFAULT '0' COMMENT '使用时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='代金券领取表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuanaddr`
--

DROP TABLE IF EXISTS `huoniao_tuanaddr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuanaddr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `hot` smallint(1) NOT NULL DEFAULT '0' COMMENT '热门',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=315 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购地区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuancommon`
--

DROP TABLE IF EXISTS `huoniao_tuancommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuancommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `rating` tinyint(1) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `score1` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分1',
  `score2` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分2',
  `score3` tinyint(1) NOT NULL DEFAULT '0' COMMENT '评分3',
  `pics` tinytext COMMENT '图片',
  `content` text NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuanitem`
--

DROP TABLE IF EXISTS `huoniao_tuanitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuanitem` (
  `id` mediumint(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL COMMENT '信息ID',
  `iid` int(10) NOT NULL COMMENT '字段ID',
  `value` char(50) NOT NULL DEFAULT '' COMMENT '字段内容',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE,
  KEY `iid` (`iid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2613 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购字段内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuanlist`
--

DROP TABLE IF EXISTS `huoniao_tuanlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuanlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0' COMMENT '所属商家',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '标题',
  `subtitle` char(100) NOT NULL DEFAULT '' COMMENT '副标题',
  `startdate` int(10) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `enddate` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `hourly` smallint(1) NOT NULL DEFAULT '0' COMMENT '整点团',
  `minnum` int(8) NOT NULL DEFAULT '0' COMMENT '最低团购数量',
  `maxnum` int(8) NOT NULL DEFAULT '0' COMMENT '最高团购数量',
  `limit` int(8) NOT NULL DEFAULT '0' COMMENT '购买限制',
  `defbuynum` int(8) NOT NULL DEFAULT '0' COMMENT '默认已购买数量',
  `buynum` int(8) NOT NULL DEFAULT '0' COMMENT '真实购买数量',
  `tuantype` smallint(1) NOT NULL DEFAULT '0' COMMENT '团购类别',
  `expireddate` int(10) NOT NULL DEFAULT '0' COMMENT '过期时间',
  `amount` int(8) NOT NULL DEFAULT '0' COMMENT '充值卡金额',
  `freight` int(8) NOT NULL DEFAULT '0' COMMENT '运费',
  `freeshi` int(8) NOT NULL DEFAULT '0' COMMENT '超过免运费',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `pics` text NOT NULL COMMENT '图集',
  `price` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '团购价',
  `market` float(8,2) NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `flag` char(100) NOT NULL DEFAULT '' COMMENT '属性',
  `tips` text NOT NULL COMMENT '重要通知',
  `notice` text NOT NULL COMMENT '购买须知',
  `packtype` tinyint(1) NOT NULL DEFAULT '1' COMMENT '套餐类型',
  `package` text NOT NULL COMMENT '套餐内容',
  `body` text NOT NULL COMMENT '团购内容',
  `mbody` text NOT NULL COMMENT '移动端内容',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `admin` int(10) DEFAULT '0' COMMENT '操作管理员',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '添加IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'ip归属地',
  `refund` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已退款',
  `rec` smallint(1) DEFAULT '0' COMMENT '推荐',
  `pin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支持拼团',
  `pinprice` float(8,2) NOT NULL COMMENT '拼团价',
  `pinpeople` tinyint(10) NOT NULL DEFAULT '0' COMMENT '拼团人数',
  `istop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `video` varchar(255) NOT NULL DEFAULT '' COMMENT '视频',
  `fx_reward` char(6) NOT NULL DEFAULT '' COMMENT '分销奖励金',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `tuantype` (`tuantype`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuanquan`
--

DROP TABLE IF EXISTS `huoniao_tuanquan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuanquan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(10) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `cardnum` char(50) NOT NULL DEFAULT '' COMMENT '券号',
  `carddate` int(10) NOT NULL DEFAULT '0' COMMENT '生成日期',
  `usedate` int(10) NOT NULL DEFAULT '0' COMMENT '使用日期',
  `expireddate` int(10) NOT NULL DEFAULT '0' COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `orderid` (`orderid`) USING BTREE,
  KEY `cardnum` (`cardnum`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='团购券';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuantype`
--

DROP TABLE IF EXISTS `huoniao_tuantype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuantype` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'seo关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'seo描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  `hot` smallint(1) NOT NULL DEFAULT '0' COMMENT '热门',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '颜色值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_tuantypeitem`
--

DROP TABLE IF EXISTS `huoniao_tuantypeitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_tuantypeitem` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `field` char(20) NOT NULL DEFAULT '0' COMMENT '字段名',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '字段别名',
  `orderby` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `formtype` char(10) NOT NULL DEFAULT '50' COMMENT '字段类型',
  `required` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否必填',
  `options` varchar(255) NOT NULL DEFAULT '' COMMENT '选项列表',
  `default` char(50) NOT NULL DEFAULT '' COMMENT '默认值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=199 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='团购分类字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_videocommon`
--

DROP TABLE IF EXISTS `huoniao_videocommon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_videocommon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` char(255) NOT NULL DEFAULT '' COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `aid` (`aid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='视频评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_videolist`
--

DROP TABLE IF EXISTS `huoniao_videolist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_videolist` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `subtitle` char(100) NOT NULL DEFAULT '' COMMENT '短标题',
  `flag` set('h','r','b','p','t') NOT NULL DEFAULT '' COMMENT '附加属性',
  `redirecturl` varchar(255) DEFAULT '' COMMENT '跳转地址',
  `weight` int(10) NOT NULL DEFAULT '1' COMMENT '排序',
  `litpic` char(255) DEFAULT '' COMMENT '缩略图',
  `source` char(30) NOT NULL DEFAULT '' COMMENT '来源',
  `sourceurl` char(200) NOT NULL DEFAULT '' COMMENT '来源网址',
  `videotype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '视频类型',
  `videourl` char(200) NOT NULL COMMENT '视频地址',
  `writer` char(20) NOT NULL DEFAULT '' COMMENT '作者',
  `typeid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `keywords` char(50) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `click` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '阅读次数',
  `color` char(7) NOT NULL DEFAULT '' COMMENT '标题颜色',
  `arcrank` smallint(1) NOT NULL DEFAULT '0' COMMENT '信息状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `admin` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布人',
  `del` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否已删除',
  `lng` varchar(50) DEFAULT NULL COMMENT '视频发布地址',
  `lat` varchar(50) DEFAULT NULL COMMENT '视频发布地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE,
  KEY `del` (`del`,`arcrank`,`typeid`,`flag`,`litpic`,`weight`) USING BTREE,
  KEY `flag` (`flag`) USING BTREE,
  KEY `admin` (`admin`) USING BTREE,
  KEY `keywords` (`keywords`) USING BTREE,
  KEY `weight` (`weight`,`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='视频信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_videotype`
--

DROP TABLE IF EXISTS `huoniao_videotype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_videotype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `ishidden` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `seotitle` varchar(80) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(60) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` char(150) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `pinyin` char(100) NOT NULL DEFAULT '' COMMENT '分类全拼',
  `py` char(50) NOT NULL DEFAULT '' COMMENT '分类首字母',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='视频分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_visitor`
--

DROP TABLE IF EXISTS `huoniao_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_visitor` (
  `phone` char(11) NOT NULL DEFAULT '11111111111',
  `usertags` tinyint(4) NOT NULL DEFAULT '0',
  `scantime` int(11) NOT NULL,
  PRIMARY KEY (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_vote_common`
--

DROP TABLE IF EXISTS `huoniao_vote_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_vote_common` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(8) NOT NULL COMMENT '活动id',
  `uid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '信息ID',
  `floor` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '楼层',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `content` char(255) NOT NULL COMMENT '评论内容',
  `dtime` int(10) NOT NULL COMMENT '评论时间',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '评论IP',
  `ipaddr` char(30) NOT NULL DEFAULT '' COMMENT 'IP归属地',
  `good` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '顶',
  `bad` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '踩',
  `ischeck` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `duser` text NOT NULL COMMENT '顶过的会员',
  `dip` text NOT NULL COMMENT '顶过的ip',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='投票选手评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_vote_list`
--

DROP TABLE IF EXISTS `huoniao_vote_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_vote_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '投票主题',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `end` int(10) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `body` text NOT NULL COMMENT '投票详情',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `admin` int(10) NOT NULL COMMENT '发布人',
  `arcrank` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `click` char(10) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `weight` int(10) DEFAULT '0' COMMENT '排序',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '投票状态',
  `waitpay` smallint(1) NOT NULL DEFAULT '0' COMMENT '等待支付',
  `alonepay` smallint(1) NOT NULL DEFAULT '0' COMMENT '单独支付',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `end` (`end`) USING BTREE,
  KEY `weight` (`weight`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='投票活动列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_vote_record`
--

DROP TABLE IF EXISTS `huoniao_vote_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_vote_record` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL COMMENT '活动id',
  `mid` int(10) NOT NULL COMMENT '投票人id',
  `ip` char(15) NOT NULL COMMENT '投票ip',
  `ipaddr` char(30) NOT NULL COMMENT 'ip详细地址',
  `pubdate` int(11) NOT NULL COMMENT '投票时间',
  `result` text NOT NULL COMMENT '结果',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `tild` (`tid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='投票记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_vote_user`
--

DROP TABLE IF EXISTS `huoniao_vote_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_vote_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL COMMENT '活动id',
  `name` char(10) NOT NULL COMMENT '选手姓名',
  `number` int(4) NOT NULL COMMENT '选手编号',
  `litpic` varchar(255) NOT NULL COMMENT '代表图',
  `age` int(2) NOT NULL COMMENT '年龄',
  `uheight` int(3) NOT NULL COMMENT '身高',
  `uweight` int(3) NOT NULL COMMENT '体重',
  `from` varchar(40) NOT NULL COMMENT '来自',
  `hobby` varchar(255) NOT NULL COMMENT '兴趣',
  `tel` char(20) NOT NULL COMMENT '联系电话',
  `intnum` int(10) NOT NULL COMMENT '基础票数',
  `pics` text NOT NULL COMMENT '图集',
  `body` text NOT NULL COMMENT '参赛文宣',
  `mbody` text NOT NULL COMMENT '参赛文宣-移动',
  `click` int(10) NOT NULL COMMENT '点击量',
  `arcrank` smallint(1) NOT NULL COMMENT '选手状态',
  `pubdate` int(11) NOT NULL COMMENT '添加时间',
  `admin` int(10) NOT NULL COMMENT '发布人',
  `weight` int(10) NOT NULL COMMENT '排序',
  `ip` char(15) NOT NULL COMMENT '提交IP',
  `ipaddr` char(30) NOT NULL COMMENT 'IP详细地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `tid` (`tid`) USING BTREE,
  KEY `number` (`number`) USING BTREE,
  KEY `click` (`click`) USING BTREE,
  KEY `weight` (`weight`) USING BTREE,
  KEY `pubdate` (`pubdate`) USING BTREE,
  KEY `arcrank` (`arcrank`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='投票活动-报名选手';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_addr`
--

DROP TABLE IF EXISTS `huoniao_waimai_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_addr` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=255 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_address`
--

DROP TABLE IF EXISTS `huoniao_waimai_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `person` varchar(50) NOT NULL DEFAULT '' COMMENT '联系人',
  `tel` varchar(50) NOT NULL DEFAULT '' COMMENT '电话',
  `street` varchar(100) NOT NULL DEFAULT '' COMMENT '街道小区',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖收货地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_album`
--

DROP TABLE IF EXISTS `huoniao_waimai_album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '所属餐厅',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '相册分类',
  `path` char(30) NOT NULL DEFAULT '' COMMENT '图片地址',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '图片介绍',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖餐厅相册';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_album_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_album_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_album_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '餐厅ID',
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖餐厅相册分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_common`
--

DROP TABLE IF EXISTS `huoniao_waimai_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_common` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单类型 0:外卖 1:跑腿',
  `oid` int(10) NOT NULL DEFAULT '0' COMMENT '订单id',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `peisongid` int(10) NOT NULL DEFAULT '0' COMMENT '配送员id',
  `content` text NOT NULL COMMENT '评论内容',
  `star` tinyint(1) NOT NULL DEFAULT '0' COMMENT '星级',
  `isanony` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否匿名',
  `starps` tinyint(1) NOT NULL DEFAULT '0' COMMENT '星级-配送员',
  `contentps` text NOT NULL COMMENT '评论内容-配送员',
  `pics` text NOT NULL COMMENT '图集',
  `reply` text NOT NULL COMMENT '回复内容',
  `replydate` int(10) NOT NULL DEFAULT '0' COMMENT '回复时间',
  `time` int(4) NOT NULL DEFAULT '0' COMMENT '订单完成时间',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_courier`
--

DROP TABLE IF EXISTS `huoniao_waimai_courier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_courier` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '姓名',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(100) NOT NULL DEFAULT '' COMMENT '密码',
  `phone` varchar(50) NOT NULL DEFAULT '' COMMENT '电话',
  `age` varchar(10) NOT NULL DEFAULT '' COMMENT '年龄',
  `sex` smallint(1) NOT NULL DEFAULT '1' COMMENT '性别',
  `photo` varchar(100) NOT NULL DEFAULT '' COMMENT '头像',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  `path` text COMMENT '最新路径',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `quit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否离职',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配送员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_courier_log`
--

DROP TABLE IF EXISTS `huoniao_waimai_courier_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_courier_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '配送员id',
  `uid` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型 1:开工 0:停工',
  `ip` char(30) NOT NULL DEFAULT '' COMMENT 'ip',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '时间2',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配送员开停工日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_list`
--

DROP TABLE IF EXISTS `huoniao_waimai_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '商品名称',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '商品分类',
  `unit` varchar(10) NOT NULL DEFAULT '' COMMENT '商品单位',
  `label` varchar(50) NOT NULL DEFAULT '' COMMENT '标签',
  `is_dabao` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否有打包费',
  `dabao_money` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '打包费',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `stockvalid` smallint(1) NOT NULL DEFAULT '0' COMMENT '启用库存',
  `stock` int(10) NOT NULL DEFAULT '0' COMMENT '库存量',
  `formerprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '原价',
  `descript` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `body` text NOT NULL COMMENT '描述',
  `is_nature` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启商品属性',
  `nature` text NOT NULL COMMENT '商品属性',
  `is_day_limitfood` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启限购',
  `day_foodnum` int(10) NOT NULL DEFAULT '0' COMMENT '限购数量',
  `is_limitfood` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启限购活动',
  `foodnum` int(10) NOT NULL DEFAULT '0' COMMENT '限购数量',
  `start_time` int(10) NOT NULL DEFAULT '0' COMMENT '限制开始时间',
  `stop_time` int(10) NOT NULL DEFAULT '0' COMMENT '限制结束时间',
  `limit_time` text NOT NULL COMMENT '限制时间段',
  `pics` text NOT NULL COMMENT '商品图集',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `fx_reward` char(6) NOT NULL DEFAULT '' COMMENT '分销奖励金',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `price` (`price`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `is_dabao` (`is_dabao`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `stockvalid` (`stockvalid`) USING BTREE,
  KEY `stock` (`stock`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_list_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_list_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_list_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `start_time` varchar(5) NOT NULL DEFAULT '' COMMENT '显示时间段开始时间',
  `end_time` varchar(5) NOT NULL DEFAULT '' COMMENT '显示时间段结束时间',
  `weekshow` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启只星期几显示',
  `week` varchar(13) NOT NULL DEFAULT '' COMMENT '星期几显示',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='店铺商品分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_menu`
--

DROP TABLE IF EXISTS `huoniao_waimai_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '所属餐厅',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '菜单分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pics` char(255) NOT NULL DEFAULT '' COMMENT '菜单图集',
  `price` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `note` char(255) NOT NULL DEFAULT '' COMMENT '简介',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=174 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖餐厅菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_menu_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_menu_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_menu_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '餐厅ID',
  `typename` char(20) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `store` (`store`) USING BTREE,
  KEY `typename` (`typename`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖餐厅菜单分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_news`
--

DROP TABLE IF EXISTS `huoniao_waimai_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '信息标题',
  `typeid` int(8) NOT NULL COMMENT '所属分类',
  `body` text NOT NULL COMMENT '内容',
  `pubdate` int(10) NOT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖问题';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_news_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_news_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_news_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖问题分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_order`
--

DROP TABLE IF EXISTS `huoniao_waimai_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺ID',
  `ordernum` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `ordernumstore` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号 日期-序号',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `fids` varchar(255) NOT NULL DEFAULT '' COMMENT '商品ID集合',
  `food` text NOT NULL COMMENT '商品内容',
  `person` varchar(50) NOT NULL DEFAULT '' COMMENT '联系人',
  `tel` varchar(50) NOT NULL DEFAULT '' COMMENT '电话',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度 ',
  `paytype` varchar(50) NOT NULL DEFAULT '' COMMENT '支付方式',
  `amount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `priceinfo` text NOT NULL COMMENT '价格明细',
  `preset` text NOT NULL COMMENT '预设选项',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paydate` int(10) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `confirmdate` int(10) NOT NULL DEFAULT '0' COMMENT '商家确认时间',
  `peidate` int(10) NOT NULL DEFAULT '0' COMMENT '接单时间',
  `peisongid` int(10) NOT NULL DEFAULT '0' COMMENT '配送员',
  `peisongidlog` text NOT NULL COMMENT '配送员变更记录',
  `songdate` int(10) NOT NULL DEFAULT '0' COMMENT '配送时间',
  `okdate` int(10) NOT NULL DEFAULT '0' COMMENT '成功时间',
  `failed` varchar(255) NOT NULL DEFAULT '' COMMENT '订单失败原因',
  `peisongpath` text NOT NULL COMMENT '地图路径',
  `print_dataid` varchar(50) NOT NULL DEFAULT '' COMMENT '打印成功接口ID',
  `iscomment` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已评价 0:未评价 1:已评价',
  `failedadmin` int(10) NOT NULL DEFAULT '0' COMMENT '无效订单操作人id',
  `refrundstate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款状态 1:成功',
  `refrunddate` int(10) NOT NULL DEFAULT '0' COMMENT '退款时间',
  `refrundno` varchar(50) DEFAULT '' COMMENT '退款流水号',
  `refrundfailed` varchar(255) NOT NULL DEFAULT '' COMMENT '退款失败错误码',
  `refrundadmin` int(10) NOT NULL DEFAULT '0' COMMENT '操作人id',
  `usequan` int(10) NOT NULL DEFAULT '0' COMMENT '使用优惠券',
  `transaction_id` varchar(100) NOT NULL DEFAULT '' COMMENT '第三方支付平台订单号',
  `paylognum` varchar(100) NOT NULL DEFAULT '' COMMENT '支付记录订单号',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `pushed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已推送',
  `courier_pushed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '骑手推送',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `sid` (`sid`) USING BTREE,
  KEY `ordernum` (`ordernum`) USING BTREE,
  KEY `state` (`state`) USING BTREE,
  KEY `fids` (`fids`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_order_product`
--

DROP TABLE IF EXISTS `huoniao_waimai_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_order_product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` int(10) NOT NULL DEFAULT '0' COMMENT '订单ID',
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '商家ID',
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '商品ID',
  `pname` char(50) NOT NULL DEFAULT '' COMMENT '商品名称',
  `price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `count` int(10) NOT NULL DEFAULT '0' COMMENT '数量',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖订单商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_order_temp`
--

DROP TABLE IF EXISTS `huoniao_waimai_order_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_order_temp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `sid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '地址',
  `paytype` char(15) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paypwd` char(30) NOT NULL DEFAULT '' COMMENT '余额支付密码',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `quanid` int(10) NOT NULL DEFAULT '0' COMMENT '优惠券',
  `preset` text NOT NULL COMMENT '预设选项',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='购物车选项信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_quan`
--

DROP TABLE IF EXISTS `huoniao_waimai_quan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_quan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `des` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `money` float(9,1) NOT NULL DEFAULT '0.0' COMMENT '面值',
  `basic_price` float(9,1) NOT NULL DEFAULT '0.0' COMMENT '最低消费额度',
  `deadline_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '截止时间类型 0:指定有效天数 1:指定有效日期',
  `validity` int(4) NOT NULL DEFAULT '0' COMMENT '有效性',
  `deadline` int(10) NOT NULL DEFAULT '0' COMMENT '截止日期',
  `shoptype` tinyint(10) NOT NULL DEFAULT '0' COMMENT '试用店铺类型 0:全部店铺 1:指定店铺',
  `shopids` text NOT NULL COMMENT '指定店铺id',
  `is_relation_food` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否关联商品 0:不关联 1:关联',
  `fid` text NOT NULL COMMENT '商品id',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加日期',
  `bear` tinyint(1) NOT NULL DEFAULT '0' COMMENT '费用承担主体',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖优惠券';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_quanlist`
--

DROP TABLE IF EXISTS `huoniao_waimai_quanlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_quanlist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `qid` int(10) NOT NULL DEFAULT '0' COMMENT '券id',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `des` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `money` float(9,1) NOT NULL DEFAULT '0.0' COMMENT '面值',
  `basic_price` float(9,1) NOT NULL DEFAULT '0.0' COMMENT '最低消费额度',
  `deadline` int(10) NOT NULL DEFAULT '0' COMMENT '截止日期',
  `shopids` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺id',
  `fid` varchar(255) NOT NULL DEFAULT '' COMMENT '商品id',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发放时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 -1:未生效 0:未使用 1:使用 2:',
  `usedate` int(10) NOT NULL DEFAULT '0' COMMENT '使用时间',
  `oid` int(10) NOT NULL DEFAULT '0' COMMENT '订单id',
  `from` int(10) NOT NULL DEFAULT '0' COMMENT '来源 订单满送',
  `bear` tinyint(1) NOT NULL DEFAULT '0' COMMENT '费用承担主体',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖优惠券发放';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_review`
--

DROP TABLE IF EXISTS `huoniao_waimai_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '评论会员',
  `store` int(10) NOT NULL DEFAULT '0' COMMENT '所属餐厅',
  `rating` tinyint(5) NOT NULL DEFAULT '0' COMMENT '总体评价',
  `note` text NOT NULL COMMENT '评价内容',
  `pics` text NOT NULL COMMENT '真实照片',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '评价时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖餐厅评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_shop`
--

DROP TABLE IF EXISTS `huoniao_waimai_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_shop` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cityid` int(10) NOT NULL DEFAULT '0' COMMENT '城市ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '商家会员ID',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `shopname` varchar(100) NOT NULL DEFAULT '' COMMENT '店铺名称',
  `typeid` varchar(50) NOT NULL DEFAULT '' COMMENT '店铺分类',
  `category` int(10) NOT NULL DEFAULT '0' COMMENT '行业类型',
  `phone` varchar(100) NOT NULL DEFAULT '' COMMENT '联系电话',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺地址',
  `qq` varchar(50) NOT NULL DEFAULT '' COMMENT 'QQ',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺描述',
  `coordX` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  `coordY` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `status` smallint(1) NOT NULL DEFAULT '0' COMMENT '店铺状态',
  `closeinfo` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺关闭提示',
  `ordervalid` smallint(1) NOT NULL DEFAULT '0' COMMENT '下单状态',
  `ordervalid_before` smallint(1) NOT NULL DEFAULT '0' COMMENT '一键操作前微信下单状态',
  `closeorder` varchar(255) NOT NULL DEFAULT '' COMMENT '微信下单关闭提示',
  `merchant_deliver` smallint(1) NOT NULL DEFAULT '0' COMMENT '商家配送',
  `selftake` smallint(1) NOT NULL DEFAULT '0' COMMENT '到店自取',
  `cancelorder` smallint(1) NOT NULL DEFAULT '0' COMMENT '允许取消订单',
  `weeks` varchar(15) NOT NULL DEFAULT '' COMMENT '营业星期',
  `start_time1` varchar(5) NOT NULL DEFAULT '' COMMENT '营业开始时间',
  `end_time1` varchar(5) NOT NULL DEFAULT '' COMMENT '营业结束时间',
  `start_time2` varchar(5) NOT NULL DEFAULT '' COMMENT '营业开始时间',
  `end_time2` varchar(5) NOT NULL DEFAULT '' COMMENT '营业结束时间',
  `start_time3` varchar(5) NOT NULL DEFAULT '' COMMENT '营业开始时间',
  `end_time3` varchar(5) NOT NULL DEFAULT '' COMMENT '营业结束时间',
  `delivery_radius` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '配送范围',
  `delivery_area` varchar(255) NOT NULL DEFAULT '' COMMENT '配送区域',
  `delivery_fee_mode` smallint(1) NOT NULL DEFAULT '1' COMMENT '起送价、配送费模式',
  `basicprice` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '起送价',
  `delivery_fee` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '外送费',
  `delivery_fee_type` smallint(1) NOT NULL DEFAULT '0' COMMENT '外送费类型',
  `delivery_fee_value` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '满多少远免外送费',
  `service_area_data` text NOT NULL COMMENT '服务区域',
  `open_range_delivery_fee` smallint(1) NOT NULL DEFAULT '0' COMMENT '按距离收取不同外送费',
  `range_delivery_fee_value` text NOT NULL COMMENT '不同距离的外送费规则',
  `shop_notice` text NOT NULL COMMENT '店铺公告',
  `shop_notice_used` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启选购页面公告',
  `buy_notice` varchar(255) NOT NULL DEFAULT '' COMMENT '选购页面公告',
  `linktype` smallint(1) NOT NULL DEFAULT '0' COMMENT '进入店铺链接类型',
  `callshow` smallint(1) NOT NULL DEFAULT '0' COMMENT '店铺首页显示拨打电话',
  `unitshow` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示商品单位',
  `opencomment` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启评论',
  `showtype` smallint(1) NOT NULL DEFAULT '0' COMMENT '展示风格',
  `food_showtype` smallint(1) NOT NULL DEFAULT '0' COMMENT '商品详情显示风格',
  `showsales` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示商品销量',
  `show_basicprice` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示起送价',
  `show_delivery` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示外送费',
  `show_range` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示服务距离',
  `show_area` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示配送区域',
  `show_delivery_service` smallint(1) NOT NULL DEFAULT '0' COMMENT '显示配送服务商名称',
  `delivery_service` varchar(100) NOT NULL DEFAULT '' COMMENT '配送服务商',
  `delivery_time` int(4) NOT NULL DEFAULT '0' COMMENT '配送时长',
  `memo_hint` varchar(255) NOT NULL DEFAULT '' COMMENT '备注提示',
  `address_hint` varchar(255) NOT NULL DEFAULT '' COMMENT '地址提示',
  `order_prefix` varchar(50) NOT NULL DEFAULT '' COMMENT '订单编号前缀',
  `paytype` varchar(255) NOT NULL DEFAULT '' COMMENT '支付方式',
  `offline_limit` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启货到付款金额限制',
  `pay_offline_limit` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '货到付款金额限制',
  `preset` text NOT NULL COMMENT '预设选项',
  `is_first_discount` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否开启首单减免',
  `first_discount` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '首单减免金额',
  `is_discount` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启店铺打折',
  `discount_value` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '店铺折扣值',
  `open_promotion` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启满减',
  `promotions` text NOT NULL COMMENT '满减规则',
  `open_fullcoupon` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启满送',
  `fullcoupon` text NOT NULL COMMENT '满送规则',
  `smsvalid` smallint(1) NOT NULL DEFAULT '0' COMMENT '短信订单提醒',
  `sms_phone` varchar(11) NOT NULL DEFAULT '' COMMENT '接收短信手机号码',
  `emailvalid` smallint(1) NOT NULL DEFAULT '0' COMMENT '邮箱订单提醒',
  `email_address` varchar(100) NOT NULL DEFAULT '' COMMENT '接收订单email地址',
  `weixinvalid` smallint(1) NOT NULL DEFAULT '0' COMMENT '微信订单提醒',
  `customerid` int(10) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `auto_printer` smallint(1) NOT NULL DEFAULT '0' COMMENT '自动打印',
  `showordernum` smallint(1) NOT NULL DEFAULT '0' COMMENT '打印显示下单次数',
  `shop_banner` text NOT NULL COMMENT '店铺图片',
  `open_addservice` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启增值服务',
  `addservice` text NOT NULL COMMENT '增值服务规则',
  `selfdefine` text NOT NULL COMMENT '自定义显示内容',
  `share_title` varchar(100) NOT NULL DEFAULT '' COMMENT '分享标题',
  `share_pic` varchar(100) NOT NULL DEFAULT '' COMMENT '分享图片',
  `jointime` int(10) NOT NULL DEFAULT '0' COMMENT '入驻时间',
  `bind_print` smallint(1) NOT NULL DEFAULT '0' COMMENT '开启打印机',
  `print_config` text NOT NULL COMMENT '用户ID',
  `print_state` smallint(1) NOT NULL DEFAULT '0' COMMENT '打印机状态',
  `fencheng_foodprice` smallint(3) NOT NULL DEFAULT '0' COMMENT '商品原价分成',
  `fencheng_delivery` smallint(3) NOT NULL DEFAULT '0' COMMENT '配送费分成',
  `fencheng_dabao` smallint(3) NOT NULL DEFAULT '0' COMMENT '打包分成',
  `fencheng_addservice` smallint(3) NOT NULL DEFAULT '0' COMMENT '增值服务费分成',
  `fencheng_discount` smallint(3) NOT NULL DEFAULT '0' COMMENT '折扣分摊',
  `fencheng_promotion` smallint(3) NOT NULL DEFAULT '0' COMMENT '满减分摊',
  `fencheng_firstdiscount` smallint(3) NOT NULL DEFAULT '0' COMMENT '首单减免分摊',
  `fencheng_offline` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否扣除货到付款项',
  `fencheng_quan` smallint(3) NOT NULL DEFAULT '0' COMMENT '优惠券分摊',
  `food_license_img` varchar(255) NOT NULL DEFAULT '' COMMENT '食品安全许可证',
  `business_license_img` varchar(255) NOT NULL DEFAULT '' COMMENT '营业执照',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `basicprice_min` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '当前模式最低起送价',
  `salesman` char(30) NOT NULL DEFAULT '' COMMENT '业务员',
  `salesdate` int(10) NOT NULL DEFAULT '0' COMMENT '签约时间',
  `store_switch` smallint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `shopname` (`shopname`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE,
  KEY `category` (`category`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `address` (`address`) USING BTREE,
  KEY `qq` (`qq`) USING BTREE,
  KEY `coordX` (`coordX`) USING BTREE,
  KEY `coordY` (`coordY`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `ordervalid` (`ordervalid`) USING BTREE,
  KEY `weeks` (`weeks`) USING BTREE,
  KEY `start_time1` (`start_time1`) USING BTREE,
  KEY `end_time1` (`end_time1`) USING BTREE,
  KEY `start_time2` (`start_time2`) USING BTREE,
  KEY `end_time2` (`end_time2`) USING BTREE,
  KEY `start_time3` (`start_time3`) USING BTREE,
  KEY `end_time3` (`end_time3`) USING BTREE,
  KEY `delivery_radius` (`delivery_radius`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='店铺列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_shop_manager`
--

DROP TABLE IF EXISTS `huoniao_waimai_shop_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_shop_manager` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户id',
  `shopid` int(10) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖店铺管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_shop_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_shop_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_shop_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '编号',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='店铺分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_store`
--

DROP TABLE IF EXISTS `huoniao_waimai_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_store` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '管理会员',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '餐厅名称',
  `typeid` char(20) NOT NULL DEFAULT '' COMMENT '所属菜系',
  `logo` char(30) NOT NULL DEFAULT '' COMMENT '餐厅LOGO',
  `start1` char(5) NOT NULL DEFAULT '' COMMENT '上午营业开始时间',
  `end1` char(5) NOT NULL DEFAULT '' COMMENT '上午营业结束时间',
  `start2` char(5) NOT NULL DEFAULT '' COMMENT '下午营业开始时间',
  `end2` char(5) NOT NULL DEFAULT '' COMMENT '下午营业结束时间',
  `times` int(3) NOT NULL DEFAULT '0' COMMENT '平均送达时间',
  `addr` int(10) NOT NULL DEFAULT '0' COMMENT '所在区域',
  `address` char(60) NOT NULL DEFAULT '' COMMENT '餐厅地址',
  `lnglat` varchar(50) NOT NULL DEFAULT '' COMMENT '坐标',
  `tel` char(13) NOT NULL DEFAULT '' COMMENT '餐厅电话',
  `range` text NOT NULL COMMENT '配送区域',
  `price` int(4) NOT NULL DEFAULT '0' COMMENT '起送价',
  `peisong` int(4) NOT NULL DEFAULT '0' COMMENT '配送费',
  `online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支持在线支付',
  `sale` char(50) NOT NULL DEFAULT '' COMMENT '立减优惠',
  `supfapiao` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支持开发票',
  `fapiao` int(3) NOT NULL DEFAULT '0' COMMENT '满多少可以开发票',
  `fapiaonote` char(20) NOT NULL DEFAULT '' COMMENT '开发票说明',
  `note` text NOT NULL COMMENT '餐厅介绍',
  `notice` text NOT NULL COMMENT '餐厅公告',
  `yingye` tinyint(1) NOT NULL DEFAULT '0' COMMENT '营业执照认证',
  `yingyezhizhao` char(30) NOT NULL DEFAULT '' COMMENT '营业执照',
  `weisheng` tinyint(1) NOT NULL DEFAULT '0' COMMENT '卫生许可证认证',
  `weishengxuke` char(30) NOT NULL DEFAULT '' COMMENT '卫生许可证',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '加入时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `start` (`start1`) USING BTREE,
  KEY `end` (`end1`) USING BTREE,
  KEY `addr` (`addr`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖餐厅';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_system`
--

DROP TABLE IF EXISTS `huoniao_waimai_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_system` (
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '页面标题',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '页面描述',
  `tel` varchar(255) NOT NULL DEFAULT '' COMMENT '客服电话',
  `share_pic` varchar(200) NOT NULL DEFAULT '' COMMENT '分享图片',
  `index_banner` text NOT NULL COMMENT '首页banner',
  `tubiao_nav` text NOT NULL COMMENT '图标导航',
  `ad1` text NOT NULL COMMENT '广告位',
  `huodong_nav` text NOT NULL COMMENT '活动导航',
  `shop` text NOT NULL COMMENT '活动店铺'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='外卖设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_waimai_type`
--

DROP TABLE IF EXISTS `huoniao_waimai_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_waimai_type` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='外卖菜系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website`
--

DROP TABLE IF EXISTS `huoniao_website`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL DEFAULT '' COMMENT '标题',
  `domaintype` smallint(1) NOT NULL DEFAULT '0' COMMENT '域名类型',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '分类ID',
  `note` text NOT NULL COMMENT '摘要',
  `head` text NOT NULL COMMENT '头部代码',
  `footer` text NOT NULL COMMENT '底部代码',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `touch_temp` char(10) NOT NULL DEFAULT '' COMMENT '移动端模板',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_360qj`
--

DROP TABLE IF EXISTS `huoniao_website_360qj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_360qj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '全景标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `typeid` smallint(1) NOT NULL DEFAULT '0' COMMENT '全景类型',
  `file` char(255) NOT NULL DEFAULT '' COMMENT '文件地址',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '全景内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站全景展示';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_article`
--

DROP TABLE IF EXISTS `huoniao_website_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_article` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '文章标题',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '文章分类',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '新闻内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站新闻管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_articletype`
--

DROP TABLE IF EXISTS `huoniao_website_articletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_articletype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '分类名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站新闻分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_case`
--

DROP TABLE IF EXISTS `huoniao_website_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_case` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '案例标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '案例内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站成功案例';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_design`
--

DROP TABLE IF EXISTS `huoniao_website_design`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_design` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `projectid` int(10) NOT NULL DEFAULT '0' COMMENT '专题ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '页面名称',
  `alias` char(30) NOT NULL DEFAULT '' COMMENT '文件名',
  `islink` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否为链接',
  `title` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pagedata` longtext COMMENT '页面内容',
  `appname` char(10) NOT NULL DEFAULT '' COMMENT '应用名称-模板专用',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `projectid` (`projectid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `alias` (`alias`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站设计内容表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_events`
--

DROP TABLE IF EXISTS `huoniao_website_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_events` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '活动标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '活动内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站活动中心';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_guest`
--

DROP TABLE IF EXISTS `huoniao_website_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_guest` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '网站ID',
  `people` char(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `contact` char(30) NOT NULL DEFAULT '' COMMENT '联系电话',
  `email` char(30) NOT NULL DEFAULT '' COMMENT '邮箱',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `ipaddr` char(60) NOT NULL,
  `note` text NOT NULL,
  `reply` text COMMENT '回复',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '留言时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `people` (`people`) USING BTREE,
  KEY `contact` (`contact`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站留言管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_product`
--

DROP TABLE IF EXISTS `huoniao_website_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '产品标题',
  `typeid` int(10) NOT NULL DEFAULT '0' COMMENT '文章分类',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '产品内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站产品管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_producttype`
--

DROP TABLE IF EXISTS `huoniao_website_producttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_producttype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '分类名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站产品分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_temp`
--

DROP TABLE IF EXISTS `huoniao_website_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_temp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '所属分类',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '模板名称',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_temp_pages`
--

DROP TABLE IF EXISTS `huoniao_website_temp_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_temp_pages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tempid` int(10) NOT NULL DEFAULT '0' COMMENT '模板ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '页面名称',
  `alias` char(30) NOT NULL DEFAULT '' COMMENT '文件名',
  `islink` smallint(1) NOT NULL DEFAULT '0' COMMENT '是否为链接',
  `title` char(100) NOT NULL DEFAULT '' COMMENT 'seo标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pagedata` longtext COMMENT '页面内容',
  `appname` char(10) NOT NULL DEFAULT '' COMMENT '应用名称-模板专用',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `tempid` (`tempid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `alias` (`alias`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站模板页面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_temptype`
--

DROP TABLE IF EXISTS `huoniao_website_temptype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_temptype` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站模板分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_touch`
--

DROP TABLE IF EXISTS `huoniao_website_touch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_touch` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `alias` char(30) NOT NULL DEFAULT '' COMMENT '文件名',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '图标',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '页面标题',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '新闻内容',
  `sys` tinyint(1) NOT NULL DEFAULT '0' COMMENT '系统页面',
  `jump` smallint(1) NOT NULL DEFAULT '0' COMMENT '跳转',
  `jump_url` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站-移动端单页';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_touch_info`
--

DROP TABLE IF EXISTS `huoniao_website_touch_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_touch_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `type` char(15) NOT NULL DEFAULT '' COMMENT '类型',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `litpic` char(50) NOT NULL DEFAULT '' COMMENT '图片',
  `date` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  `body` text NOT NULL COMMENT '内容',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '点击',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站移动端内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_type`
--

DROP TABLE IF EXISTS `huoniao_website_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_type` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parentid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `typename` char(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `weight` int(5) unsigned NOT NULL DEFAULT '50' COMMENT '排序',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_website_video`
--

DROP TABLE IF EXISTS `huoniao_website_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_website_video` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `website` int(10) NOT NULL DEFAULT '0' COMMENT '所属网站',
  `title` char(60) NOT NULL DEFAULT '' COMMENT '视频标题',
  `litpic` char(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `typeid` smallint(1) NOT NULL DEFAULT '0' COMMENT '视频类型',
  `video` char(100) NOT NULL DEFAULT '' COMMENT '视频地址',
  `keywords` char(100) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` char(200) NOT NULL DEFAULT '' COMMENT '描述',
  `body` text NOT NULL COMMENT '视频内容',
  `click` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `website` (`website`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `typeid` (`typeid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站视频中心';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_websiteelement`
--

DROP TABLE IF EXISTS `huoniao_websiteelement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_websiteelement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sort` char(20) NOT NULL DEFAULT '' COMMENT '分类',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '元素名称',
  `type` char(20) NOT NULL DEFAULT '' COMMENT '元素英文名称',
  `appstype` int(10) NOT NULL DEFAULT '0' COMMENT '应用分类',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `config` text NOT NULL COMMENT '设置',
  `theme` char(20) NOT NULL DEFAULT '' COMMENT '风格目录',
  `state` smallint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `pubdate` int(10) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自助建站功能模块';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_websiteelement_theme`
--

DROP TABLE IF EXISTS `huoniao_websiteelement_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_websiteelement_theme` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0' COMMENT '元素ID',
  `name` char(20) NOT NULL DEFAULT '' COMMENT '风格名',
  `color` char(20) NOT NULL DEFAULT '' COMMENT '颜色名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=280 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站功能模块风格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `huoniao_websiteelement_type`
--

DROP TABLE IF EXISTS `huoniao_websiteelement_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `huoniao_websiteelement_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '分类名',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='自助建站功能模块分类';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-05 14:29:12
